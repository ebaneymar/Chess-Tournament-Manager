// CatQue v2.6.1 — exact FIDE Dutch C.04.3 loader.
// Pinned engine: @echecs/swiss v5.0.0.
// Published API: pair(Player[], Game[][]) -> {pairings, byes}
//
// The engine is accepted only if it passes the exact 5-player Dutch sequence
// that exposed CatQue's prior adapter bug.

const CATQUE_DUTCH_VERSION='5.0.0';
const CATQUE_DUTCH_ENTRY='https://esm.sh/@echecs/swiss@5.0.0/dutch?bundle&target=es2022';
const CATQUE_DUTCH_CACHE_KEY='catque:fide-dutch-exact:5.0.0:bundle';
const CATQUE_DUTCH_META_KEY='catque:fide-dutch-exact:5.0.0:meta';

let exactDutchPromise=null;

function absoluteEsmUrl(spec){
  return new URL(spec,'https://esm.sh').href;
}

async function fetchPinnedBundleSource(){
  const entryResponse=await fetch(CATQUE_DUTCH_ENTRY,{cache:'no-cache'});
  if(!entryResponse.ok)throw new Error(`Engine download failed (${entryResponse.status}).`);
  let source=await entryResponse.text();

  const m=source.match(/(?:from|import)\s*["'](\/[^"']+\.mjs[^"']*)["']/) ||
          source.match(/["'](\/[^"']+\.bundle\.mjs[^"']*)["']/);

  if(m){
    const bundleUrl=absoluteEsmUrl(m[1]);
    const bundleResponse=await fetch(bundleUrl,{cache:'no-cache'});
    if(!bundleResponse.ok)throw new Error(`Pinned bundle download failed (${bundleResponse.status}).`);
    source=await bundleResponse.text();
  }

  localStorage.setItem(CATQUE_DUTCH_CACHE_KEY,source);
  localStorage.setItem(CATQUE_DUTCH_META_KEY,JSON.stringify({
    version:CATQUE_DUTCH_VERSION,
    cachedAt:new Date().toISOString(),
    source:'@echecs/swiss',
    rule:'FIDE C.04.3',
    api:'pair(Player[], Game[][])'
  }));
  return source;
}

async function importBundleSource(source){
  const blob=new Blob([source],{type:'text/javascript'});
  const url=URL.createObjectURL(blob);
  try{
    const mod=await import(url);
    if(typeof mod.pair!=='function')throw new Error('pair() export was not found.');
    return mod.pair;
  }finally{
    URL.revokeObjectURL(url);
  }
}

function normalizePairingResult(result){
  return {
    pairings:Array.isArray(result?.pairings)
      ? result.pairings.map(x=>({white:String(x.white),black:String(x.black)}))
      : (Array.isArray(result?.games)
          ? result.games.map(x=>({white:String(x.white),black:String(x.black)}))
          : []),
    byes:Array.isArray(result?.byes)
      ? result.byes.map(x=>String(x.player ?? x.white ?? ''))
      : []
  };
}

function sameExactPairing(result,expectedPairings,expectedBye){
  const n=normalizePairingResult(result);
  if(n.byes.length!==1 || n.byes[0]!==expectedBye)return false;
  if(n.pairings.length!==expectedPairings.length)return false;
  return expectedPairings.every((e,i)=>
    n.pairings[i]?.white===e.white && n.pairings[i]?.black===e.black
  );
}

function runCatQueExactDutchSelfTest(pair){
  // User-reported exact sequence with all played games won by White:
  // R1: 1–3, 4–2, bye 5
  // R2: 5–1, 3–4, bye 2
  // R3 MUST: 2–5, 1–4, bye 3
  const players=['1','2','3','4','5'].map(id=>({id}));

  const r1=pair(players,[]);
  if(!sameExactPairing(
    r1,
    [{white:'1',black:'3'},{white:'4',black:'2'}],
    '5'
  )){
    throw new Error('FIDE Dutch self-test failed at Round 1.');
  }

  const round1=[
    {white:'1',black:'3',result:1},
    {white:'4',black:'2',result:1},
    {white:'5',black:'',result:1,kind:'pairing-bye'}
  ];
  const r2=pair(players,[round1]);
  if(!sameExactPairing(
    r2,
    [{white:'5',black:'1'},{white:'3',black:'4'}],
    '2'
  )){
    throw new Error('FIDE Dutch self-test failed at Round 2.');
  }

  const round2=[
    {white:'5',black:'1',result:1},
    {white:'3',black:'4',result:1},
    {white:'2',black:'',result:1,kind:'pairing-bye'}
  ];
  const r3=pair(players,[round1,round2]);
  if(!sameExactPairing(
    r3,
    [{white:'2',black:'5'},{white:'1',black:'4'}],
    '3'
  )){
    const got=normalizePairingResult(r3);
    throw new Error(
      `FIDE Dutch self-test failed at Round 3. Got ${JSON.stringify(got)}.`
    );
  }

  return true;
}

async function validateExactPair(pair){
  runCatQueExactDutchSelfTest(pair);
  window.__fideDutchExactSelfTest='PASS';
  return pair;
}

async function loadExactDutch(){
  if(typeof window.__fideDutchExactPair==='function')return window.__fideDutchExactPair;
  if(exactDutchPromise)return exactDutchPromise;

  exactDutchPromise=(async()=>{
    let cached=localStorage.getItem(CATQUE_DUTCH_CACHE_KEY);

    if(cached){
      try{
        const pair=await importBundleSource(cached);
        await validateExactPair(pair);
        window.__fideDutchExactPair=pair;
        window.__fideDutchExactReady=true;
        return pair;
      }catch(err){
        console.warn('Cached exact Dutch engine failed validation; refreshing it.',err);
        localStorage.removeItem(CATQUE_DUTCH_CACHE_KEY);
        localStorage.removeItem(CATQUE_DUTCH_META_KEY);
        cached=null;
      }
    }

    const source=await fetchPinnedBundleSource();
    const pair=await importBundleSource(source);
    await validateExactPair(pair);

    window.__fideDutchExactPair=pair;
    window.__fideDutchExactReady=true;
    return pair;
  })();

  try{
    return await exactDutchPromise;
  }catch(err){
    window.__fideDutchExactReady=false;
    window.__fideDutchExactSelfTest='FAIL';
    throw err;
  }finally{
    exactDutchPromise=null;
  }
}

window.ensureFideDutchExact=loadExactDutch;
window.__fideDutchExactVersion=CATQUE_DUTCH_VERSION;

// Preload/cache and SELF-TEST before the tournament reaches Round 1.
loadExactDutch().catch(err=>{
  console.error('Exact FIDE Dutch engine failed preload/self-test:',err);
});
