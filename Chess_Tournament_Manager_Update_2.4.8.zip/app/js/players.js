// Chess Tournament Manager 2.0
// Player roster, structured names, ratings, CSV import, and player actions.

function playerDisplay(p){
  if(!p)return '';
  ensurePlayerStructuredName(p);
  const d=delegationLabel(p);
  return d ? `${p.name} — ${d}` : p.name;
}

function isOpenIndividualTournament(){
  return state.settings?.eventScope==='open' && state.settings?.mode!=='team';
}

function applyTournamentScopeUI(){
  const open=isOpenIndividualTournament();

  document.querySelectorAll('.school-player-name-field').forEach(el=>el.style.display=open?'none':'');
  document.querySelectorAll('.open-player-name-field').forEach(el=>el.style.display=open?'':'none');
  document.querySelectorAll('.school-registration-field').forEach(el=>el.style.display=open?'none':'');
  document.querySelectorAll('.player-category-field').forEach(el=>el.style.display=open?'none':'');
  document.querySelectorAll('.open-registration-note').forEach(el=>el.style.display=open?'':'none');

  if(open){
    const pc=document.getElementById('playerCategory');
    const wc=document.getElementById('wizPlayerCategory');
    if(pc)pc.value='Open';
    if(wc)wc.value='Open';
  }
}

function playerRosterSecondary(p){
  if(isOpenIndividualTournament())return ratingText(p);
  const d=compactDelegationLabel(p)||p.school||'';
  return d ? `${d} · ${ratingText(p)}` : ratingText(p);
}


function cleanMiddleInitial(v){
  v=String(v||'').trim().replace(/\./g,'').toUpperCase();
  return v.slice(0,2);
}
function formatStructuredName(lastName,firstName,middleInitial){
  const last=String(lastName||'').trim();
  const first=String(firstName||'').trim();
  const mi=cleanMiddleInitial(middleInitial);
  if(!last && !first)return '';
  const mid=mi ? ` ${mi}.` : '';
  return last ? `${last.toUpperCase()}, ${first}${mid}`.trim() : `${first}${mid}`.trim();
}
function ensurePlayerStructuredName(p){
  if(!p)return p;
  if(typeof p.lastName==='undefined')p.lastName='';
  if(typeof p.firstName==='undefined')p.firstName='';
  if(typeof p.middleInitial==='undefined')p.middleInitial='';
  const structured=formatStructuredName(p.lastName,p.firstName,p.middleInitial);
  if(structured)p.name=structured;
  return p;
}
function rosterName(p){
  if(!p)return '';
  ensurePlayerStructuredName(p);
  return p.name||'';
}
function rosterTemplateRows(){
  if(isOpenIndividualTournament()){
    return [
      ['Name','Rating Status','Rating'],
      ['Magnus Carlsen','Rated','2830'],
      ['Juan Dela Cruz','NR','']
    ];
  }
  return [
    ['Last Name','First Name','Middle Initial','School ID','School','Rating Status','Rating','Category'],
    ['Averia','John Vincent','A','108661','San Pablo Suha ES','NR','','Elementary Boys'],
    ['Dela Cruz','Juan','P','','','Rated','1450','Secondary Boys']
  ];
}
function downloadRosterTemplate(){
  const rows=rosterTemplateRows();
  const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='Chess_Roster_Import_Template.csv';
  a.click();
  URL.revokeObjectURL(a.href);
}
function csvHeaderIndex(headers,candidates){
  const h=headers.map(normalizedHeader);
  for(const cand of candidates){
    const c=normalizedHeader(cand);
    let i=h.findIndex(x=>x===c);
    if(i>=0)return i;
    i=h.findIndex(x=>x.includes(c));
    if(i>=0)return i;
  }
  return -1;
}
async function importRosterCSV(event,fromWizard=false){
  const file=event.target.files?.[0];
  if(!file)return;
  try{
    const raw=await file.text();
    const lines=raw.split(/\r?\n/).filter(x=>x.trim());
    if(lines.length<2){alert('The roster file has no player rows.');return;}

    const headers=parseCSVLine(lines[0]);
    const iName=csvHeaderIndex(headers,['Name','Player Name','Full Name']);
    const iLast=csvHeaderIndex(headers,['Last Name','Surname','Family Name']);
    const iFirst=csvHeaderIndex(headers,['First Name','Given Name']);
    const iMI=csvHeaderIndex(headers,['Middle Initial','MI']);
    const iSchoolId=csvHeaderIndex(headers,['School ID','DepEd School ID']);
    const iSchool=csvHeaderIndex(headers,['School','School Name']);
    const iStatus=csvHeaderIndex(headers,['Rating Status','Status']);
    const iRating=csvHeaderIndex(headers,['Rating','Elo']);
    const iCategory=csvHeaderIndex(headers,['Category','Sex / Category','Sex']);

    const openScope=isOpenIndividualTournament();
    if(openScope){
      if(iName<0 && (iLast<0 || iFirst<0)){
        alert('Open Tournament roster CSV must contain a Name column, or Last Name and First Name columns.');
        return;
      }
    }else if(iLast<0 || iFirst<0){
      alert('School Tournament roster CSV must contain Last Name and First Name columns.');
      return;
    }

    if(!openScope && iSchoolId>=0){
      try{ await ensureSchoolDataLoaded(); }catch(e){}
    }

    let added=0;
    for(let lineNo=1;lineNo<lines.length;lineNo++){
      const v=parseCSVLine(lines[lineNo]);
      const directName=openScope && iName>=0 ? String(v[iName]||'').trim() : '';
      const last=iLast>=0?String(v[iLast]||'').trim():'';
      const first=iFirst>=0?String(v[iFirst]||'').trim():'';
      if(openScope ? (!directName&&!last&&!first) : (!last&&!first))continue;
      const mi=iMI>=0?cleanMiddleInitial(v[iMI]):'';
      const schoolId=!openScope && iSchoolId>=0?String(v[iSchoolId]||'').trim().replace(/\.0$/,''):'';
      let school=!openScope && iSchool>=0?String(v[iSchool]||'').trim():'';
      let town='',division='',region='';

      if(!openScope && schoolId){
        const s=BUILTIN_SCHOOLS[schoolId]||nationalSchoolById(schoolId)||await getImportedSchool(schoolId);
        if(s){
          if(!school)school=s.school||'';
          town=s.town||'';division=s.division||'';region=s.region||'';
        }
      }

      const status=iStatus>=0?String(v[iStatus]||'').trim().toUpperCase():'';
      const ratingVal=iRating>=0?String(v[iRating]||'').trim():'';
      const unrated=status==='NR'||status==='NON-RATED'||status==='UNRATED'||!ratingVal;
      const rating=unrated?0:(+ratingVal||0);

      state.players.push({
        id:uid(),
        lastName:openScope?'':last,firstName:openScope?'':first,middleInitial:openScope?'':mi,
        name:openScope?(directName||formatStructuredName(last,first,mi)):formatStructuredName(last,first,mi),
        schoolId,school,town,division,region,
        rating,unrated,
        team:'',
        category:openScope?(state.settings.tournamentCategory||'Open'):(iCategory>=0?(String(v[iCategory]||'Open').trim()||'Open'):'Open')
      });
      added++;
    }

    persist();renderAll();
    if(fromWizard){renderWizardRoster();renderWizardParticipantCountPanel();}
    alert(`${added} player(s) imported.`);
  }catch(err){
    alert('Could not import the roster CSV.');
  }finally{
    event.target.value='';
  }
}
function toggleWizardPlayerRating(){
  const rated=document.getElementById('wizPlayerRatingStatus')?.value==='rated';
  const wrap=document.getElementById('wizPlayerRatingWrap');
  if(wrap)wrap.style.display=rated?'':'none';
}
async function lookupWizardPlayerSchool(){ initWizardSchoolCascade(); }
function addWizardPlayer(){
  const openScope=isOpenIndividualTournament();
  const unrated=wizPlayerRatingStatus.value!=='rated';

  if(openScope){
    const name=document.getElementById('wizPlayerOpenName')?.value.trim()||'';
    if(!name){
      alert('Enter the player name.');
      return;
    }

    pushHistory('Add player');
    state.players.push({
      id:uid(),
      lastName:'',firstName:'',middleInitial:'',
      name,
      schoolId:'',school:'',town:'',division:'',region:'',
      rating:unrated?0:(+wizPlayerRating.value||0),
      unrated,team:'',
      category:state.settings.tournamentCategory||'Open'
    });

    wizPlayerOpenName.value='';
    wizPlayerRatingStatus.value='unrated';
    wizPlayerRating.value='1200';
    toggleWizardPlayerRating();
    persist();renderAll();renderWizardRoster();renderWizardParticipantCountPanel();
    return;
  }

  const last=wizPlayerLastName.value.trim();
  const first=wizPlayerFirstName.value.trim();
  const mi=cleanMiddleInitial(wizPlayerMiddleInitial.value);
  if(!last||!first){
    alert('Enter both Last Name and First Name.');
    return;
  }
  if(!wizPlayerRegion.value || !wizPlayerDivision.value || !wizPlayerTown.value || !wizPlayerSchoolId.value){
    alert('Select Region, Division/Province, Town/City, and School first.');
    return;
  }

  pushHistory('Add player');
  state.players.push({
    id:uid(),
    lastName:last,firstName:first,middleInitial:mi,
    name:formatStructuredName(last,first,mi),
    schoolId:wizPlayerSchoolId.value.trim(),
    school:wizPlayerSchool.value.trim(),
    town:wizPlayerTown.value.trim(),
    division:wizPlayerDivision.value.trim(),
    region:wizPlayerRegion.value.trim(),
    rating:unrated?0:(+wizPlayerRating.value||0),
    unrated,team:'',
    category:wizPlayerCategory.value
  });

  wizPlayerLastName.value='';wizPlayerFirstName.value='';wizPlayerMiddleInitial.value='';
  initWizardSchoolCascade(true);
  wizPlayerRatingStatus.value='unrated';wizPlayerRating.value='1200';wizPlayerCategory.value='Elementary Boys';
  toggleWizardPlayerRating();
  if(wizPlayerSchoolStatus)wizPlayerSchoolStatus.textContent='Select Region → Division/Province → Town/City → School / DepEd School ID.';
  persist();renderAll();renderWizardRoster();renderWizardParticipantCountPanel();
}
function removeWizardPlayer(id){
  if(state.rounds.length)return;
  state.players=state.players.filter(p=>p.id!==id);
  persist();renderAll();renderWizardRoster();renderWizardParticipantCountPanel();
}

function ratingText(p){ return p && p.unrated ? 'NR' : String(p?.rating ?? 0); }
function toggleRatingInput(){
  const unrated = document.getElementById('playerRatingStatus')?.value === 'unrated';
  const wrap = document.getElementById('playerRatingWrap');
  if(wrap) wrap.style.display = unrated ? 'none' : '';
}
function addPlayer(){
  const openScope=isOpenIndividualTournament();
  const unrated=playerRatingStatus.value==='unrated';

  if(openScope){
    const name=document.getElementById('playerOpenName')?.value.trim()||'';
    if(!name){alert('Enter the player name.');return;}

    state.players.push({
      id:uid(),
      lastName:'',firstName:'',middleInitial:'',
      name,
      schoolId:'',school:'',town:'',division:'',region:'',
      rating:unrated?0:(+playerRating.value||0),unrated,
      team:'',category:state.settings.tournamentCategory||'Open'
    });

    playerOpenName.value='';
    playerRatingStatus.value='unrated';
    playerRating.value='1200';
    toggleRatingInput();
    persist();renderAll();playerOpenName.focus();
    return;
  }

  const last=playerLastName.value.trim();
  const first=playerFirstName.value.trim();
  const mi=cleanMiddleInitial(playerMiddleInitial.value);
  if(!last||!first){alert('Enter both Last Name and First Name.');return;}
  if(!playerRegion.value || !playerDivision.value || !playerTown.value || !playerSchoolId.value){
    alert('Select Region, Division/Province, Town/City, and School first.');
    return;
  }

  state.players.push({
    id:uid(),
    lastName:last,firstName:first,middleInitial:mi,
    name:formatStructuredName(last,first,mi),
    schoolId:playerSchoolId.value.trim(),
    school:playerSchool.value.trim(),
    town:playerTown.value.trim(),
    division:playerDivision.value.trim(),
    region:playerRegion.value.trim(),
    rating:unrated?0:(+playerRating.value||0),unrated,
    team:'',category:playerCategory.value
  });

  playerLastName.value='';playerFirstName.value='';playerMiddleInitial.value='';
  initRosterSchoolCascade(true);
  playerRatingStatus.value='rated';playerRating.value='1200';playerCategory.value='Elementary Boys';
  toggleRatingInput();
  schoolLookupStatus.textContent='Select Region → Division/Province → Town/City → School / DepEd School ID.';
  persist();renderAll();playerLastName.focus();
}
function deletePlayer(id){
  if(state.rounds.length){alert('Players cannot be deleted after pairings have started. Reset the tournament or remove rounds first.');return;}
  const p=getPlayer(id);
  pushHistory(`Delete player${p?.name?`: ${p.name}`:''}`);
  state.players=state.players.filter(p=>p.id!==id);persist();renderAll();
}
function editPlayer(id){
  const p=getPlayer(id); if(!p)return;
  ensurePlayerStructuredName(p);

  if(isOpenIndividualTournament()){
    const name=prompt('Player Name:',p.name||''); if(name===null)return;
    const cleanName=String(name||'').trim();
    if(!cleanName){alert('Player name cannot be blank.');return;}
    const r=prompt('Rating (type NR for Non-Rated):',p.unrated?'NR':p.rating); if(r===null)return;

    p.name=cleanName;
    p.lastName='';p.firstName='';p.middleInitial='';
    p.schoolId='';p.school='';p.town='';p.division='';p.region='';
    p.unrated=String(r).trim().toUpperCase()==='NR'||String(r).trim()==='';
    p.rating=p.unrated?0:(+r||0);
    p.category=state.settings.tournamentCategory||'Open';
    persist();renderAll();
    return;
  }

  const last=prompt('Last Name / Surname:',p.lastName||''); if(last===null)return;
  const first=prompt('First Name:',p.firstName||''); if(first===null)return;
  const mi=prompt('Middle Initial:',p.middleInitial||''); if(mi===null)return;
  const r=prompt('Rating (type NR for Non-Rated):',p.unrated?'NR':p.rating); if(r===null)return;
  const sid=prompt('DepEd School ID:',p.schoolId||''); if(sid===null)return;
  const sch=prompt('School:',p.school||''); if(sch===null)return;
  const town=prompt('Town / Municipality / City:',p.town||''); if(town===null)return;
  const div=prompt('Division / Province:',p.division||''); if(div===null)return;
  const reg=prompt('Region:',p.region||''); if(reg===null)return;

  p.lastName=last.trim();
  p.firstName=first.trim();
  p.middleInitial=cleanMiddleInitial(mi);
  p.name=formatStructuredName(p.lastName,p.firstName,p.middleInitial)||p.name;
  p.unrated=String(r).trim().toUpperCase()==='NR';
  p.rating=p.unrated?0:(+r||0);
  p.schoolId=sid.trim();p.school=sch.trim();p.town=town.trim();
  p.division=div.trim();p.region=reg.trim();p.team='';
  persist();renderAll();
}
function sortPlayersByRating(){
  if(state.rounds.length){alert('Seeding cannot be changed after the tournament starts.');return;}
  state.players.sort((a,b)=>(Number(a.unrated)-Number(b.unrated))||b.rating-a.rating||a.name.localeCompare(b.name));persist();renderAll();
}
async function clearPlayers(){
  if(state.rounds.length){alert('Reset the tournament first because rounds already exist.');return;}
  if(await appConfirm('Remove all players from this tournament roster?',{title:'Clear Roster',confirmText:'Remove All'})){
    pushHistory('Clear player roster');
    state.players=[];persist();renderAll();showToast('Player roster cleared.','success');
  }
}
