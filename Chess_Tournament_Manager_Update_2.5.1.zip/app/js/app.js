// Chess Tournament Manager 2.0
// Common controller: save/navigation, tournament settings sync, tie-break UI.

function persist(){
  enforceStandardScoring(state);
  safeStorage.setItem('chessManagerAveria',JSON.stringify(state));
  if(state.settings?.tournamentStarted)saveActiveTournamentToLibrary();
  renderTournamentSwitcher();
  const x=document.getElementById('saveStatus');
  if(x){x.textContent='Saved';setTimeout(()=>x.textContent='Ready',900);}
  const top=document.getElementById('topSaveStatus');
  if(top){top.textContent='✓ Saved';setTimeout(()=>top.textContent='✓ Auto-saved',900);}
}
function saveNow(){syncSettings();persist();showToast('Tournament saved. You can reopen it from Main Menu → Saved Tournaments.','success','Saved');}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7);}
function currentRound(){return state.rounds[state.rounds.length-1] || null;}
function getPlayer(id){return state.players.find(p=>p.id===id);}
function goTab(tab){
  if(tab!=='pairings' && document.body.classList.contains('round-focus-mode')){
    document.body.classList.remove('round-focus-mode');
    if(typeof roundFocusMode!=='undefined')roundFocusMode=false;
    const focusBtn=document.getElementById('focusRoundBtn');
    if(focusBtn)focusBtn.textContent='⛶ Focus Mode';
  }
  const tournamentTabs=['dashboard','pairings','standings','tiebreaks','reports'];

  if(tournamentTabs.includes(tab) && !state.settings.tournamentStarted){
    beginNewTournament();
    return;
  }

  document.querySelectorAll('.section').forEach(s=>s.classList.toggle('active',s.id===tab));
  const activeNav = (tab==='notation'||tab==='standings') ? 'reports' : tab;
  document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===activeNav));
  const advBtn=document.getElementById('navAdvancedButton');
  if(advBtn)advBtn.classList.toggle('active',tab==='tiebreaks');

  const map={
    dashboard:['Setup','Tournament information and current status.'],
    players:['Players','Add, edit, or import the tournament roster.'],
    pairings:['Round','Generate pairings and encode the current round results.'],
    standings:['Ranking','Live ranking after recorded results.'],
    tiebreaks:['Advanced Ranking','Only use this if you want to change the ranking tie-break order.'],
    notation:['Print Sheets','Prepare printable chess notation sheets.'],
    reports:['Print','Preview pairings, round results, rankings, notation sheets, and reports before printing.']
  };
  const page=map[tab]||[tab,''];
  document.getElementById('pageTitle').textContent=page[0];
  const sub=document.getElementById('eventSubtitle');
  if(sub)sub.textContent=page[1];

  if(tab==='standings')renderStandings();
  if(tab==='pairings')renderPairings();
  if(tab==='reports')renderReports();
  if(tab==='tiebreaks')renderTieList();
  if(tab==='players' && !isOpenIndividualTournament())initRosterSchoolCascade();
}
document.getElementById('nav').addEventListener('click',e=>{const b=e.target.closest('button[data-tab]');if(b)goTab(b.dataset.tab)});


function tieBreakOptionHTML(selected){
  return Object.entries(TB_LABELS).map(([key,label]) =>
    `<option value="${key}" ${key===selected?'selected':''}>${esc(label)}</option>`
  ).join('');
}

function allTieBreakKeys(){
  return Object.keys(TB_LABELS);
}
function orderedTieBreakSlots(mode){
  const active=state.tieBreaksByMode?.[mode]||[];
  const defaults=cloneDefaultTB(mode);
  const extras=allTieBreakKeys().filter(x=>!active.includes(x)&&!defaults.includes(x));
  return [...active,...defaults.filter(x=>!active.includes(x)),...extras].slice(0,8);
}
function setTieBreakCount(count){
  for(let i=1;i<=8;i++){
    const cb=document.getElementById(`tbEn${i}`);
    if(cb)cb.checked=i<=count;
  }
  applyModeTieBreaks();
}
function setWizardTieBreakCount(count){
  for(let i=1;i<=8;i++){
    const cb=document.getElementById(`wizTbEn${i}`);
    if(cb)cb.checked=i<=count;
    updateWizardTieSlot(i,false);
  }
}
function updateWizardTieSlot(i,save=false){
  const cb=document.getElementById(`wizTbEn${i}`);
  const sel=document.getElementById(`wizTb${i}`);
  if(sel)sel.disabled=cb?!cb.checked:false;
  if(save && wizardFormat)saveWizardTieBreaks(wizardFormat);
}

function renderModeTieBreakSelectors(){
  if(!state.tieBreaksByMode)ensureTieBreakState();
  const m=state.settings.mode||'';
  const active=m?(state.tieBreaksByMode[m]||[]):[];
  const slots=m?orderedTieBreakSlots(m):[];

  state.tieBreaks=[...active];

  for(let i=1;i<=8;i++){
    const el=document.getElementById(`tb${i}`);
    const cb=document.getElementById(`tbEn${i}`);
    if(el){
      el.innerHTML=m
        ? tieBreakOptionHTML(slots[i-1]||allTieBreakKeys()[i-1]||'de')
        : '<option value="">Select tournament format first</option>';
      el.disabled=!m || !cb?.checked;
    }
    if(cb){
      cb.checked=!!m && i<=active.length;
      cb.disabled=!m || m==='knockout' || m==='team';
      if(el)el.disabled=cb.disabled || !cb.checked;
    }
  }

  const title=document.getElementById('modeTieBreakTitle');
  const help=document.getElementById('modeTieBreakHelp');
  if(title)title.textContent=`${modeName(m)} Tie-break Order`;
  if(help)help.textContent=(m==='knockout')
    ? 'Knockout advances players by game result; ranking tie-break order is not used.'
    : (m==='team')
      ? 'Team ranking uses its own Match Points / Board Points rules.'
      : `Check only the tie-breaks used by this event. ${active.length} tie-break${active.length===1?' is':'s are'} currently enabled.`;

  const advTitle=document.getElementById('advancedTieTitle');
  if(advTitle)advTitle.textContent=`Tie-break Priority — ${modeName(m)}`;

  renderFormatTieBreakSummary();
  updateTieBreakVisibility();
}
function renderFormatTieBreakSummary(){
  const el=document.getElementById('formatTieBreakSummary');
  if(!el || !state.tieBreaksByMode)return;
  const short=x=>TB_LABELS[x]?.replace(' – Direct Encounter','').replace('Number of ','')||x;
  const line=(m)=>{
    const a=state.tieBreaksByMode[m]||[];
    return `<b>${modeName(m)} (${a.length} active):</b> ${a.length?a.map(short).join(' → '):'Points only / no ranking tie-break'}`;
  };
  el.innerHTML=`Saved separately: &nbsp; ${line('swiss')}<br>${line('roundrobin')}<br>${line('knockout')}`;
}
function applyModeTieBreaks(){
  const m=state.settings.mode||'';
  if(!m || m==='knockout'||m==='team')return;

  const selected=[];
  for(let i=1;i<=8;i++){
    const cb=document.getElementById(`tbEn${i}`);
    const sel=document.getElementById(`tb${i}`);
    if(sel)sel.disabled=!cb?.checked;
    if(cb?.checked && sel?.value && !selected.includes(sel.value))selected.push(sel.value);
  }

  state.tieBreaksByMode[m]=selected;
  state.tieBreaks=[...selected];

  persist();
  renderTieList();
  renderStandings();
  renderPairingsRanking();
  renderDashboard();
  renderReports();
  renderModeTieBreakSelectors();
}
function updateTieBreakVisibility(){
  const box=document.getElementById('modeTieBreakBox');
  if(!box)return;
  const m=document.getElementById('mode')?.value||state.settings.mode||'';
  const selects=box.querySelectorAll('select');
  const advancedBtn=box.querySelector('button');
  if(m==='knockout'||m==='team'){
    selects.forEach(x=>x.disabled=true);
    if(advancedBtn)advancedBtn.disabled=true;
    box.style.opacity='.68';
  }else{
    selects.forEach(x=>x.disabled=false);
    if(advancedBtn)advancedBtn.disabled=false;
    box.style.opacity='1';
  }
}

function syncSettings(){
  state.settings.name=document.getElementById('eventName').value||'Untitled Tournament';

  const modeEl=document.getElementById('mode');
  const newMode=modeEl?.value||'';
  const oldMode=state.settings.mode||'';

  if(!state.tieBreaksByMode)ensureTieBreakState();

  // Mode is selected only by the New Tournament format gate.
  // A blank selector must remain blank; never default to Swiss.
  if(newMode){
    if(oldMode && newMode!==oldMode && state.tieBreaksByMode[oldMode]){
      state.tieBreaksByMode[oldMode]=[...(state.tieBreaks||[])];
    }
    state.settings.mode=newMode;
    state.tieBreaks=[...(state.tieBreaksByMode[newMode]||cloneDefaultTB(newMode))];
  }else if(!state.settings.tournamentStarted){
    state.settings.mode='';
    state.tieBreaks=[];
  }

  state.settings.meetLevel=document.getElementById('meetLevel').value;
  state.settings.rounds=Math.max(1,+document.getElementById('rounds').value||1);
  state.settings.date=document.getElementById('eventDate').value;
  state.settings.school=document.getElementById('school').value;
  state.settings.venue=document.getElementById('venue').value;
  state.settings.chiefArbiter=document.getElementById('chiefArbiter').value;
  state.settings.tournamentDirector=document.getElementById('tournamentDirector').value;
  state.settings.timeControl=document.getElementById('timeControl').value;
  enforceStandardScoring(state);

  persist();
  renderAll();
  renderModeTieBreakSelectors();
}
function hydrateInputs(){
  const s=state.settings;
  eventName.value=s.name; mode.value=s.tournamentStarted?(s.mode||''):''; meetLevel.value=s.meetLevel||'municipal'; rounds.value=s.rounds; eventDate.value=s.date||''; school.value=s.school||''; venue.value=s.venue||''; chiefArbiter.value=s.chiefArbiter||s.arbiter||''; tournamentDirector.value=s.tournamentDirector||'John Vincent A. Averia'; timeControl.value=s.timeControl||'';
  applyTournamentScopeUI?.();
  enforceStandardScoring(state);
}

// Nationwide DepEd school baseline embedded for offline lookup.
// Source dataset: SY 2020-2021 DepEd Schools Masterlist (60,924 rows).
// Fields kept in this app: School ID, School Name, Municipality/City, Division, Region.


function applyEasyFlowRedesign(){
  try{
    const savedHelp=document.querySelector('.saved-tournaments-head .help');
    if(savedHelp && !savedHelp.dataset.easyFlow){
      savedHelp.dataset.easyFlow='1';
      savedHelp.innerHTML='Open a saved event when you want to continue working. <b>Nothing opens automatically at startup.</b>';
    }

    const emptySaved=document.querySelector('#savedTournamentList');
    if(emptySaved && !emptySaved.children.length){
      emptySaved.innerHTML='<div class="home-empty-note">No saved tournaments yet. Click <b>Start New Tournament</b> to begin.</div>';
    }

    const title=document.getElementById('pageTitle');
    if(title && !state.settings?.tournamentStarted){
      title.textContent='Tournament';
    }
  }catch(e){
    console.error('Easy Flow redesign failed',e);
  }
}

function updateWorkflowBanner(){
  const banner=document.getElementById('workflowBanner');
  if(!banner)return;
  const steps=[...banner.querySelectorAll('.workflow-step')];
  steps.forEach(x=>x.classList.remove('done','active'));

  const started=!!state.settings?.tournamentStarted;
  const playerCount=state.players?.length||0;
  const rounds=state.rounds?.length||0;
  const current=document.querySelector('.section.active')?.id||'dashboard';

  if(steps[0]) steps[0].classList.add('done');
  if(playerCount>0 && steps[1]) steps[1].classList.add('done');
  if(rounds>0 && steps[2]) steps[2].classList.add('done');
  if(rounds>0 && current==='pairings' && steps[2]) steps[2].classList.add('active');
  if(current==='players' && steps[1]) steps[1].classList.add('active');
  if(current==='dashboard' && steps[0]) steps[0].classList.add('active');
  if((current==='reports' || current==='standings') && steps[3]) steps[3].classList.add('active');
  if(started && rounds>0 && steps[3] && current!=='pairings' && current!=='players' && current!=='dashboard'){
    // keep final step active only on print/ranking views
  }
}


function openAdvancedTools(targetTab=''){
  if(targetTab){
    goTab(targetTab);
    return;
  }
  const modal=document.getElementById('advancedToolsModal');
  if(!modal)return;
  modal.classList.add('show');
  modal.setAttribute('aria-hidden','false');
  document.body.classList.add('settings-modal-open');
}
function closeAdvancedTools(){
  const modal=document.getElementById('advancedToolsModal');
  if(!modal)return;
  modal.classList.remove('show');
  modal.setAttribute('aria-hidden','true');
  if(!document.getElementById('settingsModal')?.classList.contains('show')){
    document.body.classList.remove('settings-modal-open');
  }
}

// ===== CatQue Print Preview v2.4.3 — Smart Auto Fit =====
let printPreviewState={
  frame:null,
  pages:1,
  current:1,
  pageHeight:1123,
  orientation:'portrait',
  title:'Document Preview',
  autoFit:true,
  scale:1,
  minScale:.72,
  fitOnePage:false,
  bodyClass:''
};

function clonePrintableHTML(selector){
  const source=document.querySelector(selector);
  if(!source)return '';
  const clone=source.cloneNode(true);
  const sourceFields=source.querySelectorAll('input,select,textarea');
  const cloneFields=clone.querySelectorAll('input,select,textarea');
  sourceFields.forEach((el,i)=>{
    const c=cloneFields[i];
    if(!c)return;
    if(el.tagName==='SELECT'){
      [...c.options].forEach((opt,j)=>opt.selected=el.options[j]?.selected||false);
    }else if(el.tagName==='TEXTAREA'){
      c.textContent=el.value;
    }else{
      c.setAttribute('value',el.value);
      if(el.checked)c.setAttribute('checked','checked');
      else c.removeAttribute('checked');
    }
  });
  clone.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));
  return clone.outerHTML;
}

function previewPageGeometry(orientation='portrait'){
  const landscape=orientation==='landscape';
  const width=landscape?1123:794;
  const height=landscape?794:1123;
  // approximately 10–12mm print margins at 96dpi
  return {width,height,top:42,right:38,bottom:48,left:38};
}

function buildPreviewDocument(html,{orientation='portrait',bodyClass='',title='Document Preview'}={}){
  const base=esc(document.baseURI);
  const g=previewPageGeometry(orientation);
  const pageRule=orientation==='landscape'?'A4 landscape':'A4 portrait';
  return `<!doctype html><html><head>
    <meta charset="UTF-8"><base href="${base}">
    <link rel="stylesheet" href="css/styles.css">
    <style>
      :root{color-scheme:light}
      html,body{margin:0;background:#cfd5dc!important;color:#000!important;font-family:Arial,Helvetica,sans-serif!important}
      body{padding:24px 0 48px!important;min-width:${g.width+48}px}
      #cqPreviewPaper{position:relative;box-sizing:border-box;width:${g.width}px;min-height:${g.height}px;margin:0 auto;background:#fff;color:#000;padding:${g.top}px ${g.right}px ${g.bottom}px ${g.left}px;box-shadow:0 14px 44px rgba(0,0,0,.22);overflow:visible}
      #cqPreviewContent{position:relative;z-index:2;width:100%;min-height:1px;transform-origin:top left}
      #cqPreviewMarkers{position:absolute;inset:0;pointer-events:none;z-index:3}
      .cq-page-marker{position:absolute;left:0;right:0;border-top:2px dashed rgba(207,50,50,.55);height:0}
      .cq-page-marker span{position:absolute;right:10px;top:-22px;background:#fff3f3;color:#a22626;border:1px solid #e3b1b1;border-radius:999px;padding:3px 8px;font:700 10px Arial}
      .print-pairing-sheet,.print-standings-sheet,.print-round-results-sheet{display:block!important}
      .print-sheet,.report-box{box-shadow:none!important;max-width:none!important;margin:0!important;border-radius:0!important}
      button,.no-print{display:none!important}

      /* Smart compacting before scaling keeps text larger and improves one-sheet output. */
      body.cq-smart-fit .print-pairing-header h1{font-size:17pt!important;margin-bottom:2px!important}
      body.cq-smart-fit .print-pairing-header .category{font-size:10pt!important;margin:1px 0!important}
      body.cq-smart-fit .print-pairing-header .round-title{font-size:12pt!important;margin-top:4px!important}
      body.cq-smart-fit .print-meta{margin:6px 0 7px!important;padding:4px 0!important;gap:1px 16px!important;font-size:8.5pt!important;line-height:1.22!important}
      body.cq-smart-fit .print-pairing-table{font-size:8.6pt!important}
      body.cq-smart-fit .print-pairing-table th{font-size:7.8pt!important;padding:3px 4px!important}
      body.cq-smart-fit .print-pairing-table td{padding:3px 4px!important;line-height:1.16!important}
      body.cq-smart-fit .print-pairing-table .delegation{font-size:7.5pt!important;line-height:1.1!important}
      body.cq-smart-fit .print-signatures{margin-top:18px!important;gap:42px!important;font-size:8.5pt!important}
      body.cq-smart-fit .round-results-summary{margin:5px 0 7px!important;gap:4px!important}
      body.cq-smart-fit .round-results-summary>div{padding:4px 3px!important}
      body.cq-smart-fit .round-results-summary b{font-size:12px!important}
      body.cq-smart-fit .round-results-summary span{font-size:7pt!important}
      body.cq-smart-fit .catque-print-footer{margin-top:6px!important;padding-top:4px!important;font-size:6.5pt!important}
      body.cq-smart-fit .fs-header{margin-bottom:5px!important}
      body.cq-smart-fit .fs-meta{margin:5px 0 7px!important}
      body.cq-smart-fit .fs-table th,body.cq-smart-fit .fs-table td{padding-top:3px!important;padding-bottom:3px!important}

      /* Tournament Report smart-fit rules */
      body.cq-smart-fit.printing-report .report-box{padding:0!important;font-size:7.4pt!important;line-height:1.12!important}
      body.cq-smart-fit.printing-report .report-box h2{font-size:14pt!important;margin:0 0 2px!important;line-height:1.05!important}
      body.cq-smart-fit.printing-report .report-box h3{font-size:9.5pt!important;margin:7px 0 4px!important;line-height:1.08!important}
      body.cq-smart-fit.printing-report .report-box h4{font-size:8.2pt!important;margin:3px 0 2px!important;line-height:1.05!important}
      body.cq-smart-fit.printing-report .report-box hr{margin:5px 0!important}
      body.cq-smart-fit.printing-report .report-box table{font-size:6.9pt!important;table-layout:fixed!important}
      body.cq-smart-fit.printing-report .report-box th{font-size:6.2pt!important;padding:2px 3px!important;line-height:1.05!important}
      body.cq-smart-fit.printing-report .report-box td{padding:2px 3px!important;line-height:1.08!important;overflow-wrap:anywhere!important}
      body.cq-smart-fit.printing-report .cq-report-rounds-grid{display:grid!important;grid-template-columns:1fr 1fr!important;gap:5px 8px!important;align-items:start!important}
      body.cq-smart-fit.printing-report .cq-report-round{break-inside:avoid!important;page-break-inside:avoid!important}
      body.cq-smart-fit.printing-report .cq-report-footer{margin-top:6px!important;font-size:6pt!important}
      body.cq-smart-fit.printing-report .cq-report-heading{margin-top:7px!important}

      @page{size:${pageRule};margin:12mm 10mm 14mm}
      @media print{
        html,body{background:#fff!important;padding:0!important;min-width:0!important}
        #cqPreviewPaper{width:auto!important;min-height:0!important;margin:0!important;padding:0!important;box-shadow:none!important;overflow:visible!important}
        #cqPreviewMarkers{display:none!important}
        #cqPreviewContent{width:auto!important}
      }
    </style>
    <title>${esc(title)}</title>
  </head><body class="${esc(bodyClass)}"><div id="cqPreviewPaper"><div id="cqPreviewContent">${html}</div><div id="cqPreviewMarkers"></div></div></body></html>`;
}

function isSmartOnePageDocument(bodyClass=''){
  return /printing-(pairings|round-results|standings|report|notation)/.test(String(bodyClass||''));
}

function printPreviewScaleText(scale=1){
  return `${Math.round((Number(scale)||1)*100)}%`;
}

function updatePrintPreviewFitUI(message=''){
  const status=document.getElementById('printPreviewFitStatus');
  const btn=document.getElementById('printPreviewFitToggle');
  if(status){
    if(message)status.textContent=message;
    else status.textContent=printPreviewState.autoFit?`Auto Fit ${printPreviewScaleText(printPreviewState.scale)}`:'100% Scale';
  }
  if(btn)btn.textContent=printPreviewState.autoFit?'Auto Fit: ON':'Auto Fit: OFF';
}

function openPrintPreview({title='Document Preview',selector,orientation='portrait',bodyClass='',autoFit=null,minScale=null}={}){
  const modal=document.getElementById('printPreviewModal');
  const frame=document.getElementById('printPreviewFrame');
  if(!modal||!frame)return;
  const html=clonePrintableHTML(selector);
  if(!html){showToast('The printable layout could not be prepared.','error','Print Preview');return;}

  const smartDefault=autoFit===null?isSmartOnePageDocument(bodyClass):!!autoFit;
  let smartMin=minScale;
  if(smartMin==null){
    if(/printing-report/.test(bodyClass))smartMin=.58;
    else if(/printing-standings/.test(bodyClass))smartMin=.66;
    else if(/printing-notation/.test(bodyClass))smartMin=.70;
    else smartMin=.72;
  }
  smartMin=Math.max(.55,Math.min(1,Number(smartMin)||.72));

  printPreviewState={
    frame,pages:1,current:1,
    pageHeight:previewPageGeometry(orientation).height,
    orientation,title,
    autoFit:smartDefault,
    scale:1,
    minScale:smartMin,
    fitOnePage:false,
    bodyClass
  };
  document.getElementById('printPreviewTitle').textContent=title;
  document.getElementById('printPreviewInfo').textContent=`A4 • ${orientation==='landscape'?'Landscape':'Portrait'} • Calculating pages…`;
  document.getElementById('printPreviewPageCount').textContent='Calculating…';
  document.getElementById('printPreviewCurrentPage').textContent='Page 1 of 1';
  updatePrintPreviewFitUI(smartDefault?'Auto Fit…':'100% Scale');
  modal.classList.add('show');
  modal.setAttribute('aria-hidden','false');
  document.body.classList.add('print-preview-open');

  frame.onload=()=>{
    setTimeout(()=>calculatePrintPreviewPages(),100);
    try{
      frame.contentDocument?.fonts?.ready?.then(()=>setTimeout(calculatePrintPreviewPages,50));
      frame.contentWindow?.addEventListener('scroll',updatePrintPreviewCurrentPage,{passive:true});
    }catch(e){}
  };
  frame.srcdoc=buildPreviewDocument(html,{orientation,bodyClass,title});
}

function resetPreviewContentScale(doc){
  const content=doc?.getElementById('cqPreviewContent');
  if(!content)return;
  content.style.zoom='1';
  content.style.width='100%';
  doc.body?.classList.remove('cq-smart-fit');
}

function measurePreviewContent(content){
  if(!content)return {height:0,width:0};
  const rect=content.getBoundingClientRect();
  const zoom=Math.max(.1,parseFloat(content.style.zoom)||1);
  return {
    height:Math.max((content.scrollHeight||0)*zoom,rect.height||0),
    width:Math.max((content.scrollWidth||0)*zoom,rect.width||0)
  };
}

function applySmartPrintFit(doc,g){
  const content=doc?.getElementById('cqPreviewContent');
  if(!content)return {scale:1,fitOnePage:false};

  resetPreviewContentScale(doc);
  const smartDocument=isSmartOnePageDocument(printPreviewState.bodyClass);
  if(printPreviewState.autoFit && smartDocument)doc.body?.classList.add('cq-smart-fit');

  // Measure the compact but unscaled document first.
  const usableH=Math.max(200,g.height-g.top-g.bottom);
  const usableW=Math.max(200,g.width-g.left-g.right);
  let natural=measurePreviewContent(content);
  let scale=1;
  let fitOnePage=false;

  if(printPreviewState.autoFit){
    const heightScale=natural.height>0?usableH/natural.height:1;
    const widthScale=natural.width>0?usableW/natural.width:1;
    const rawNeeded=Math.min(1,heightScale,widthScale);
    const needed=rawNeeded>=1?1:rawNeeded*.985;

    if(needed>=printPreviewState.minScale){
      scale=Math.min(1,needed);
      fitOnePage=true;
    }else if(smartDocument){
      // Never make official result sheets unreadably tiny just to claim one page.
      // Use the minimum readable scale and allow additional pages.
      scale=printPreviewState.minScale;
    }else{
      scale=1;
    }
  }

  content.style.zoom=String(scale);
  // A tiny delayed re-measure after zoom catches table/text reflow in Chromium.
  printPreviewState.scale=scale;
  printPreviewState.fitOnePage=fitOnePage;
  return {scale,fitOnePage};
}

function calculatePrintPreviewPages(){
  const frame=printPreviewState.frame;
  const doc=frame?.contentDocument;
  if(!doc)return;
  const content=doc.getElementById('cqPreviewContent');
  const paper=doc.getElementById('cqPreviewPaper');
  const markers=doc.getElementById('cqPreviewMarkers');
  if(!content||!paper||!markers)return;

  const g=previewPageGeometry(printPreviewState.orientation);
  const usable=Math.max(200,g.height-g.top-g.bottom);
  applySmartPrintFit(doc,g);

  // Re-measure after auto-fit has been applied.
  const measured=measurePreviewContent(content);
  const contentHeight=measured.height;
  let pages=Math.max(1,Math.ceil(contentHeight/usable));
  if(printPreviewState.fitOnePage)pages=1;

  printPreviewState.pages=pages;
  printPreviewState.pageHeight=g.height;
  paper.style.minHeight=`${pages*g.height}px`;
  markers.innerHTML='';
  for(let i=1;i<pages;i++){
    const line=doc.createElement('div');
    line.className='cq-page-marker';
    line.style.top=`${i*g.height}px`;
    line.innerHTML=`<span>Page ${i+1}</span>`;
    markers.appendChild(line);
  }

  const pageText=`${pages} page${pages===1?'':'s'}`;
  const scaleText=printPreviewScaleText(printPreviewState.scale);
  document.getElementById('printPreviewPageCount').textContent=pageText;

  let fitDescription='100% scale';
  if(printPreviewState.autoFit && printPreviewState.fitOnePage){
    fitDescription=`Auto Fit ${scaleText} • fitted to 1 sheet`;
    updatePrintPreviewFitUI(`✓ Fits 1 sheet · ${scaleText}`);
  }else if(printPreviewState.autoFit && printPreviewState.scale<.999){
    fitDescription=`Auto Fit ${scaleText} • kept readable`;
    updatePrintPreviewFitUI(`Auto Fit ${scaleText}`);
  }else{
    updatePrintPreviewFitUI('100% Scale');
  }
  document.getElementById('printPreviewInfo').textContent=`A4 • ${printPreviewState.orientation==='landscape'?'Landscape':'Portrait'} • ${pageText} • ${fitDescription}`;
  document.getElementById('printPreviewCurrentPage').textContent=`Page 1 of ${pages}`;
  printPreviewState.current=1;
  updatePrintPreviewCurrentPage();
}

function togglePrintPreviewAutoFit(){
  printPreviewState.autoFit=!printPreviewState.autoFit;
  printPreviewState.scale=1;
  printPreviewState.fitOnePage=false;
  calculatePrintPreviewPages();
}

function updatePrintPreviewCurrentPage(){
  const frame=printPreviewState.frame;
  if(!frame)return;
  let y=0;
  try{y=frame.contentWindow.scrollY||frame.contentDocument.documentElement.scrollTop||0;}catch(e){}
  const current=Math.max(1,Math.min(printPreviewState.pages,Math.floor(y/printPreviewState.pageHeight)+1));
  printPreviewState.current=current;
  const el=document.getElementById('printPreviewCurrentPage');
  if(el)el.textContent=`Page ${current} of ${printPreviewState.pages}`;
}

function scrollPrintPreviewToPage(page){
  const frame=printPreviewState.frame;
  if(!frame)return;
  const target=Math.max(1,Math.min(printPreviewState.pages,page));
  try{frame.contentWindow.scrollTo({top:(target-1)*printPreviewState.pageHeight,behavior:'smooth'});}catch(e){}
}
function printPreviewPreviousPage(){scrollPrintPreviewToPage(printPreviewState.current-1)}
function printPreviewNextPage(){scrollPrintPreviewToPage(printPreviewState.current+1)}

function printPreviewNow(){
  const frame=printPreviewState.frame;
  if(!frame)return;
  try{
    frame.contentWindow.focus();
    frame.contentWindow.print();
  }catch(e){showToast('Could not open the Windows print dialog.','error','Print Preview')}
}

function closePrintPreview(){
  const modal=document.getElementById('printPreviewModal');
  const frame=document.getElementById('printPreviewFrame');
  if(modal){modal.classList.remove('show');modal.setAttribute('aria-hidden','true');}
  if(frame)frame.srcdoc='';
  document.body.classList.remove('print-preview-open');
}

function previewNotationSheet(){
  buildNotationGrid?.([]);
  openPrintPreview({
    title:'Notation Sheet Preview',
    selector:'#notation .print-sheet',
    orientation:'portrait',
    bodyClass:'printing-notation',
    autoFit:true,
    minScale:.70
  });
}

function previewTournamentReport(){
  renderReports();
  openPrintPreview({
    title:'Tournament Report Preview',
    selector:'#reportBox',
    orientation:'portrait',
    bodyClass:'printing-report',
    autoFit:true,
    minScale:.58
  });
}
