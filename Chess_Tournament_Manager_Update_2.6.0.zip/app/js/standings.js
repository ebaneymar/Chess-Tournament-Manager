// Chess Tournament Manager 2.0
// Standings and tie-break logic: BH, BH-C1, BH-M1, BH-M2, SB, DE, etc.

function resultScoreForPlayer(game,playerId){return gameAward(game,playerId);}
function scheduledRoundsForTieBreak(){return Math.max(state.rounds.length,+state.settings.rounds||state.rounds.length||1);}
function swissRoundDrawValue(){return state.settings.mode==='swiss'&&state.settings.swissVariant==='double'?1:0.5;}
function playerRoundRecord(playerId,rnd){
  const mine=(rnd?.games||[]).filter(g=>g.white===playerId||g.black===playerId);
  if(!mine.length)return {kind:'none',award:0,opponent:null,played:false,vur:true};
  const bye=mine.find(g=>g.bye);
  if(bye){
    if(state.settings.mode==='roundrobin')return {kind:'rr-sitout',award:0,opponent:null,played:false,vur:false};
    return {kind:bye.byeType==='requested'?'requested':'pab',award:byePointsForGame(bye),opponent:null,played:false,vur:true};
  }
  const opponent=mine[0].white===playerId?mine[0].black:mine[0].white;
  const doubleMode=state.settings.mode==='swiss'&&state.settings.swissVariant==='double';
  if(doubleMode){
    const played=mine.some(g=>isOverTheBoardResult(g.result));
    const award=mine.reduce((a,g)=>a+gameAward(g,playerId),0);
    if(played)return {kind:'played',award,opponent,played:true,vur:false};
    if(mine.some(g=>isForfeitResult(g.result)))return {kind:award>0?'forfeit-win':'forfeit-loss',award,opponent,played:false,vur:true};
    return {kind:'unplayed',award,opponent,played:false,vur:true};
  }
  const g=mine[0],award=gameAward(g,playerId);
  if(isOverTheBoardResult(g.result))return {kind:'played',award,opponent,played:true,vur:false};
  if(isForfeitResult(g.result))return {kind:award>0?'forfeit-win':'forfeit-loss',award,opponent,played:false,vur:true};
  return {kind:'unplayed',award,opponent,played:false,vur:true};
}
function requestedByeIsCategory5(playerId,roundIndex){
  for(let i=roundIndex+1;i<state.rounds.length;i++){
    const rr=playerRoundRecord(playerId,state.rounds[i]);
    if(rr.kind==='played'||rr.kind==='forfeit-win'||rr.kind==='forfeit-loss'||rr.kind==='pab')return false;
  }
  return true;
}
function adjustedScoreForOpponents(playerId){
  const h=playerHistory();let score=h[playerId]?.score||0;
  state.rounds.forEach((rnd,i)=>{
    const rr=playerRoundRecord(playerId,rnd);
    if(rr.kind==='requested'&&requestedByeIsCategory5(playerId,i))score+=swissRoundDrawValue()-rr.award;
  });
  return score;
}
function buchholzContributions(playerId){
  const own=playerHistory()[playerId]?.score||0;
  const scheduled=scheduledRoundsForTieBreak(), drawDummy=swissRoundDrawValue()*scheduled;
  return state.rounds.map((rnd,i)=>{
    const rr=playerRoundRecord(playerId,rnd);
    if(rr.played&&rr.opponent)return {value:adjustedScoreForOpponents(rr.opponent),vur:false,kind:'played'};
    if((rr.kind==='forfeit-win'||rr.kind==='forfeit-loss')&&rr.opponent){
      return {value:Math.min(own,adjustedScoreForOpponents(rr.opponent)),vur:true,kind:rr.kind};
    }
    return {value:Math.min(own,drawDummy),vur:true,kind:rr.kind};
  });
}
function cutBuchholz(values,lowCuts=0,highCuts=0){
  const a=values.map(x=>({...x}));
  for(let k=0;k<lowCuts&&a.length;k++){
    const pool=a.map((x,i)=>({x,i})).filter(z=>z.x.vur);const candidates=pool.length?pool:a.map((x,i)=>({x,i}));
    const cut=candidates.sort((u,v)=>u.x.value-v.x.value)[0];a.splice(cut.i,1);
  }
  for(let k=0;k<highCuts&&a.length;k++){
    let idx=0;for(let i=1;i<a.length;i++)if(a[i].value>a[idx].value)idx=i;a.splice(idx,1);
  }
  return a.reduce((sum,x)=>sum+x.value,0);
}
function directEncounterOpponentScores(playerId,tiedIds){
  const perOpp=new Map();
  for(const rnd of state.rounds){
    for(const g of rnd.games){
      if(g.bye||!(g.white===playerId||g.black===playerId))continue;
      const opp=g.white===playerId?g.black:g.white;if(!tiedIds.includes(opp)||opp===playerId)continue;
      let include=false;
      if(state.settings.mode==='roundrobin')include=!!g.result;
      else if(state.settings.mode==='swiss'&&state.settings.swissVariant==='double'&&g.matchId){
        const mg=rnd.games.filter(x=>x.matchId===g.matchId&&!x.bye);
        include=mg.some(x=>isOverTheBoardResult(x.result)); // a single forfeit is treated as played when the match is regular
      }else include=isOverTheBoardResult(g.result);
      if(!include)continue;
      if(!perOpp.has(opp))perOpp.set(opp,[]);perOpp.get(opp).push(gameAward(g,playerId));
    }
  }
  return perOpp;
}
function directEncounterScore(playerId,tiedIds){
  let total=0;const perOpp=directEncounterOpponentScores(playerId,tiedIds);
  for(const scores of perOpp.values())total+=scores.reduce((a,b)=>a+b,0)/scores.length;
  return total;
}
function resolveDirectEncounterGroup(ids){
  if(ids.length<=1)return [ids];
  const perPlayer=new Map(ids.map(id=>[id,directEncounterOpponentScores(id,ids)]));
  const met=(a,b)=>perPlayer.get(a)?.has(b);
  const allMet=ids.every((a,i)=>ids.slice(i+1).every(b=>met(a,b)&&met(b,a)));
  const score=new Map(ids.map(id=>[id,directEncounterScore(id,ids)]));
  if(allMet){
    const ordered=[...ids].sort((a,b)=>score.get(b)-score.get(a));
    const parts=[];for(const id of ordered){const last=parts.at(-1);if(!last||score.get(last[0])!==score.get(id))parts.push([id]);else last.push(id);}
    if(parts.length===1)return [ids];
    return parts.flatMap(part=>part.length>1?resolveDirectEncounterGroup(part):[part]);
  }
  // FIDE DE 6.3: in a Swiss, rank a participant first if they remain alone
  // at the top regardless of every possible result of the missing direct encounters.
  if(state.settings.mode==='swiss'){
    const maxPossible=new Map(ids.map(id=>{
      const missing=ids.filter(o=>o!==id&&!met(id,o)).length;
      return [id,(score.get(id)||0)+missing];
    }));
    const guaranteed=ids.filter(id=>ids.every(other=>other===id||(score.get(id)||0)>(maxPossible.get(other)||0)));
    if(guaranteed.length===1){
      const first=guaranteed[0],rest=ids.filter(x=>x!==first);
      return [[first],...resolveDirectEncounterGroup(rest)];
    }
  }
  return [ids];
}
function tiebreakValues(){
  const h=playerHistory(),vals={};
  for(const p of state.players){
    const ph=h[p.id],bc=buchholzContributions(p.id);
    const tiedIds=state.players.filter(x=>(h[x.id]?.score||0)===ph.score).map(x=>x.id);
    let sb=0;
    state.rounds.forEach((rnd,i)=>{
      const rr=playerRoundRecord(p.id,rnd);
      if(rr.played&&rr.opponent)sb+=rr.award*adjustedScoreForOpponents(rr.opponent);
      else if(rr.kind!=='none'&&rr.kind!=='rr-sitout'){
        const dummy=(rr.opponent&&rr.kind.startsWith('forfeit'))?Math.min(ph.score,adjustedScoreForOpponents(rr.opponent)):Math.min(ph.score,swissRoundDrawValue()*scheduledRoundsForTieBreak());
        sb+=rr.award*dummy;
      }
    });
    vals[p.id]={score:ph.score,de:directEncounterScore(p.id,tiedIds),buchholz:cutBuchholz(bc),buchholzCut1:cutBuchholz(bc,1,0),buchholzMedian1:cutBuchholz(bc,1,1),buchholzMedian2:cutBuchholz(bc,2,2),sb,wins:ph.wins,blackWins:ph.blackWins,cumulative:ph.roundScores.reduce((a,b)=>a+b,0),rating:p.unrated?-1:p.rating};
  }
  return vals;
}
function partitionByScalar(groups,tb,vals){
  const out=[];
  for(const group of groups){
    if(group.length<=1){out.push(group);continue;}
    const ordered=[...group].sort((a,b)=>(vals[b]?.[tb]??0)-(vals[a]?.[tb]??0));
    const parts=[];for(const id of ordered){const last=parts.at(-1);if(!last||(vals[last[0]]?.[tb]??0)!==(vals[id]?.[tb]??0))parts.push([id]);else last.push(id);}out.push(...parts);
  }
  return out;
}
function standings(){
  const vals=tiebreakValues(),rosterIndex=new Map(state.players.map((p,i)=>[p.id,i]));
  const byScore=new Map();
  for(const p of state.players){const sc=vals[p.id]?.score||0;if(!byScore.has(sc))byScore.set(sc,[]);byScore.get(sc).push(p.id);}
  const scoreKeys=[...byScore.keys()].sort((a,b)=>b-a),resolved=[];
  for(const score of scoreKeys){
    let groups=[byScore.get(score)];
    for(const tb of activeRankingTieBreaks()){
      const next=[];
      for(const g of groups){if(g.length<=1)next.push(g);else if(tb==='de')next.push(...resolveDirectEncounterGroup(g));else next.push(...partitionByScalar([g],tb,vals));}
      groups=next;
    }
    resolved.push(...groups);
  }
  const arr=[];let place=1;
  for(const group of resolved){
    group.sort((a,b)=>(rosterIndex.get(a)||0)-(rosterIndex.get(b)||0));
    for(const id of group){const p=getPlayer(id);arr.push({...p,...vals[id],rank:place,tied:group.length>1});}
    place+=group.length;
  }
  return arr;
}
function tieBreakExplanationHTML(playerId){
  const p=getPlayer(playerId);if(!p)return '<div class="empty">Player not found.</div>';
  const v=tiebreakValues()[playerId],bc=buchholzContributions(playerId),active=activeRankingTieBreaks();
  const cards=[];
  for(const tb of active){
    if(BUCHHOLZ_TB_KEYS.has(tb))cards.push(`<div class="tie-calc-card"><h4>${esc(TB_LABELS[tb])}</h4><div class="tie-calc-formula">${fmt(v[tb]||0)}</div><div class="tie-calc-detail">FIDE Swiss unplayed-round management is applied. Contributions: ${bc.map(x=>`${fmt(x.value)}${x.vur?' (VUR)':''}`).join(' + ')||'0'}.</div></div>`);
    else if(tb==='wins')cards.push(`<div class="tie-calc-card"><h4>${esc(TB_LABELS[tb])}</h4><div class="tie-calc-formula">${v.wins}</div><div class="tie-calc-detail">WIN counts win-equivalent rounds with or without play; a full ordinary PAB/forfeit win counts.</div></div>`);
    else if(tb==='blackWins')cards.push(`<div class="tie-calc-card"><h4>${esc(TB_LABELS[tb])}</h4><div class="tie-calc-formula">${v.blackWins}</div><div class="tie-calc-detail">BWG counts only games actually won over the board with Black.</div></div>`);
    else cards.push(`<div class="tie-calc-card"><h4>${esc(TB_LABELS[tb])}</h4><div class="tie-calc-formula">${fmt(v[tb]||0)}</div><div class="tie-calc-detail">Calculated from the current tournament record.</div></div>`);
  }
  return `<div class="note" style="margin-bottom:10px"><b>Score:</b> ${fmt(v.score)}${p.tied?' • Shared place':''}</div><div class="tie-explain-grid">${cards.join('')}</div>`;
}
function openTieBreakExplanation(playerId){const p=getPlayer(playerId);if(!p)return;const modal=document.getElementById('tieBreakExplainModal');if(!modal)return;document.getElementById('tieExplainPlayer').textContent=p.name;document.getElementById('tieExplainBody').innerHTML=tieBreakExplanationHTML(playerId);modal.classList.add('show');modal.setAttribute('aria-hidden','false');}
function closeTieBreakExplanation(){const modal=document.getElementById('tieBreakExplainModal');if(!modal)return;modal.classList.remove('show');modal.setAttribute('aria-hidden','true');}
function fmt(v){return Number.isInteger(v)?String(v):Number(v).toFixed(1);}

function renderPairingsRanking(){
  const box=document.getElementById('pairingsRankingTable');
  const subtitle=document.getElementById('pairingsRankingSubtitle');
  if(!box)return;

  const completedGames=state.rounds.reduce((n,r)=>n+r.games.filter(g=>g.bye||g.result).length,0);
  const totalGames=state.rounds.reduce((n,r)=>n+r.games.length,0);
  if(subtitle){
    subtitle.textContent=`Live standings after Round ${state.rounds.length || 0} • ${completedGames}/${totalGames} game result(s) encoded`;
  }

  if(state.settings.mode==='team'){
    const arr=teamStandings();
    if(!arr.length){
      box.innerHTML='<div class="empty">No team ranking yet.</div>';
      return;
    }
    box.innerHTML=`<table>
      <thead><tr><th>Rank</th><th>Team / Delegation</th><th>MP</th><th>Board Pts</th><th>Match Wins</th></tr></thead>
      <tbody>${arr.map((t,i)=>`<tr class="${i===0?'rank1':''}">
        <td><b>${t.rank??i+1}</b></td>
        <td><b>${esc(t.name)}</b></td>
        <td><b>${fmt(t.matchPoints||0)}</b></td>
        <td>${fmt(t.boardPoints||0)}</td>
        <td>${t.wins||0}</td>
      </tr>`).join('')}</tbody>
    </table>`;
    return;
  }

  const arr=standings();
  if(!arr.length){
    box.innerHTML='<div class="empty">No ranking yet.</div>';
    return;
  }

  const visibleTB=activeRankingTieBreaks().slice(0,8);
  const headers=['Rank','Player','Rtg','Pts',...visibleTB.map(tb=>TB_LABELS[tb].split(' – ')[0])];

  box.innerHTML=`<table>
    <thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead>
    <tbody>${arr.map((p,i)=>`<tr class="${i===0?'rank1':''}">
      <td><b>${p.rank??i+1}</b></td>
      <td class="standings-player"><b>${esc(p.name)}</b>${isOpenIndividualTournament()?'':`<br><small class="school-short" title="${esc(p.school||delegationLabel(p)||'')}">${esc(compactDelegationLabel(p)||p.category||'')}</small>`}</td>
      <td>${ratingText(p)}</td>
      <td><b>${fmt(p.score)}</b></td>
      ${visibleTB.map(tb=>`<td>${fmt(p[tb]||0)}</td>`).join('')}
    </tr>`).join('')}</tbody>
  </table>`;
}



function standingsTieShort(tb){
  const map={
    de:'DE',
    buchholz:'BH',
    buchholzCut1:'BH-C1',
    buchholzMedian1:'BH-M1',
    buchholzMedian2:'BH-M2',
    wins:'W',
    blackWins:'BWG',
    sb:'SB',
    sonneborn:'SB',
    cumulative:'CUM',
    rating:'RTG'
  };
  return map[tb]||String(tb||'').toUpperCase();
}
function standingsTieLegend(tb){
  const map={
    de:'DE = Direct Encounter',
    buchholz:'BH = Buchholz',
    buchholzCut1:'BH-C1 = Buchholz Cut 1 — exclude the lowest contribution',
    buchholzMedian1:'BH-M1 = Buchholz Median-1 — exclude the lowest and highest contributions',
    buchholzMedian2:'BH-M2 = Buchholz Median-2 — exclude the two lowest and two highest contributions',
    wins:'WIN = Win-equivalent rounds (played or unplayed)',
    blackWins:'BWG = Over-the-board wins with Black',
    sb:'SB = Sonneborn-Berger',
    sonneborn:'SB = Sonneborn-Berger',
    cumulative:'CUM = Cumulative Score',
    rating:'RTG = Starting Rating'
  };
  return map[tb]||standingsTieShort(tb);
}
function standingsDelegationHeader(){
  const lvl=state.settings.meetLevel||'municipal';
  if(lvl==='municipal')return 'SCHOOL';
  if(lvl==='division')return 'MUNICIPALITY / CITY';
  if(lvl==='regional')return 'DIVISION / PROVINCE';
  if(lvl==='national')return 'REGION';
  return 'DELEGATION';
}
function standingsDelegationValue(p){
  const lvl=state.settings.meetLevel||'municipal';
  if(lvl==='municipal')return compactDelegationLabel(p)||p.school||'';
  if(lvl==='division')return p.town||compactDelegationLabel(p)||p.school||'';
  if(lvl==='regional')return p.division||p.town||compactDelegationLabel(p)||p.school||'';
  if(lvl==='national')return p.region||p.division||p.town||compactDelegationLabel(p)||p.school||'';
  return compactDelegationLabel(p)||p.school||'';
}
function isTournamentFinalResult(){
  const total=+state.settings.rounds||0;
  if(total<=0 || state.rounds.length<total)return false;
  const last=currentRound();
  return state.rounds.length>0 &&
    state.rounds.every(r=>r.games.every(g=>g.bye||g.result)) &&
    !!last?.finalized;
}
function standingsReportTitle(){
  return isTournamentFinalResult()
    ? 'Final Ranking'
    : `Provisional Standing — Round ${state.rounds.length||0}`;
}
function standingsReportStatus(){
  return isTournamentFinalResult()
    ? 'OFFICIAL FINAL RESULT'
    : 'CURRENT / UNOFFICIAL';
}
function printStandingsReport(){
  buildStandingsPrintSheet();

  const useLandscape=(activeRankingTieBreaks()?.length||0)>5 || (state.players?.length||0)>32;
  const compactLargeRoster=(state.players?.length||0)>=30;
  const classes=['printing-standings'];
  if(useLandscape)classes.push('landscape-print');
  if(compactLargeRoster)classes.push('large-standings-print');

  openPrintPreview({
    title:isTournamentFinalResult()?'Final Ranking Preview':'Provisional Ranking Preview',
    selector:'#printStandingsSheet',
    orientation:useLandscape?'landscape':'portrait',
    bodyClass:classes.join(' ')
  });
}
function buildStandingsPrintSheet(){
  const box=document.getElementById('printStandingsSheet');
  if(!box)return;

  const title=(state.settings.name||'Chess Tournament').toUpperCase();
  const category=state.settings.tournamentCategory||'Open';
  const rankingTitle=standingsReportTitle();
  const reportStatus=standingsReportStatus();
  const delegationHeader=standingsDelegationHeader();
  const date=state.settings.date||'—';
  const venue=state.settings.venue||'—';
  const timeControl=state.settings.timeControl||'—';
  const chief=state.settings.chiefArbiter||'';
  const td=state.settings.tournamentDirector||'';
  const totalRounds=state.settings.rounds||0;
  const roundsText=`${state.rounds.length}/${totalRounds}`;
  const tieCols=activeRankingTieBreaks().slice(0,8);
  const generatedAt=new Date().toLocaleString();
  const isFinal=isTournamentFinalResult();

  if(state.settings.mode==='team'){
    const arr=teamStandings();
    if(!arr.length){
      box.innerHTML='<div style="font-family:Arial;color:#000">No team standings yet.</div>';
      return;
    }

    const rows=arr.map((t,i)=>`<tr class="${isFinal?(i===0?'top1':i===1?'top2':i===2?'top3':''):''}">
      <td class="c-rank">${p.rank??i+1}${isFinal&&p.rank<=3?`<span class="rank-medal">${p.rank===1?'1ST':p.rank===2?'2ND':'3RD'}</span>`:''}</td>
      <td class="player-cell"><span class="player-name">${esc(t.name)}</span></td>
      <td>${esc(t.name)}</td>
      <td class="c-pts">${fmt(t.matchPoints||0)}</td>
      <td class="c-small">${fmt(t.boardPoints||0)}</td>
      <td class="c-small">${t.wins||0}</td>
    </tr>`).join('');

    box.innerHTML=`
      <div class="fs-document">
        <div class="fs-header">
          <div class="fs-header-left">
            <div class="print-brand-line"><img src="assets/catque-logo.png" alt="CatQue"><span>CATQUE TOURNAMENT MANAGER</span></div>
            <div class="fs-kicker">Chess Tournament Official Result</div>
            <div class="fs-event">${esc(title)}</div>
            <div class="fs-category">${esc(category)}</div>
          </div>
          <div class="fs-status">
            <div class="fs-status-title">${esc(rankingTitle)}</div>
            <div class="fs-status-round">${esc(reportStatus)}</div>
          </div>
        </div>

        <div class="fs-meta">
          <div class="fs-meta-item"><span class="fs-meta-label">Format</span><span class="fs-meta-value">${esc(modeName(state.settings.mode))}</span></div>
          <div class="fs-meta-item"><span class="fs-meta-label">Rounds</span><span class="fs-meta-value">${esc(roundsText)}</span></div>
          <div class="fs-meta-item"><span class="fs-meta-label">Time Control</span><span class="fs-meta-value">${esc(timeControl)}</span></div>
          <div class="fs-meta-item"><span class="fs-meta-label">Date</span><span class="fs-meta-value">${esc(date)}</span></div>
        </div>

        <div class="fs-table-title"><h2>Team Ranking</h2><div class="count">${arr.length} team(s) • ${esc(venue)}</div></div>

        <table class="print-standings-table">
          <colgroup>
            <col style="width:8%"><col style="width:42%"><col style="width:26%"><col style="width:8%"><col style="width:8%"><col style="width:8%">
          </colgroup>
          <thead><tr><th>Rank</th><th>Team</th><th>${esc(delegationHeader)}</th><th>MP</th><th>BP</th><th>W</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>

        <div class="fs-legend"><b>Ranking:</b> Match Points → Board Points → Match Wins.</div>

        <div class="fs-cert">
          <div class="fs-cert-box"><div class="fs-cert-caption">Officiated by:</div><div class="fs-cert-name">${esc(chief).toUpperCase()}</div><div class="fs-cert-role">Chief Arbiter</div></div>
          <div class="fs-cert-box"><div class="fs-cert-caption">Prepared by:</div><div class="fs-cert-name">${esc(td).toUpperCase()}</div><div class="fs-cert-role">Tournament Director (TD)</div></div>
          <div class="fs-cert-box"><div class="fs-cert-caption">Verified / Checked by:</div><div class="fs-cert-name">&nbsp;</div><div class="fs-cert-role">Tournament Committee</div></div>
        </div>

        <div class="fs-footer"><div>Generated by CatQue Tournament Manager</div><div class="right">${esc(generatedAt)}</div></div>
      </div>`;
    return;
  }

  const arr=standings();
  if(!arr.length){
    box.innerHTML='<div style="font-family:Arial;color:#000">No standings yet.</div>';
    return;
  }

  const rows=arr.map((p,i)=>{
    const printableName = ((p.lastName||'')+' '+(p.firstName||'')+(p.middleInitial?(' '+p.middleInitial):'')).trim() || p.name;
    return `<tr class="${isFinal?(i===0?'top1':i===1?'top2':i===2?'top3':''):''}">
      <td class="c-rank">${p.rank??i+1}${isFinal&&p.rank<=3?`<span class="rank-medal">${p.rank===1?'1ST':p.rank===2?'2ND':'3RD'}</span>`:''}</td>
      <td class="player-cell">
        <span class="player-name">${esc(printableName).toUpperCase()}</span>
      </td>
      <td>${esc(standingsDelegationValue(p)).toUpperCase()}</td>
      <td class="c-pts"><b>${fmt(p.score)}</b></td>
      ${tieCols.map(tb=>`<td class="c-small">${fmt(p[tb]||0)}</td>`).join('')}
    </tr>`;
  }).join('');

  // Dynamic widths: retain a strong Name/Delegation area, then share remainder among TBs.
  const tbCount=Math.max(1,tieCols.length);
  const tbWidth=Math.max(5,Math.floor(31/tbCount));
  const colWidths=['7%','36%','22%','7%',...tieCols.map(()=>`${tbWidth}%`)];
  const headers=['Rank','Name',delegationHeader,'Pts',...tieCols.map(standingsTieShort)];

  const legend=tieCols.map((tb,i)=>`${i+1}. ${standingsTieLegend(tb)}`).join(' &nbsp; • &nbsp; ');

  box.innerHTML=`
    <div class="fs-document">
      <div class="fs-header">
        <div class="fs-header-left">
          <div class="print-brand-line"><img src="assets/catque-logo.png" alt="CatQue"><span>CATQUE TOURNAMENT MANAGER</span></div>
          <div class="fs-kicker">Chess Tournament Official Result</div>
          <div class="fs-event">${esc(title)}</div>
          <div class="fs-category">${esc(category)}</div>
        </div>
        <div class="fs-status">
          <div class="fs-status-title">${esc(rankingTitle)}</div>
          <div class="fs-status-round">${esc(reportStatus)}</div>
        </div>
      </div>

      <div class="fs-meta">
        <div class="fs-meta-item"><span class="fs-meta-label">Format</span><span class="fs-meta-value">${esc(cleanFormatName())}</span></div>
        <div class="fs-meta-item"><span class="fs-meta-label">Rounds</span><span class="fs-meta-value">${esc(roundsText)}</span></div>
        <div class="fs-meta-item"><span class="fs-meta-label">Time Control</span><span class="fs-meta-value">${esc(timeControl)}</span></div>
        <div class="fs-meta-item"><span class="fs-meta-label">Date</span><span class="fs-meta-value">${esc(date)}</span></div>
      </div>

      <div class="fs-table-title">
        <h2>${esc(rankingTitle)}</h2>
        <div class="count">${arr.length} participant(s) • ${esc(venue)}</div>
      </div>

      <table class="print-standings-table">
        <colgroup>${colWidths.map(w=>`<col style="width:${w}">`).join('')}</colgroup>
        <thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead>
        <tbody>${rows}</tbody>
      </table>

      <div class="fs-legend">
        <b>Tie-break order:</b> ${legend || 'None'}
      </div>

      <div class="fs-cert">
        <div class="fs-cert-box">
          <div class="fs-cert-caption">Officiated by:</div>
          <div class="fs-cert-name">${esc(chief).toUpperCase()}</div>
          <div class="fs-cert-role">Chief Arbiter</div>
        </div>
        <div class="fs-cert-box">
          <div class="fs-cert-caption">Prepared by:</div>
          <div class="fs-cert-name">${esc(td).toUpperCase()}</div>
          <div class="fs-cert-role">Tournament Director (TD)</div>
        </div>
        <div class="fs-cert-box">
          <div class="fs-cert-caption">Verified / Checked by:</div>
          <div class="fs-cert-name">&nbsp;</div>
          <div class="fs-cert-role">Tournament Committee</div>
        </div>
      </div>

      <div class="fs-footer">
        <div>Generated by CatQue Tournament Manager</div>
        <div class="right">${esc(generatedAt)}</div>
      </div>
    </div>`;
}

let rankingDetailMode=false;
function toggleRankingDetail(){
  rankingDetailMode=!rankingDetailMode;
  const btn=document.getElementById('rankingDetailToggle');
  if(btn)btn.textContent=rankingDetailMode?'Show Simple Ranking':'Show Detailed Tie-breaks';
  renderStandings();
}

function renderStandings(){
  const rankingHeading=document.querySelector('#standings h3');
  if(rankingHeading)rankingHeading.textContent=isTournamentFinalResult()?'Final Result':'Ranking';
  const detailBtn=document.getElementById('rankingDetailToggle');
  if(detailBtn)detailBtn.textContent=rankingDetailMode?'Show Simple Ranking':'Show Detailed Tie-breaks';

  if(state.settings.mode==='team'){
    const arr=teamStandings();
    if(!arr.length){standingsTable.innerHTML='<div class="empty">No teams yet.</div>';return;}
    standingsTable.innerHTML=`<table class="easy-ranking-table"><thead><tr><th>Rank</th><th>Team / Delegation</th><th>Match Pts</th>${rankingDetailMode?'<th>Board Pts</th><th>Match Wins</th><th>Players</th>':''}</tr></thead><tbody>`+
      arr.map((t,i)=>`<tr class="${t.rank===1?'rank1':''}"><td><span class="rank-number rank-${t.rank??i+1}">${t.rank??i+1}</span></td><td><b>${esc(t.name)}</b></td><td><b>${fmt(t.matchPoints||0)}</b></td>${rankingDetailMode?`<td>${fmt(t.boardPoints||0)}</td><td>${t.wins||0}</td><td>${t.players.length}</td>`:''}</tr>`).join('')+
      `</tbody></table>`;
    return;
  }

  const arr=standings();
  if(!arr.length){standingsTable.innerHTML='<div class="empty">No players yet.</div>';return;}
  const currentTB=activeRankingTieBreaks();
  const visibleTB=rankingDetailMode?currentTB.slice(0,5):currentTB.slice(0,1);
  const cols=['Rank','Player','Pts',...visibleTB.map(x=>TB_LABELS[x].split(' – ')[0]),...(rankingDetailMode?['Details']:[])];
  standingsTable.innerHTML=`<table class="easy-ranking-table"><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>`+
  arr.map((p,i)=>`<tr class="${p.rank===1?'rank1':''}">
    <td><span class="rank-number rank-${p.rank??i+1}">${p.rank??i+1}</span></td>
    <td class="standings-player"><b>${esc(p.name)}</b>${isOpenIndividualTournament()?'':`<span class="subline">${esc(compactDelegationLabel(p)||p.category||'')}</span>`}</td>
    <td><b class="points-pill">${fmt(p.score)}</b></td>
    ${visibleTB.map(tb=>`<td>${fmt(p[tb]||0)}</td>`).join('')}
    ${rankingDetailMode?`<td><button class="btn small tie-explain-btn" onclick="openTieBreakExplanation('${p.id}')" title="Show tie-break calculation">Explain</button></td>`:''}
  </tr>`).join('')+
  `</tbody></table>`;
}

function renderPlayersSummaryCards(){
  const box=document.getElementById('playersSummaryCards');
  if(!box)return;
  const total=state.players.length;
  const rated=state.players.filter(p=>!p.unrated).length;
  const unrated=state.players.filter(p=>p.unrated).length;
  const groups=isOpenIndividualTournament()
    ? new Set(state.players.map(p=>p.category||'Open')).size
    : new Set(state.players.map(p=>p.schoolId||p.school||'')).size;
  const groupLabel=isOpenIndividualTournament()?'Categories':'Schools';
  box.innerHTML=[
    ['Players',total,total?`${total} registered player(s)`:'No players yet'],
    ['Rated',rated,'With rating values'],
    ['Non-Rated',unrated,'Shown as NR'],
    [groupLabel,groups,isOpenIndividualTournament()?'Tournament group count':'Represented schools / delegations']
  ].map(([label,value,sub])=>`<div class="summary-card-mini"><div class="label">${esc(label)}</div><div class="value">${value}</div><div class="sub">${esc(sub)}</div></div>`).join('');
}

function renderPlayers(){
  applyTournamentScopeUI?.();
  state.players.forEach(ensurePlayerStructuredName);
  renderPlayersSummaryCards();
  updateShufflePlayersButton?.();

  const q=(document.getElementById('playerRosterSearch')?.value||'').trim().toLowerCase();
  const visible=state.players.filter(p=>{
    if(!q)return true;
    const hay=[p.name,p.school,p.schoolId,p.town,p.division,p.region,p.category,String(p.rating||'')].join(' ').toLowerCase();
    return hay.includes(q);
  });

  if(!state.players.length){
    playersTable.innerHTML='<div class="pair-empty-guide"><b>No players registered yet.</b><ol><li>Enter the player details above.</li><li>Click <b>Add Player</b> or import a CSV.</li><li>When the roster is ready, open <b>Current Round</b>.</li></ol></div>';
    return;
  }
  if(!visible.length){
    playersTable.innerHTML='<div class="empty">No player matches your search.</div>';
    return;
  }

  playersTable.innerHTML=`<div class="player-card-grid">${visible.map((p)=>{
    const index=state.players.indexOf(p)+1;
    const secondary=isOpenIndividualTournament()
      ? (p.category||'Open Tournament')
      : (compactDelegationLabel(p)||p.school||'School not set');
    const schoolMeta=isOpenIndividualTournament()
      ? ''
      : `<div class="player-card-meta">${esc(p.schoolId||'No School ID')} ${p.town?`• ${esc(p.town)}`:''}</div>`;
    return `<article class="player-card-easy">
      <div class="player-card-number">${index}</div>
      <div class="player-card-main">
        <div class="player-card-name">${esc(p.name||'')}</div>
        <div class="player-card-secondary">${esc(secondary)}</div>
        ${schoolMeta}
      </div>
      <div class="player-card-rating"><span>Rating</span><b>${ratingText(p)}</b></div>
      <div class="player-card-actions">
        <button class="btn small" onclick="editPlayer('${p.id}')">Edit</button>
        <button class="btn small danger" onclick="deletePlayer('${p.id}')">Delete</button>
      </div>
    </article>`;
  }).join('')}</div>`;
}

function moveTie(i,dir){
  const m=state.settings.mode||'';
  if(!m || m==='knockout'||m==='team')return;
  const j=i+dir;if(j<0||j>=state.tieBreaks.length)return;
  [state.tieBreaks[i],state.tieBreaks[j]]=[state.tieBreaks[j],state.tieBreaks[i]];
  state.tieBreaksByMode[m]=[...state.tieBreaks];
  persist();renderTieList();renderAll();renderModeTieBreakSelectors();
}
function renderTieList(){
  const m=state.settings.mode||'';
  if(!m){
    tieList.innerHTML='<div class="empty">Select a tournament format first.</div>';
    return;
  }
  state.tieBreaks=activeRankingTieBreaks(); if(state.tieBreaksByMode?.[m])state.tieBreaksByMode[m]=[...state.tieBreaks];
  const advTitle=document.getElementById('advancedTieTitle');
  if(advTitle)advTitle.textContent=`Tie-break Priority — ${modeName(m)}`;
  if(m==='knockout'||m==='team'){
    tieList.innerHTML=`<div class="empty">${m==='team'?'Team standings use Match Points → Board Points → Match Wins.':'Knockout does not use a standings tie-break order for advancement.'}</div>`;
    return;
  }
  tieList.innerHTML=state.tieBreaks.length
    ? state.tieBreaks.map((tb,i)=>`<div class="tie-item"><div><span class="badge gold">${i+1}</span> <b>${esc(TB_LABELS[tb])}</b></div><div><button class="btn small" onclick="moveTie(${i},-1)">↑</button> <button class="btn small" onclick="moveTie(${i},1)">↓</button></div></div>`).join('')
    : '<div class="empty">No ranking tie-break is enabled. Players with no defined separator share the same place. Tournament regulations may specify a playoff, drawing of lots, or another published method.</div>';
}
function resetTieBreaks(){
  const m=state.settings.mode||'';
  if(!m)return;
  state.tieBreaksByMode[m]=cloneDefaultTB(m);
  state.tieBreaks=[...state.tieBreaksByMode[m]];
  persist();renderAll();renderModeTieBreakSelectors();
}
function renderDashboard(){
  const st=state.settings.mode==='team'?teamStandings():standings();
  kpiPlayers.textContent=state.players.length;kpiRound.textContent=state.rounds.length;
  kpiGames.textContent=state.rounds.reduce((n,r)=>n+r.games.filter(g=>g.result||g.bye).length,0);
  kpiLeader.textContent=st[0]?(state.settings.mode==='team'?st[0].name:st[0].name.split(' ')[0]):'—';
  if(!document.querySelector('.section.active')?.id || document.querySelector('.section.active')?.id==='dashboard'){
    eventSubtitle.textContent=`${state.settings.tournamentCategory||'Open'} • ${state.settings.name} • ${modeName(state.settings.mode)} • ${state.settings.rounds} round(s)`;
  }
  const openScope=isOpenIndividualTournament();
  configSummary.innerHTML=`<b>${esc(state.settings.name)}</b><br>Category: ${esc(state.settings.tournamentCategory||'Open')}<br>Mode: ${esc(modeName(state.settings.mode))}${state.settings.mode==='swiss'?` (${esc(({flexible:'Flexible',dutch:'Dutch-style (local)',accelerated:'Accelerated',double:'Double Swiss'}[state.settings.swissVariant||'flexible']))})`:''}<br>Environment: ${openScope?'Open Individual':'School / DepEd'}<br>Entry: ${esc(({open:'Open',invitational:'Invitational',rating:'Rating-Restricted'}[state.settings.entryType||'open']))}${openScope?'':`<br>Meet Level: ${esc((state.settings.meetLevel||'municipal').toUpperCase())}<br>School: ${esc(state.settings.school||'')}${state.settings.schoolId?' ('+esc(state.settings.schoolId)+')':''}`}<br>Rounds: ${state.settings.rounds}<br>Time Control: ${esc(state.settings.timeControl)}<br>Venue: ${esc(state.settings.venue)}<br>Chief Arbiter: ${esc(state.settings.chiefArbiter||'—')}<br>Tournament Director: ${esc(state.settings.tournamentDirector||'—')}<br><br><b>${esc(modeName(state.settings.mode))} Tie-breaks:</b><br>${activeRankingTieBreaks().length?activeRankingTieBreaks().slice(0,5).map((x,i)=>`${i+1}. ${esc(TB_LABELS[x])}`).join('<br>'):'Not used in Knockout'}`;
  if(!st.length)dashboardStandings.innerHTML='<div class="empty">Add players to begin.</div>';
  else if(state.settings.mode==='team'){
    dashboardStandings.innerHTML=`<table><thead><tr><th>Rank</th><th>Team</th><th>MP</th><th>Board Pts</th></tr></thead><tbody>${st.slice(0,8).map((t,i)=>`<tr><td>${t.rank??i+1}</td><td><b>${esc(t.name)}</b></td><td>${fmt(t.matchPoints||0)}</td><td>${fmt(t.boardPoints||0)}</td></tr>`).join('')}</tbody></table>`;
  } else dashboardStandings.innerHTML=`<table><thead><tr><th>Rank</th><th>Player</th><th>Pts</th><th>Primary TB</th></tr></thead><tbody>${st.slice(0,8).map((p,i)=>`<tr><td>${p.rank??i+1}</td><td><b>${esc(playerDisplay(p))}</b></td><td>${fmt(p.score)}</td><td>${activeRankingTieBreaks().length?`${fmt(p[activeRankingTieBreaks()[0]]||0)} ${esc(TB_LABELS[activeRankingTieBreaks()[0]].split(' – ')[0])}`:'—'}</td></tr>`).join('')}</tbody></table>`;
  notationEvent.textContent=state.settings.name;
  notationArbiter.textContent=state.settings.chiefArbiter||'';

  const cleanTitle=document.getElementById('cleanRoundStatusTitle');
  const cleanHelp=document.getElementById('cleanRoundStatusHelp');
  const cleanBtn=document.getElementById('dashboardGenerateRoundBtn');
  if(cleanTitle&&cleanHelp&&cleanBtn){
    const current=currentRound();
    const playerCount=state.players.length;
    const pending=current?.games?.filter(g=>!g.bye && !g.result).length || 0;
    const totalCurrent=current?.games?.filter(g=>!g.bye).length || 0;

    if(!state.settings?.tournamentStarted){
      cleanTitle.textContent='Create or Open a Tournament';
      cleanHelp.textContent='Start from the main menu, then follow the simple flow: Setup → Players → Round → Print.';
      cleanBtn.textContent='Open Main Menu';
      cleanBtn.onclick=()=>showHomeScreen();
    }else if(playerCount===0){
      cleanTitle.textContent='Step 1: Add Players';
      cleanHelp.textContent='Your tournament settings are ready. The next best step is to add or import the player roster.';
      cleanBtn.textContent='Open Players →';
      cleanBtn.onclick=()=>goTab('players');
    }else if(!state.rounds.length){
      cleanTitle.textContent='Step 2: Generate Round 1';
      cleanHelp.textContent=`${playerCount} player(s) registered. You can now generate the first round.`;
      cleanBtn.textContent='Open Current Round →';
      cleanBtn.onclick=()=>goTab('pairings');
    }else if(pending>0){
      cleanTitle.textContent=`Step 3: Encode Results (${pending} left)`;
      cleanHelp.textContent=`Round ${current.number} still has ${pending} unfinished board result(s) out of ${totalCurrent}.`;
      cleanBtn.textContent='Continue Current Round →';
      cleanBtn.onclick=()=>goTab('pairings');
    }else{
      cleanTitle.textContent=`Round ${current?.number||state.rounds.length} Completed`;
      cleanHelp.textContent='All board results for the current round are encoded. You can review the ranking or print reports.';
      cleanBtn.textContent='Open Print & Export →';
      cleanBtn.onclick=()=>goTab('reports');
    }
  }

  updateWorkflowBanner?.();
}
