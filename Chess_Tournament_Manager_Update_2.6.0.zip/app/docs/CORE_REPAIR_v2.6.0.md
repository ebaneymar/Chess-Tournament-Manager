# CatQue Tournament Manager v2.6.0 — Tournament Integrity Core Repair

This release repairs tournament logic in the v2.5.3 FIDE-bye/logo build without redesigning CatQue or changing its logo/app-icon artwork.

## Core repairs

- Swiss unplayed-round management for Buchholz-family and Sonneborn-Berger calculations, including dummy scores, opponent score adjustment, and the VUR Cut-1 rule.
- WIN is a round-based win-equivalent count; ordinary full PAB and forfeit wins count. BWG counts only over-the-board wins with Black.
- Swiss forfeits no longer create ordinary colour history or a previous-played-opponent record. Players paired but never actually playing may be paired later where the applicable Swiss rules allow it.
- Double-Swiss PAB is 1.5 points under 1 / 1/2 / 0 scoring. A match with one game played and one game forfeited remains a regular match; a match forfeited in both games can be repeated later.
- Team Swiss PAB uses the drawn-match score by default: draw match points and half of the available game/board points. Team Round-Robin scheduled sit-outs score zero.
- A present player against a missing team board receives the board point.
- Team Swiss no longer forces a repeated team opponent. If no legal pairing is found, CatQue stops and tells the tournament director instead.
- Team PAB eligibility blocks a second PAB and a team that has already won a match wholly by forfeit.
- Random all-NR school Round 1 applies only to Flexible / Practical Swiss, not Accelerated or Double Swiss.
- Round Robin removes Buchholz-family tie-breaks. Rating tie-break is removed when any player is unrated.
- Direct Encounter excludes Swiss forfeits by default, averages multiple encounters, recursively reapplies to tied subgroups, and implements the Swiss guaranteed-top case for incomplete direct-encounter groups.
- Remaining exact ties share the same displayed place instead of being silently separated alphabetically.
- Knockout Random Draw now respects the shuffled order instead of re-sorting by rating.
- Editing an official final result invalidates it and returns the tournament to provisional status until the final round is re-confirmed.
- Player add/import is locked once Round 1 has been generated; no incomplete late-entry procedure is implied.
- User-facing “FIDE theoretical baseline” wording was replaced with a CatQue round-count planning estimate/heuristic.
- The custom Dutch-style engine is explicitly labelled local and not an implementation/certification of the FIDE Dutch System.
- Stale desktop version label updated to v2.6.0.

## Deliberate limitation

CatQue v2.6.0 is **FIDE-based**, not represented as FIDE-certified pairing software. The local Dutch-style engine is not labelled “FIDE Dutch”. Team Swiss also retains CatQue’s practical pairing search rather than claiming an exact implementation of every ordered bracket/transposition rule in the FIDE Team Swiss specification.

## Regression coverage

The included `tests_core_regression.cjs` covers PAB, forfeits, colour history, WIN/BWG, Double Swiss, unplayed-round Buchholz, VUR Cut-1, Direct Encounter, NR rating protection, shared places, knockout random draw, Team PAB, missing boards, no-repeat team pairing, Team RR sit-outs, and finalization/late-entry guards.
