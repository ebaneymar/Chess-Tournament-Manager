# CatQue v2.6.2 — FIDE Dutch Electron Loader Fix

## Fixed
v2.6.1 loaded `app/js/fide-dutch-exact.js` as a local `type="module"` script.
Electron pages loaded from `file://` can reject local module scripts, leaving
`window.ensureFideDutchExact` undefined. CatQue then blocked Round 1 with
"Exact Dutch engine unavailable."

v2.6.2 loads the adapter as a normal classic script before `startup.js`.
The adapter uses dynamic `import()` for the pinned browser ESM
`@echecs/swiss@5.0.0/dutch` and retains cache/source fallback plus the existing
five-player exact-Dutch self-test.

No Flexible Swiss fallback is introduced. All v2.6.0 core repair behavior remains.
CatQue logo/app icon artwork is unchanged.
