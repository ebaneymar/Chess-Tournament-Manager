# CatQue v2.6.1 — FIDE Dutch C.04.3

- Swiss variant label is **FIDE Dutch Swiss**.
- Pure Dutch pairings use pinned `@echecs/swiss` v5.0.0 Dutch C.04.3 `pair(Player[], Game[][])`.
- The engine must pass CatQue's built-in 5-player regression self-test before pairing is enabled.
- Flexible / Practical Swiss is never used as a fallback for a selected FIDE Dutch tournament.
- Pairing byes, requested full/half/zero byes, and forfeits are translated to the published v5 GameKind model.
- The v2.6.0 tournament-integrity repairs remain intact.
- CatQue logo/app icon artwork is unchanged.

Note: the exact Dutch module is pinned and cached locally after a successful preload. If the local cache is empty, the first exact-engine preload requires internet access.
