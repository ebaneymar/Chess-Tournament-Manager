// Chess Tournament Manager 2.0
// Pairing engines, Swiss safeguards, rounds/results, and pairing print.

function isForfeitResult(result){return result==='1F-0F'||result==='0F-1F';}
function isOverTheBoardResult(result){return result==='1-0'||result==='0-1'||result==='½-½';}
function gameAward(game,playerId){
  if(!game)return 0;
  if(game.bye)return game.white===playerId?byePointsForGame(game):0;
  if(game.result==='½-½')return state.settings.scoring.draw;
  if(game.white===playerId && (game.result==='1-0'||game.result==='1F-0F'))return state.settings.scoring.win;
  if(game.black===playerId && (game.result==='0-1'||game.result==='0F-1F'))return state.settings.scoring.win;
  return 0;
}
function byePointsForGame(game){
  if(!game||!game.bye)return 0;
  if(state.settings.mode==='roundrobin')return 0;
  if(game.teamBoardForfeit)return 1;
  if(game.byeType==='requested'){
    const policy=state.settings.byePolicy||{};
    return policy.requestedEnabled ? Number(policy.requestedScore||0) : 0;
  }
  // FIDE Double-Swiss PAB = one win + one draw under normal scoring.
  if(state.settings.mode==='swiss' && state.settings.swissVariant==='double')return 1.5;
  return 1;
}
function gameCountsAsPlayedForPairing(game,rnd){
  if(!game||game.bye||!game.white||!game.black)return false;
  if(isOverTheBoardResult(game.result))return true;
  if(state.settings.mode==='swiss' && state.settings.swissVariant==='double' && game.matchId){
    const mate=(rnd?.games||[]).filter(g=>g.matchId===game.matchId && !g.bye);
    return mate.some(g=>isOverTheBoardResult(g.result));
  }
  // A standard Swiss pairing decided only by forfeit was paired but not played.
  return false;
}
function playerHistory(){
  const h={};
  state.players.forEach(p=>h[p.id]={score:0,opp:[],colors:[],wins:0,blackWins:0,otbWins:0,roundScores:[],bye:0,fullPointUnplayedWin:0});
  for(const rnd of state.rounds){
    const beforeScore=Object.fromEntries(state.players.map(p=>[p.id,h[p.id].score]));
    const doubleMode=state.settings.mode==='swiss' && state.settings.swissVariant==='double';
    const handledMatches=new Set();
    for(const g of rnd.games){
      if(g.bye){
        if(h[g.white]){
          const pts=byePointsForGame(g);
          h[g.white].score+=pts;
          if(g.byeType!=='requested' && state.settings.mode!=='roundrobin' && !g.teamBoardForfeit)h[g.white].bye++;
        }
        continue;
      }
      if(!h[g.white]||!h[g.black])continue;

      // Score every recorded result, including forfeits.
      const ws=gameAward(g,g.white), bs=gameAward(g,g.black);
      h[g.white].score+=ws; h[g.black].score+=bs;
      if(g.result==='1-0'){h[g.white].otbWins++;}
      else if(g.result==='0-1'){h[g.black].otbWins++;h[g.black].blackWins++;}
      else if(g.result==='1F-0F'){if(!doubleMode)h[g.white].fullPointUnplayedWin++;}
      else if(g.result==='0F-1F'){if(!doubleMode)h[g.black].fullPointUnplayedWin++;}

      if(doubleMode && g.matchId){
        if(handledMatches.has(g.matchId))continue;
        handledMatches.add(g.matchId);
        const mg=rnd.games.filter(x=>x.matchId===g.matchId&&!x.bye);
        const first=[...mg].sort((a,b)=>(a.doubleSwissGame||a.board)-(b.doubleSwissGame||b.board))[0];
        const regular=mg.some(x=>isOverTheBoardResult(x.result));
        if(regular && first && h[first.white] && h[first.black]){
          h[first.white].opp.push(first.black);h[first.black].opp.push(first.white);
          h[first.white].colors.push('W');h[first.black].colors.push('B');
        }else if(mg.length && mg.every(x=>isForfeitResult(x.result))){
          const ids=[g.white,g.black];
          for(const id of ids){
            const total=mg.reduce((sum,x)=>sum+gameAward(x,id),0);
            if(total>=2)h[id].fullPointUnplayedWin++;
          }
        }
        continue;
      }

      // Only an actually played game creates colour history and a previous opponent in ordinary Swiss.
      if(gameCountsAsPlayedForPairing(g,rnd)){
        h[g.white].opp.push(g.black);h[g.black].opp.push(g.white);
        h[g.white].colors.push('W');h[g.black].colors.push('B');
      }
    }
    const winEquivalent=doubleMode?2:Number(state.settings.scoring.win||1);
    for(const p of state.players){
      if((h[p.id].score-beforeScore[p.id])>=winEquivalent)h[p.id].wins++;
      h[p.id].roundScores.push(h[p.id].score);
    }
  }
  return h;
}
function scoreOf(id){return playerHistory()[id]?.score||0;}
function played(a,b){
  return state.rounds.some(r=>r.games.some(g=>((g.white===a&&g.black===b)||(g.white===b&&g.black===a))&&gameCountsAsPlayedForPairing(g,r)));
}
function colorBalance(id){
  const c=playerHistory()[id]?.colors||[]; return c.filter(x=>x==='W').length-c.filter(x=>x==='B').length;
}
function lastColors(id,n=2){return (playerHistory()[id]?.colors||[]).slice(-n);}
function chooseColors(a,b){
  const ba=colorBalance(a.id),bb=colorBalance(b.id),la=lastColors(a.id),lb=lastColors(b.id);
  const penalty=(pid,color)=>{
    const bal=colorBalance(pid)+(color==='W'?1:-1); let p=Math.abs(bal)*2;
    const l=lastColors(pid,2); if(l.length===2&&l[0]===color&&l[1]===color)p+=20;
    return p;
  };
  const p1=penalty(a.id,'W')+penalty(b.id,'B'), p2=penalty(a.id,'B')+penalty(b.id,'W');
  if(p1<p2)return [a.id,b.id]; if(p2<p1)return [b.id,a.id];
  return Math.random()<.5?[a.id,b.id]:[b.id,a.id];
}
function selectBye(players){
  const h=playerHistory();
  // FIDE Swiss absolute criterion: no second PAB, and no PAB after a prior full-point unplayed/forfeit win.
  const eligible=players.filter(p=>(h[p.id]?.bye||0)===0 && (h[p.id]?.fullPointUnplayedWin||0)===0);
  if(!eligible.length)return null;
  return [...eligible].sort((a,b)=>
    (h[a.id].score-h[b.id].score)||
    ((a.unrated?0:a.rating)-(b.unrated?0:b.rating))||
    a.name.localeCompare(b.name)
  )[0];
}

function buildConflictFreeSwissPairs(pool,pairingScore){
  const h=playerHistory();
  const historyPairs=new Set();
  for(const rnd of state.rounds){
    for(const g of rnd.games){
      if(g.bye||!g.white||!g.black||!gameCountsAsPlayedForPairing(g,rnd))continue;
      historyPairs.add([g.white,g.black].sort().join('|'));
    }
  }
  const canPair=(a,b)=>!historyPairs.has([a.id,b.id].sort().join('|'));
  const balance=p=>{
    const colors=h[p.id]?.colors||[];
    return colors.filter(x=>x==='W').length-colors.filter(x=>x==='B').length;
  };
  const pairCost=(a,b)=>
    Math.abs(pairingScore(a)-pairingScore(b))*10000+
    Math.abs(balance(a)+balance(b))*50+
    Math.abs((a.unrated?0:a.rating||0)-(b.unrated?0:b.rating||0))/10;

  let nodes=0;
  const NODE_LIMIT=250000;

  const search=(remaining,pairs)=>{
    if(!remaining.length)return pairs;
    if(++nodes>NODE_LIMIT)return null;

    let pickIndex=0,minOptions=Infinity;
    for(let i=0;i<remaining.length;i++){
      let options=0;
      for(let j=0;j<remaining.length;j++){
        if(i!==j && canPair(remaining[i],remaining[j]))options++;
      }
      if(options<minOptions){minOptions=options;pickIndex=i;}
      if(minOptions===0)break;
    }
    if(minOptions===0)return null;

    const a=remaining[pickIndex];
    const rest=remaining.filter((_,i)=>i!==pickIndex);
    const candidates=rest.filter(b=>canPair(a,b)).sort((x,y)=>pairCost(a,x)-pairCost(a,y));

    for(const b of candidates){
      const next=rest.filter(x=>x.id!==b.id);
      const found=search(next,[...pairs,[a,b]]);
      if(found)return found;
    }
    return null;
  };

  return search([...pool],[]);
}

function validateSwissAbsoluteCriteria(games,{doubleSwiss=false}={}){
  if(!Array.isArray(games)||!games.length)return {ok:false,message:'No valid games were generated.'};
  const h=playerHistory();
  const seenPlayers=new Map();
  const seenCurrentPairs=new Set();

  for(const g of games){
    if(g.bye){
      if(!g.white)return {ok:false,message:'A pairing-allocated bye has no player.'};
      if((h[g.white]?.bye||0)>0){
        const p=getPlayer(g.white);
        return {ok:false,message:`${p?.name||'A player'} already received a pairing-allocated bye.`};
      }
      if((h[g.white]?.fullPointUnplayedWin||0)>0){
        const p=getPlayer(g.white);
        return {ok:false,message:`${p?.name||'A player'} already received a full-point unplayed/forfeit win and is not eligible for a pairing-allocated bye under the FIDE Swiss absolute criterion.`};
      }
      seenPlayers.set(g.white,(seenPlayers.get(g.white)||0)+1);
      continue;
    }

    if(!g.white||!g.black)return {ok:false,message:'A generated board is missing a player.'};

    const key=[g.white,g.black].sort().join('|');
    if(played(g.white,g.black)){
      const a=getPlayer(g.white),b=getPlayer(g.black);
      return {ok:false,message:`Repeat opponent blocked: ${a?.name||'Player'} vs ${b?.name||'Player'} already occurred.`};
    }

    if(seenCurrentPairs.has(key) && !doubleSwiss){
      return {ok:false,message:'The same opponents were paired twice in the new round.'};
    }
    seenCurrentPairs.add(key);

    seenPlayers.set(g.white,(seenPlayers.get(g.white)||0)+1);
    seenPlayers.set(g.black,(seenPlayers.get(g.black)||0)+1);
  }

  if(!doubleSwiss){
    for(const [id,count] of seenPlayers){
      if(count>1){
        const p=getPlayer(id);
        return {ok:false,message:`${p?.name||'A player'} appears more than once in the generated round.`};
      }
    }
  }
  return {ok:true,message:''};
}

function swissPairByScore(players, pairingScore){
  const h=playerHistory();
  let pool=[...players].sort((a,b)=>
    pairingScore(b)-pairingScore(a)||
    (b.unrated?0:b.rating||0)-(a.unrated?0:a.rating||0)||
    a.name.localeCompare(b.name)
  );
  const games=[];

  if(pool.length%2){
    const bye=selectBye(pool);
    if(!bye){
      showToast('No player is eligible for another pairing-allocated bye. Pairing stopped.','error','Swiss pairing blocked');
      return null;
    }
    games.push({id:uid(),board:0,white:bye.id,black:null,result:'BYE',bye:true,byeType:'pairing'});
    pool=pool.filter(p=>p.id!==bye.id);
  }

  const pairs=buildConflictFreeSwissPairs(pool,pairingScore);
  if(!pairs){
    showToast('A conflict-free Swiss round could not be produced without a repeat opponent. Pairing stopped instead of forcing an invalid board.','error','Swiss pairing blocked');
    return null;
  }

  pairs.sort((x,y)=>Math.max(pairingScore(y[0]),pairingScore(y[1]))-Math.max(pairingScore(x[0]),pairingScore(x[1])));
  let board=1;
  for(const [a,b] of pairs){
    const [w,bl]=chooseColors(a,b);
    games.push({id:uid(),board:board++,white:w,black:bl,result:'',bye:false});
  }
  const byeGame=games.find(g=>g.bye);
  if(byeGame)byeGame.board=board;
  return games;
}

function swissPair(players){
  const h=playerHistory();
  return swissPairByScore(players,p=>h[p.id]?.score||0);
}


function shouldRandomizeSchoolRoundOne(){
  if(state.settings.mode!=='swiss')return false;
  if((state.settings.swissVariant||'flexible')!=='flexible')return false;
  if(state.rounds.length!==0)return false;

  // Manual Shuffle Players explicitly requests a random Swiss Round 1.
  if(state.settings?.manualRosterShuffle)return state.players.length>1;

  // School/DepEd all-NR tournaments are random by default in Round 1.
  if(state.settings?.eventScope==='open')return false;
  return state.players.length>1 && state.players.every(p=>p.unrated || !Number(p.rating||0));
}

function shuffledPlayers(players){
  const arr=[...players];
  for(let i=arr.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]]=[arr[j],arr[i]];
  }
  return arr;
}

function randomSchoolRoundOnePair(players){
  // If the user already clicked Shuffle Players, preserve that visible shuffled order.
  // Otherwise (automatic School/NR Round 1), create a fresh random shuffle here.
  let pool=state.settings?.manualRosterShuffle ? [...players] : shuffledPlayers(players);
  const games=[];
  let board=1;

  // For an odd roster, the first-round bye is random too.
  if(pool.length%2){
    const bye=pool.pop();
    games.push({
      id:uid(),
      board:0,
      white:bye.id,
      black:null,
      result:'BYE',
      bye:true,
      byeType:'pairing',
      randomSchoolRoundOne:true
    });
  }

  for(let i=0;i<pool.length;i+=2){
    const a=pool[i], b=pool[i+1];
    const [w,bl]=chooseColors(a,b);
    games.push({
      id:uid(),
      board:board++,
      white:w,
      black:bl,
      result:'',
      bye:false,
      randomSchoolRoundOne:true
    });
  }

  const byeGame=games.find(g=>g.bye);
  if(byeGame)byeGame.board=board;
  return games;
}

function acceleratedSwissPair(players){
  const h=playerHistory();
  const seeded=[...players].sort((a,b)=>(b.rating||0)-(a.rating||0)||a.name.localeCompare(b.name));
  const top=new Set(seeded.slice(0,Math.ceil(seeded.length/2)).map(p=>p.id));
  const opening=state.rounds.length<2;
  return swissPairByScore(players,p=>(h[p.id]?.score||0)+(opening&&top.has(p.id)?1:0));
}

// EXACT FIDE DUTCH C.04.3 ADAPTER — @echecs/swiss v5.0.0
// ---------------------------------------------------------------------------
// IMPORTANT:
// The published v5.0.0 API is:
//   pair(players, gamesByRound)
// where gamesByRound is Game[][].
// A pairing bye is a Game with black:'' and result:1.
// The result is { pairings:[{white,black}], byes:[{player}] }.
//
// Pure Dutch tournaments NEVER use CatQue Flexible Swiss as a fallback.

function ensureExactDutchTPN(players){
  const sorted=[...players].sort((a,b)=>Number(a.dutchTpn||999999)-Number(b.dutchTpn||999999));
  const valid=sorted.length===players.length &&
    sorted.every((p,i)=>Number.isInteger(Number(p.dutchTpn)) && Number(p.dutchTpn)===i+1);

  if(!valid){
    players.forEach((p,i)=>{p.dutchTpn=i+1;});
    state.settings.dutchTpnLocked=true;
  }
}

function exactDutchPlayersInTPNOrder(players){
  ensureExactDutchTPN(players);
  return [...players].sort((a,b)=>Number(a.dutchTpn)-Number(b.dutchTpn));
}

function catqueToExactDutchPlayers(players){
  return exactDutchPlayersInTPNOrder(players).map(p=>{
    const out={id:String(p.id)};
    if(!p.unrated && Number.isFinite(Number(p.rating)) && Number(p.rating)>0){
      out.rating=Number(p.rating);
    }
    return out;
  });
}

function catqueGameToPublishedDutchGame(g){
  if(g.bye){
    const pts=Number(byePointsForGame(g));
    const win=Number(state.settings.scoring.win||1);
    const draw=Number(state.settings.scoring.draw||0.5);
    let kind='pairing-bye';
    if(g.byeType==='requested'){
      if(Math.abs(pts-win)<1e-9)kind='full-bye';
      else if(Math.abs(pts-draw)<1e-9)kind='half-bye';
      else kind='zero-bye';
    }
    return {
      white:String(g.white),
      black:'',
      result:pts,
      kind
    };
  }

  const base={white:String(g.white),black:String(g.black)};

  if(g.result==='1-0')return {...base,result:1};
  if(g.result==='0-1')return {...base,result:0};
  if(g.result==='½-½')return {...base,result:.5};

  // Published API result is from White's perspective.
  if(g.result==='1F-0F')return {...base,result:1,kind:'forfeit-win'};
  if(g.result==='0F-1F')return {...base,result:0,kind:'forfeit-loss'};

  throw new Error(`Round ${g.board||'?'} has no completed result for FIDE Dutch history.`);
}

function catqueToPublishedDutchGamesByRound(){
  return state.rounds.map(r=>{
    return (r.games||[]).map(catqueGameToPublishedDutchGame);
  });
}

function publishedDutchResultToCatQue(result,{preview=false}={}){
  const pairings=Array.isArray(result?.pairings)
    ? result.pairings
    : (Array.isArray(result?.games) ? result.games : []);

  const byes=Array.isArray(result?.byes) ? result.byes : [];
  const games=[];
  let board=1;

  for(const g of pairings){
    games.push({
      id:preview?`exact-dutch-preview-${board}`:uid(),
      board:board++,
      white:String(g.white),
      black:String(g.black),
      result:'',
      bye:false,
      dutchStyle:true,
      fideDutch:true,
      exactFideDutch:true,
      exactEngine:'@echecs/swiss@5.0.0'
    });
  }

  for(const b of byes){
    const player=String(b.player ?? b.white ?? '');
    if(!player)continue;
    games.push({
      id:preview?`exact-dutch-preview-bye-${board}`:uid(),
      board:board++,
      white:player,
      black:null,
      result:'BYE',
      bye:true,
      byeType:'pairing',
      dutchStyle:true,
      fideDutch:true,
      exactFideDutch:true,
      exactEngine:'@echecs/swiss@5.0.0'
    });
  }

  return games;
}

async function dutchStyleSwissPair(players,{preview=false}={}){
  let exactPair;
  try{
    if(typeof window.ensureFideDutchExact!=='function'){
      throw new Error('Exact FIDE Dutch engine loader is not available.');
    }
    exactPair=await window.ensureFideDutchExact();
  }catch(err){
    if(!preview){
      showToast(
        'The exact FIDE Dutch C.04.3 engine could not load. CatQue will NOT substitute Flexible Swiss.',
        'error',
        'Exact Dutch engine unavailable'
      );
    }
    console.error('Exact FIDE Dutch engine load failed:',err);
    return null;
  }

  try{
    const exactPlayers=catqueToExactDutchPlayers(players);
    const gamesByRound=catqueToPublishedDutchGamesByRound();

    // Published @echecs/swiss v5 API:
    // pair(Player[], Game[][])
    const result=exactPair(exactPlayers,gamesByRound);
    if(!preview)window.__catqueExactDutchPreviewGames=null;

    const games=publishedDutchResultToCatQue(result,{preview});
    const expectedBoards=Math.floor(players.length/2);
    if(games.filter(g=>!g.bye).length!==expectedBoards){
      throw new Error(
        `Exact engine returned ${games.filter(g=>!g.bye).length} played board(s); ${expectedBoards} expected.`
      );
    }

    if(!preview){
      state.settings.dutchEngine='@echecs/swiss@5.0.0';
      state.settings.dutchRule='FIDE C.04.3';
      state.settings.dutchExact=true;
      state.settings.dutchApi='Game[][]';
      state.settings.dutchTpnLocked=true;
    }
    return games;
  }catch(err){
    if(!preview){
      showToast(
        `Exact FIDE Dutch pairing stopped: ${err?.message||err}. No Flexible fallback was used.`,
        'error',
        'FIDE Dutch pairing blocked'
      );
    }
    console.error('Exact FIDE Dutch pair() failed:',err);
    return null;
  }
}
async function doubleSwissPair(players){
  const base=(state.settings.doubleSwissBase||'dutch')==='flexible'
    ? swissPair(players)
    : await dutchStyleSwissPair(players);
  if(!base)return null;
  const out=[];
  let board=1;
  for(const g of base){
    if(g.bye){
      out.push({...g,board:board++});
      continue;
    }
    const matchId=uid();
    out.push({...g,id:uid(),board:board++,matchId,doubleSwissGame:1});
    out.push({id:uid(),board:board++,white:g.black,black:g.white,result:'',bye:false,matchId,doubleSwissGame:2});
  }
  return out;
}
function roundRobinSchedule(){
  let arr=[...state.players];
  if(arr.length%2)arr.push({id:'BYE',name:'BYE'});
  const n=arr.length, schedules=[];
  let work=[...arr];
  for(let r=0;r<n-1;r++){
    const games=[];
    for(let i=0;i<n/2;i++){
      const a=work[i],b=work[n-1-i];
      if(a.id==='BYE'||b.id==='BYE'){
        const real=a.id==='BYE'?b:a; games.push({id:uid(),board:games.length+1,white:real.id,black:null,result:'BYE',bye:true,byeType:'pairing'});
      }else{
        const reverse=(r+i)%2===1;games.push({id:uid(),board:games.length+1,white:reverse?b.id:a.id,black:reverse?a.id:b.id,result:'',bye:false});
      }
    }
    schedules.push(games);
    work=[work[0],work[n-1],...work.slice(1,n-1)];
  }
  if(state.settings.roundRobinType==='double'){
    const second=schedules.map(round=>round.map(g=>{
      if(g.bye)return {...g,id:uid()};
      return {...g,id:uid(),white:g.black,black:g.white,result:''};
    }));
    return [...schedules,...second];
  }
  return schedules;
}
function knockoutPair(){
  if(state.rounds.length===0){
    const seeded=state.settings.knockoutSeeding==='random'
      ? [...state.players]
      : [...state.players].sort((a,b)=>(b.unrated?0:b.rating||0)-(a.unrated?0:a.rating||0)||a.name.localeCompare(b.name));
    const games=[];let board=1;
    while(seeded.length){
      const a=seeded.shift(),b=seeded.pop();
      if(!b)games.push({id:uid(),board:board++,white:a.id,black:null,result:'BYE',bye:true,byeType:'pairing'});
      else games.push({id:uid(),board:board++,white:a.id,black:b.id,result:'',bye:false});
    } return games;
  }
  const prev=currentRound(); const winners=[];
  for(const g of prev.games){
    if(g.bye)winners.push(getPlayer(g.white));
    else if(g.result==='1-0'||g.result==='1F-0F')winners.push(getPlayer(g.white));
    else if(g.result==='0-1'||g.result==='0F-1F')winners.push(getPlayer(g.black));
    else {alert('Knockout games must have a winner. Resolve draws before generating the next round.');return null;}
  }
  if(winners.length<=1){alert('Knockout tournament already has a champion.');return null;}
  const games=[];let board=1;
  for(let i=0;i<winners.length;i+=2){
    const a=winners[i],b=winners[i+1];
    if(!b)games.push({id:uid(),board:board++,white:a.id,black:null,result:'BYE',bye:true,byeType:'pairing'});
    else {const [w,bl]=chooseColors(a,b);games.push({id:uid(),board:board++,white:w,black:bl,result:'',bye:false});}
  } return games;
}

function teamKeyForPlayer(p){
  return delegationLabel(p)||p.school||p.town||p.region||'Unassigned';
}
function getTeams(){
  const map=new Map();
  for(const p of state.players){
    const key=teamKeyForPlayer(p);
    if(!map.has(key))map.set(key,[]);
    map.get(key).push(p);
  }
  return [...map.entries()].map(([name,players])=>({
    name,
    players:players.sort((a,b)=>(b.unrated?0:b.rating)-(a.unrated?0:a.rating)||a.name.localeCompare(b.name)),
    avgRating:players.length?players.reduce((s,p)=>s+(p.unrated?0:p.rating),0)/players.length:0
  }));
}
function teamMatchWasPlayed(rnd,m){
  if(!m||m.bye)return false;
  const games=(rnd?.games||[]).filter(g=>g.matchId===m.id && !g.teamBoardForfeit);
  return games.some(g=>isOverTheBoardResult(g.result));
}
function teamHistory(){
  const teams=getTeams();
  const h={};
  teams.forEach((t,i)=>h[t.name]={matchPoints:0,boardPoints:0,wins:0,opponents:[],bye:0,forfeitMatchWins:0,matchesPlayed:0,tpn:i+1});
  for(const rnd of state.rounds){
    if(!rnd.teamMatches)continue;
    for(const m of rnd.teamMatches){
      if(m.bye){
        if(h[m.teamA] && (state.settings.teamFormat||'swiss')==='swiss'){
          // Current FIDE Team Swiss default: a PAB receives the score of a drawn match.
          h[m.teamA].matchPoints+=(state.settings.teamMatchDraw??1);
          h[m.teamA].boardPoints+=(state.settings.teamBoards||4)*0.5;
          h[m.teamA].bye++;
        }
        // Team Round Robin BYE is a scheduled sit-out and scores zero.
        continue;
      }
      if(!h[m.teamA]||!h[m.teamB])continue;
      const regular=teamMatchWasPlayed(rnd,m);
      if(regular){
        h[m.teamA].opponents.push(m.teamB);h[m.teamB].opponents.push(m.teamA);
        h[m.teamA].matchesPlayed++;h[m.teamB].matchesPlayed++;
      }
      const games=rnd.games.filter(g=>g.matchId===m.id);
      let aBP=0,bBP=0,complete=true;
      for(const g of games){
        if(g.teamBoardForfeit){
          const presentTeam=g.whiteTeam;
          if(presentTeam===m.teamA)aBP+=1;else if(presentTeam===m.teamB)bBP+=1;
          continue;
        }
        if(!g.result){complete=false;continue;}
        let w=0,b=0;
        if(g.result==='1-0'||g.result==='1F-0F')w=1;
        else if(g.result==='0-1'||g.result==='0F-1F')b=1;
        else if(g.result==='½-½'){w=.5;b=.5;}
        if(g.whiteTeam===m.teamA){aBP+=w;bBP+=b;}else{aBP+=b;bBP+=w;}
      }
      h[m.teamA].boardPoints+=aBP;h[m.teamB].boardPoints+=bBP;
      const competitiveGames=games.filter(g=>!g.teamBoardForfeit);
      const matchByForfeit=complete && competitiveGames.length>0 && !competitiveGames.some(g=>isOverTheBoardResult(g.result)) && competitiveGames.every(g=>isForfeitResult(g.result));
      if(complete){
        if(aBP>bBP){h[m.teamA].matchPoints+=(state.settings.teamMatchWin??2);h[m.teamA].wins++;if(matchByForfeit)h[m.teamA].forfeitMatchWins++;}
        else if(bBP>aBP){h[m.teamB].matchPoints+=(state.settings.teamMatchWin??2);h[m.teamB].wins++;if(matchByForfeit)h[m.teamB].forfeitMatchWins++;}
        else{h[m.teamA].matchPoints+=(state.settings.teamMatchDraw??1);h[m.teamB].matchPoints+=(state.settings.teamMatchDraw??1);}
      }
    }
  }
  return h;
}
function teamPlayed(a,b){
  return state.rounds.some(r=>(r.teamMatches||[]).some(m=>!m.bye&&((m.teamA===a&&m.teamB===b)||(m.teamA===b&&m.teamB===a))&&teamMatchWasPlayed(r,m)));
}
function buildTeamMatch(teamA,teamB,matchNo,roundNo){
  const boards=Math.max(1,state.settings.teamBoards||4);
  const matchId=uid(),games=[];
  for(let i=0;i<boards;i++){
    const a=teamA.players[i],b=teamB.players[i];
    if(!a&&!b)continue;
    if(a&&!b){games.push({id:uid(),board:i+1,white:a.id,black:null,result:'BYE',bye:true,byeType:'team-board-forfeit',teamBoardForfeit:true,matchId,whiteTeam:teamA.name,blackTeam:teamB.name,teamBoard:true});continue;}
    if(!a&&b){games.push({id:uid(),board:i+1,white:b.id,black:null,result:'BYE',bye:true,byeType:'team-board-forfeit',teamBoardForfeit:true,matchId,whiteTeam:teamB.name,blackTeam:teamA.name,teamBoard:true});continue;}
    const aWhite=((roundNo+i)%2===0);
    games.push({id:uid(),board:i+1,white:aWhite?a.id:b.id,black:aWhite?b.id:a.id,result:'',bye:false,matchId,whiteTeam:aWhite?teamA.name:teamB.name,blackTeam:aWhite?teamB.name:teamA.name,teamBoard:true});
  }
  return {match:{id:matchId,number:matchNo,teamA:teamA.name,teamB:teamB.name,bye:false},games};
}
function conflictFreeTeamPairs(pool){
  const search=remaining=>{
    if(!remaining.length)return [];
    const a=remaining[0], rest=remaining.slice(1);
    const candidates=rest.filter(b=>!teamPlayed(a.name,b.name));
    for(const b of candidates){
      const tail=rest.filter(x=>x.name!==b.name);
      const found=search(tail);
      if(found)return [[a,b],...found];
    }
    return null;
  };
  return search(pool);
}
function generateTeamSwissRound(){
  const teams=getTeams(),h=teamHistory();
  const ordered=[...teams].sort((a,b)=>(h[b.name]?.matchPoints||0)-(h[a.name]?.matchPoints||0)||(h[b.name]?.boardPoints||0)-(h[a.name]?.boardPoints||0)||b.avgRating-a.avgRating||a.name.localeCompare(b.name));
  const byeCandidates=ordered.filter(t=>(h[t.name]?.bye||0)===0&&(h[t.name]?.forfeitMatchWins||0)===0).sort((a,b)=>(h[a.name]?.matchPoints||0)-(h[b.name]?.matchPoints||0)||(h[b.name]?.matchesPlayed||0)-(h[a.name]?.matchesPlayed||0)||(h[b.name]?.tpn||0)-(h[a.name]?.tpn||0));
  const tries=ordered.length%2?byeCandidates:[null];
  for(const bye of tries){
    const pool=bye?ordered.filter(t=>t.name!==bye.name):ordered;
    const pairs=conflictFreeTeamPairs(pool);
    if(!pairs)continue;
    const teamMatches=[],games=[];
    if(bye){const id=uid();teamMatches.push({id,number:1,teamA:bye.name,teamB:null,bye:true});}
    let n=teamMatches.length+1;
    for(const [a,b] of pairs){const built=buildTeamMatch(a,b,n++,state.rounds.length+1);teamMatches.push(built.match);games.push(...built.games);}
    return {teamMatches,games};
  }
  showToast('No legal Team Swiss pairing exists without repeating a team opponent. Pairing stopped instead of forcing a repeat.','error','Team pairing blocked');
  return null;
}
function teamRoundRobinSchedule(){
  let teams=getTeams().map(t=>t.name);
  if(teams.length%2)teams.push('BYE');
  const all=[],n=teams.length;
  let work=[...teams];
  for(let r=0;r<n-1;r++){
    const matches=[];
    for(let i=0;i<n/2;i++){
      const a=work[i],b=work[n-1-i];
      matches.push([a,b]);
    }
    all.push(matches);
    work=[work[0],work[n-1],...work.slice(1,n-1)];
  }
  return all;
}
function generateTeamRound(){
  const teams=getTeams();
  if(teams.length<2){alert('A team tournament needs at least 2 different delegations/teams.');return null;}
  if((state.settings.teamFormat||'swiss')==='roundrobin'){
    const sched=teamRoundRobinSchedule();
    const idx=state.rounds.length;
    if(idx>=sched.length){alert('Team Round Robin is complete.');return null;}
    const teamMap=new Map(teams.map(t=>[t.name,t]));
    const teamMatches=[],games=[];
    let no=1;
    for(const [aName,bName] of sched[idx]){
      if(aName==='BYE'||bName==='BYE'){
        const real=aName==='BYE'?bName:aName;
        teamMatches.push({id:uid(),number:no++,teamA:real,teamB:null,bye:true,byeType:'roundrobin-sitout'});
      }else{
        const built=buildTeamMatch(teamMap.get(aName),teamMap.get(bName),no++,idx+1);
        teamMatches.push(built.match);games.push(...built.games);
      }
    }
    return {teamMatches,games};
  }
  return generateTeamSwissRound();
}
function teamStandings(){
  const h=teamHistory();
  const rosterOrder=new Map(getTeams().map((t,i)=>[t.name,i]));
  const arr=getTeams().map(t=>({...t,...(h[t.name]||{})}))
    .sort((a,b)=>(b.matchPoints||0)-(a.matchPoints||0)||(b.boardPoints||0)-(a.boardPoints||0)||(b.wins||0)-(a.wins||0)||(rosterOrder.get(a.name)||0)-(rosterOrder.get(b.name)||0));
  let last=null,lastRank=0;
  arr.forEach((t,i)=>{const key=`${t.matchPoints||0}|${t.boardPoints||0}|${t.wins||0}`;if(key!==last){lastRank=i+1;last=key;}t.rank=lastRank;});
  return arr;
}

async function generateNextRound(skipHistory=false){
  // Capture any currently selected result before validating the round.
  syncVisibleResults();
  persist();

  // Do not call syncSettings() here because tournament format/settings
  // are already fixed for the active tournament and the dashboard mode field is locked.
  if(state.players.length<2){alert('Register at least 2 players first.');return;}
  const cur=currentRound();
  if(cur && cur.games.some(g=>!g.bye&&!g.result)){
    alert('Please select a result for every played game before ending this round.');
    return;
  }

  // A completed round must be explicitly ended before another round is generated.
  if(cur && !cur.finalized){
    endCurrentRound();
    return;
  }

  if(state.settings.mode!=='knockout' && state.rounds.length>=state.settings.rounds){
    const finalPending=currentRound()?.games?.filter(g=>!g.bye&&!g.result).length||0;
    if(finalPending>0){
      showToast(`This is the final round. Complete the remaining ${finalPending} result(s) to show the official final result.`,'info','Final round');
      goTab('pairings');
      setTimeout(()=>scrollToPendingBoard(),80);
      return;
    }
    showFinalTournamentResult();
    return;
  }
  let games;
  if(state.settings.mode==='swiss'){
    const v=state.settings.swissVariant||'flexible';
    if(shouldRandomizeSchoolRoundOne()){
      games=randomSchoolRoundOnePair(state.players);
    }else if(v==='dutch')games=await dutchStyleSwissPair(state.players);
    else if(v==='accelerated')games=acceleratedSwissPair(state.players);
    else if(v==='double')games=await doubleSwissPair(state.players);
    else games=swissPair(state.players);
  }
  if(state.settings.mode==='team'){
    const teamRound=generateTeamRound();
    if(!teamRound)return;
    if(!skipHistory)pushHistory(`Generate Round ${state.rounds.length+1}`);
    state.rounds.push({number:state.rounds.length+1,games:teamRound.games,teamMatches:teamRound.teamMatches,finalized:false});
    persist();renderAll();goTab('pairings');
    showToast(`Round ${state.rounds.length} generated successfully.`,'success','Pairings ready');
    return;
  }
  if(state.settings.mode==='roundrobin'){
    const sched=roundRobinSchedule();
    if(state.rounds.length>=sched.length){alert('Round Robin schedule is complete.');return;}
    games=sched[state.rounds.length];
  }
  if(state.settings.mode==='knockout')games=knockoutPair();
  if(!games)return;

  if(state.settings.mode==='swiss'){
    const check=validateSwissAbsoluteCriteria(games,{doubleSwiss:state.settings.swissVariant==='double'});
    if(!check.ok){showToast(check.message,'error','Pairing blocked');return;}
  }

  if(!skipHistory)pushHistory(`Generate Round ${state.rounds.length+1}`);
  state.rounds.push({number:state.rounds.length+1,games,finalized:false});
  persist();renderAll();goTab('pairings');
  showToast(`Round ${state.rounds.length} generated successfully.`,'success','Pairings ready');
}

function openEditRoundModal(){
  syncVisibleResults();
  persist();

  if(!state.rounds.length){
    alert('There are no generated rounds to edit yet.');
    return;
  }

  const select=document.getElementById('editRoundSelect');
  select.innerHTML=state.rounds
    .map(r=>`<option value="${r.number}" ${r.number===currentRound()?.number?'selected':''}>Round ${r.number}</option>`)
    .join('');

  renderEditRoundGames();
  document.getElementById('editRoundModal').classList.add('show');
}

function closeEditRoundModal(){
  document.getElementById('editRoundModal').classList.remove('show');
}

function selectedEditRound(){
  const n=+document.getElementById('editRoundSelect')?.value;
  return state.rounds.find(r=>r.number===n)||null;
}

function renderEditRoundGames(){
  const r=selectedEditRound();
  const box=document.getElementById('editRoundGames');
  const warning=document.getElementById('editRoundWarning');
  if(!r||!box)return;

  const hasLater=state.rounds.some(x=>x.number>r.number);
  if(warning){
    warning.style.display=hasLater?'block':'none';
    warning.innerHTML=hasLater
      ? `<b>Important:</b> You are editing Round ${r.number}, but later rounds already exist. Correcting this result will recalculate scores, rankings, and tie-breaks. Existing later-round pairings will remain as originally generated.`
      : '';
  }

  if(state.settings.mode==='team' && r.teamMatches){
    box.innerHTML=r.teamMatches.map(m=>{
      if(m.bye){
        return `<div class="pair-card"><b>Team Match ${m.number}: ${esc(m.teamA)}</b> — TEAM BYE</div>`;
      }
      const games=r.games.filter(g=>g.matchId===m.id).sort((a,b)=>a.board-b.board);
      return `<div class="pair-card">
        <h3>Match ${m.number}: ${esc(m.teamA)} vs ${esc(m.teamB)}</h3>
        <table>
          <thead><tr><th>Board</th><th>White</th><th>Correct Result</th><th>Black</th></tr></thead>
          <tbody>${games.map(g=>{
            const w=getPlayer(g.white),b=getPlayer(g.black);
            if(g.bye){
              return `<tr><td>${g.board}</td><td>${esc(playerDisplay(w))}</td><td>BYE</td><td>—</td></tr>`;
            }
            return `<tr>
              <td>${g.board}</td>
              <td>${esc(w?.name||'')}<br><small>${esc(g.whiteTeam||'')}</small></td>
              <td><select data-edit-round-result="${g.id}">${resultOptions(g.result)}</select></td>
              <td>${esc(b?.name||'')}<br><small>${esc(g.blackTeam||'')}</small></td>
            </tr>`;
          }).join('')}</tbody>
        </table>
      </div>`;
    }).join('');
    return;
  }

  box.innerHTML=`<table>
    <thead><tr><th>Board</th><th>White</th><th>Correct Result</th><th>Black</th></tr></thead>
    <tbody>${[...r.games].sort((a,b)=>a.board-b.board).map(g=>{
      const w=getPlayer(g.white),b=getPlayer(g.black);
      if(g.bye){
        return `<tr>
          <td><b>${g.board}</b></td>
          <td>${esc(playerDisplay(w))}</td>
          <td><span class="badge gold">BYE</span></td>
          <td>—</td>
        </tr>`;
      }
      return `<tr>
        <td><b>${g.board}</b></td>
        <td>${esc(playerDisplay(w))}</td>
        <td><select data-edit-round-result="${g.id}">${resultOptions(g.result)}</select></td>
        <td>${esc(playerDisplay(b))}</td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

async function saveEditedRound(){
  const r=selectedEditRound();
  if(!r)return;

  const hasLater=state.rounds.some(x=>x.number>r.number);
  if(hasLater){
    const ok=await appConfirm(
      `Save corrections to Round ${r.number}? Rankings and tie-breaks will be recalculated, but already-generated later pairings will NOT be changed.`,
      {title:'Correct Earlier Round',confirmText:'Save Corrections',danger:false}
    );
    if(!ok)return;
  }

  const wasOfficialFinal=typeof isTournamentFinalResult==='function' && isTournamentFinalResult();
  pushHistory(`Edit results — Round ${r.number}`);

  document.querySelectorAll('[data-edit-round-result]').forEach(sel=>{
    const g=r.games.find(x=>x.id===sel.dataset.editRoundResult);
    if(g)g.result=sel.value;
  });

  // Any correction after a declared final result returns the event to provisional status.
  const last=currentRound();
  const invalidatedFinal=wasOfficialFinal;
  if(invalidatedFinal){last.finalized=false;delete last.finalizedAt;state.settings.finalResultInvalidatedAt=new Date().toISOString();}

  persist();
  renderAll();
  renderPairingsRanking();
  closeEditRoundModal();

  const status=document.getElementById('saveStatus');
  if(status){
    status.textContent=`Round ${r.number} corrected`;
    setTimeout(()=>status.textContent='Ready',1200);
  }

  showToast(invalidatedFinal?`Round ${r.number} corrected. The previous Final Result is now provisional; re-confirm the Final Round after review.`:`Round ${r.number} corrections saved. Rankings and tie-breaks were recalculated.`,'success',invalidatedFinal?'Final result invalidated':'Round corrected');
}

async function rebuildCurrentRound(){
  if(!state.rounds.length){generateNextRound();return;}
  if(!await appConfirm('Regenerate the current round? Any entered results in this round will be lost.',{title:'Regenerate Round',confirmText:'Regenerate'}))return;
  pushHistory(`Regenerate Round ${state.rounds.length}`);
  state.rounds.pop();persist();generateNextRound(true);
}

function syncVisibleResults(){
  const r=currentRound();
  if(!r)return;
  document.querySelectorAll('[data-result-id]').forEach(sel=>{
    const g=r.games.find(x=>x.id===sel.dataset.resultId);
    if(g)g.result=sel.value;
  });
}

function updateGameResult(gameId,value){
  const r=currentRound();
  if(!r)return;
  const g=r.games.find(x=>x.id===gameId);
  if(!g)return;
  if(g.result===value)return;
  pushHistory(`Change result — Round ${r.number}, Board ${g.board}`);
  g.result=value;
  persist();
  const status=document.getElementById('saveStatus');
  if(status){
    status.textContent='Result saved';
    setTimeout(()=>status.textContent='Ready',900);
  }

  // Update the current round view and dependent reports immediately.
  renderPairings();
  renderStandings();
  renderPairingsRanking();
  renderDashboard();
  renderReports();
}

function saveResults(){
  const r=currentRound();if(!r)return;
  syncVisibleResults();
  persist();
  renderAll();
  showToast('Round results saved.','success','Saved');
}
function printPairings(){
  buildCleanPairingPrint();
  openPrintPreview({
    title:`Round ${currentRound()?.number||0} Pairings Preview`,
    selector:'#printPairingSheet',
    orientation:'portrait',
    bodyClass:'printing-pairings'
  });
}

function buildRoundResultsPrintSheet(){
  const box=document.getElementById('printRoundResultsSheet');
  const r=currentRound();
  if(!box)return false;
  if(!r){
    showToast('Generate a round first before previewing Round Results.','info','Round Results');
    return false;
  }
  const s=state.settings||{};
  const games=[...(r.games||[])].sort((a,b)=>(a.board||0)-(b.board||0));
  const played=games.filter(g=>!g.bye);
  const completed=played.filter(g=>!!g.result).length;
  const pending=played.length-completed;
  const whiteWins=played.filter(g=>g.result==='1-0'||g.result==='1F-0F').length;
  const blackWins=played.filter(g=>g.result==='0-1'||g.result==='0F-1F').length;
  const draws=played.filter(g=>g.result==='½-½').length;
  const byes=games.filter(g=>g.bye).length;
  const meet=(s.eventScope==='open')?'Open Tournament':String(s.meetLevel||'').toUpperCase();

  const rows=games.map(g=>{
    const w=pairingPrintPlayer(getPlayer(g.white));
    const b=g.bye?null:pairingPrintPlayer(getPlayer(g.black));
    const result=g.bye?(state.settings.mode==='roundrobin'?'BYE':'BYE (+1)'):(g.result||'PENDING');
    return `<tr class="${!g.bye&&!g.result?'pending-result-row':''}">
      <td class="board">${esc(g.board)}</td>
      <td><span class="player-name">${esc(w.name)}</span><span class="delegation">${esc(w.delegation)}</span></td>
      <td class="rating">${esc(w.rating)}</td>
      <td class="result"><b>${esc(result)}</b></td>
      <td>${g.bye?'—':`<span class="player-name">${esc(b.name)}</span><span class="delegation">${esc(b.delegation)}</span>`}</td>
      <td class="rating">${g.bye?'—':esc(b.rating)}</td>
    </tr>`;
  }).join('');

  box.innerHTML=`
    <div class="print-round-results-document">
      <div class="print-pairing-header">
        <div class="print-brand-line print-brand-center"><img src="assets/catque-logo.png" alt="CatQue"><span>CATQUE TOURNAMENT MANAGER</span></div>
        <h1>${esc(s.name||'Chess Tournament')}</h1>
        <div class="category">${esc(s.tournamentCategory||'Open')}</div>
        <div class="round-title">ROUND ${esc(r.number)} — RESULTS</div>
      </div>
      <div class="print-meta">
        <div><b>Format:</b> ${esc(cleanFormatName())}</div>
        <div><b>Event:</b> ${esc(meet||'—')}</div>
        <div><b>Date:</b> ${esc(s.date||'—')}</div>
        <div><b>Time Control:</b> ${esc(s.timeControl||'—')}</div>
        <div><b>Venue:</b> ${esc(s.venue||'—')}</div>
        <div><b>Status:</b> ${pending===0?'Complete':`${pending} result(s) pending`}</div>
      </div>
      <div class="round-results-summary">
        <div><b>${completed}</b><span>Completed</span></div>
        <div><b>${whiteWins}</b><span>White Wins</span></div>
        <div><b>${draws}</b><span>Draws</span></div>
        <div><b>${blackWins}</b><span>Black Wins</span></div>
        <div><b>${byes}</b><span>Byes</span></div>
      </div>
      <table class="print-pairing-table print-results-table">
        <colgroup><col style="width:7%"><col style="width:32%"><col style="width:8%"><col style="width:13%"><col style="width:32%"><col style="width:8%"></colgroup>
        <thead><tr><th>Board</th><th>White</th><th>Rtg</th><th>Result</th><th>Black</th><th>Rtg</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="print-signatures">
        <div class="print-signature"><div class="name">${esc(s.chiefArbiter||'')}</div><div class="line">Chief Arbiter</div></div>
        <div class="print-signature"><div class="name">${esc(s.tournamentDirector||'')}</div><div class="line">Tournament Director (TD)</div></div>
      </div>
      <div class="catque-print-footer">Generated by CatQue Tournament Manager • Round ${esc(r.number)} Results</div>
    </div>`;
  return true;
}

function printRoundResults(){
  if(!buildRoundResultsPrintSheet())return;
  openPrintPreview({
    title:`Round ${currentRound()?.number||0} Results Preview`,
    selector:'#printRoundResultsSheet',
    orientation:'portrait',
    bodyClass:'printing-round-results'
  });
}

function pairingPrintPlayer(p){
  if(!p)return {name:'—',delegation:'',rating:'—'};
  ensurePlayerStructuredName(p);
  return {
    name:p.name||'—',
    delegation:compactDelegationLabel(p)||p.school||'',
    rating:ratingText(p)
  };
}

function cleanFormatName(){
  if(state.settings.mode==='swiss'){
    const v={
      flexible:'Flexible / Practical Swiss',
      dutch:'FIDE Dutch Swiss',
      accelerated:'Accelerated Swiss',
      double:'Double Swiss'
    }[state.settings.swissVariant||'flexible'];
    return `Swiss System — ${v}`;
  }
  if(state.settings.mode==='roundrobin'){
    return state.settings.roundRobinType==='double'?'Double Round Robin':'Round Robin';
  }
  if(state.settings.mode==='team'){
    return (state.settings.teamFormat||'swiss')==='swiss'?'Team Swiss':'Team Round Robin';
  }
  if(state.settings.mode==='knockout')return 'Knockout';
  return modeName(state.settings.mode);
}

function buildCleanPairingPrint(){
  const sheet=document.getElementById('printPairingSheet');
  const r=currentRound();
  if(!sheet)return;

  if(!r){
    sheet.innerHTML='<div style="font-family:Arial;color:#000">No round generated yet.</div>';
    return;
  }

  const s=state.settings;
  const category=s.tournamentCategory||s.category||'';
  const meet=(s.meetLevel||'').replace(/^\w/,c=>c.toUpperCase());

  let rows='';

  if(state.settings.mode==='team' && r.teamMatches){
    let displayBoard=1;
    for(const m of r.teamMatches){
      if(m.bye){
        rows+=`<tr>
          <td class="board">${displayBoard++}</td>
          <td colspan="2"><span class="player-name">${esc(m.teamA)}</span></td>
          <td class="result">TEAM BYE</td>
          <td colspan="2">—</td>
        </tr>`;
        continue;
      }
      const games=r.games.filter(g=>g.matchId===m.id).sort((a,b)=>a.board-b.board);
      for(const g of games){
        const w=pairingPrintPlayer(getPlayer(g.white));
        const b=pairingPrintPlayer(getPlayer(g.black));
        rows+=`<tr>
          <td class="board">${esc(g.board)}</td>
          <td><span class="player-name">${esc(w.name)}</span><span class="delegation">${esc(g.whiteTeam||w.delegation)}</span></td>
          <td class="rating">${esc(w.rating)}</td>
          <td class="result">${esc(g.bye?'BYE':(g.result||'________'))}</td>
          <td><span class="player-name">${esc(b.name)}</span><span class="delegation">${esc(g.blackTeam||b.delegation)}</span></td>
          <td class="rating">${esc(b.rating)}</td>
        </tr>`;
      }
    }
  }else{
    for(const g of [...r.games].sort((a,b)=>a.board-b.board)){
      const w=pairingPrintPlayer(getPlayer(g.white));
      const b=pairingPrintPlayer(getPlayer(g.black));
      rows+=`<tr>
        <td class="board">${esc(g.board)}</td>
        <td><span class="player-name">${esc(w.name)}</span><span class="delegation">${esc(w.delegation)}</span></td>
        <td class="rating">${esc(w.rating)}</td>
        <td class="result">${esc(g.bye?'BYE':(g.result||'________'))}</td>
        <td>${g.bye?'—':`<span class="player-name">${esc(b.name)}</span><span class="delegation">${esc(b.delegation)}</span>`}</td>
        <td class="rating">${g.bye?'—':esc(b.rating)}</td>
      </tr>`;
    }
  }

  sheet.innerHTML=`
    <div class="print-pairing-header">
      <div class="print-brand-line print-brand-center"><img src="assets/catque-logo.png" alt="CatQue"><span>CATQUE TOURNAMENT MANAGER</span></div>
      <h1>${esc(s.name||'Chess Tournament')}</h1>
      ${category?`<div class="category">${esc(category)}</div>`:''}
      <div class="round-title">PAIRINGS — ROUND ${esc(r.number)}</div>
    </div>

    <div class="print-meta">
      <div><b>Format:</b> ${esc(cleanFormatName())}</div>
      <div><b>Meet Level:</b> ${esc(meet||'—')}</div>
      <div><b>Date:</b> ${esc(s.date||'—')}</div>
      <div><b>Time Control:</b> ${esc(s.timeControl||'—')}</div>
      <div><b>Venue:</b> ${esc(s.venue||'—')}</div>
      <div><b>Players:</b> ${state.players.length}</div>
    </div>

    <table class="print-pairing-table">
      <colgroup>
        <col style="width:7%">
        <col style="width:32%">
        <col style="width:8%">
        <col style="width:11%">
        <col style="width:34%">
        <col style="width:8%">
      </colgroup>
      <thead>
        <tr>
          <th>Board</th>
          <th>White</th>
          <th>Rtg</th>
          <th>Result</th>
          <th>Black</th>
          <th>Rtg</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>

    <div class="print-signatures">
      <div class="print-signature">
        <div class="name">${esc(s.chiefArbiter||'')}</div>
        <div class="line">Chief Arbiter</div>
      </div>
      <div class="print-signature">
        <div class="name">${esc(s.tournamentDirector||'')}</div>
        <div class="line">Tournament Director (TD)</div>
      </div>
    </div>
  `;
}
let roundFocusMode=false;
function toggleRoundFocusMode(){
  roundFocusMode=!roundFocusMode;
  document.body.classList.toggle('round-focus-mode',roundFocusMode);
  const btn=document.getElementById('focusRoundBtn');
  if(btn)btn.textContent=roundFocusMode?'Exit Focus Mode':'⛶ Focus Mode';
  if(roundFocusMode)window.scrollTo({top:0,behavior:'smooth'});
}
function firstPendingGame(){
  const r=currentRound();
  return r?.games?.find(g=>!g.bye&&!g.result)||null;
}
function scrollToPendingBoard(){
  const g=firstPendingGame();
  if(!g)return;
  const el=document.querySelector(`[data-board-id="${g.id}"]`);
  if(el)el.scrollIntoView({behavior:'smooth',block:'center'});
}

function isScheduledFinalRound(round=currentRound()){
  if(!round || state.settings.mode==='knockout')return false;
  const total=+state.settings.rounds||0;
  return total>0 && state.rounds.length>=total;
}


function endCurrentRound(){
  syncVisibleResults();
  const round=currentRound();
  if(!round)return;

  const pending=round.games.filter(g=>!g.bye&&!g.result).length;
  if(pending>0){
    showToast(`Round ${round.number} still has ${pending} unfinished result(s).`,'info','Round not finished');
    setTimeout(()=>scrollToPendingBoard(),60);
    return;
  }

  if(round.finalized){
    updateMainRoundAction(round);
    return;
  }

  pushHistory(`End Round ${round.number}`);
  round.finalized=true;
  round.finalizedAt=new Date().toISOString();
  if(isScheduledFinalRound(round))delete state.settings.finalResultInvalidatedAt;
  persist();
  renderStandings?.();
  renderPairingsRanking?.();
  renderDashboard?.();
  renderReports?.();
  renderPairings();

  if(isScheduledFinalRound(round)){
    showToast(`Round ${round.number} ended. Tournament is complete.`,'success','Tournament complete');
    setTimeout(()=>showFinalTournamentResult(),120);
  }else{
    showToast(`Round ${round.number} ended. Review the ranking, then generate the next round when ready.`,'success','Round ended');
  }
}

function showFinalTournamentResult(){
  renderStandings?.();
  goTab('standings');
  setTimeout(()=>{
    const heading=document.querySelector('#standings h3');
    if(heading && typeof isTournamentFinalResult==='function' && isTournamentFinalResult()){
      heading.textContent='Final Result';
    }
    showToast('Tournament completed. Official final ranking is now shown.','success','Final Result');
    window.scrollTo?.({top:0,behavior:'smooth'});
  },30);
}

function updateMainRoundAction(round=currentRound()){
  const btn=document.getElementById('mainRoundActionBtn');
  const label=document.getElementById('mainRoundActionText');
  if(!btn||!label)return;

  btn.disabled=false;

  if(!round){
    label.textContent='Generate Round 1';
    btn.onclick=()=>generateNextRound();
    btn.title=state.players.length<2?'Add at least 2 players first.':'Generate the first round.';
    return;
  }

  const pending=round.games.filter(g=>!g.bye&&!g.result).length;
  const finalRound=isScheduledFinalRound(round);

  if(pending>0){
    label.textContent=`Complete Round ${round.number} (${pending} left)`;
    btn.onclick=()=>scrollToPendingBoard();
    btn.title='Go to the next board without a result.';
    return;
  }

  if(!round.finalized){
    label.textContent=finalRound?'End Final Round':'End Round';
    btn.onclick=()=>endCurrentRound();
    btn.title='Confirm that this round is complete.';
    return;
  }

  if(finalRound){
    label.textContent='View Final Result';
    btn.onclick=()=>showFinalTournamentResult();
    btn.title='Open the official final ranking.';
    return;
  }

  label.textContent='Generate Next Round';
  btn.onclick=()=>generateNextRound();
  btn.title='Generate the next scheduled round.';
}

function updateRoundStickyBar(round=currentRound()){
  const title=document.getElementById('roundStickyTitle');
  const help=document.getElementById('roundStickyHelp');
  const primary=document.getElementById('roundStickyPrimary');
  if(!title||!help||!primary)return;

  if(!round){
    title.textContent='Ready to start';
    help.textContent=`${state.players.length} player(s) registered. Generate Round 1 when ready.`;
    primary.textContent='Generate Round 1';
    primary.disabled=state.players.length<2;
    primary.onclick=()=>generateNextRound();
    return;
  }
  const pending=round.games.filter(g=>!g.bye&&!g.result).length;
  const played=round.games.filter(g=>!g.bye).length;
  if(pending>0){
    title.textContent=`Round ${round.number} • ${pending} result(s) left`;
    help.textContent=`${played-pending}/${played} played boards completed.`;
    primary.textContent='Go to Next Unfinished Board';
    primary.disabled=false;
    primary.onclick=()=>scrollToPendingBoard();
  }else{
    title.textContent=`Round ${round.number} complete`;
    help.textContent='All results are encoded and auto-saved.';
    const allDone=isScheduledFinalRound(round);
    primary.textContent=allDone?'View Final Result':'Generate Next Round';
    primary.disabled=false;
    primary.onclick=allDone?(()=>showFinalTournamentResult()):(()=>generateNextRound());
  }
}

function resultOptions(value){
  const opts=['','1-0','0-1','½-½','1F-0F','0F-1F'];
  return opts.map(o=>`<option ${o===value?'selected':''} value="${o}">${o||'Select result'}</option>`).join('');
}
function renderPairingsSummaryCards(round){
  const box=document.getElementById('pairingsSummaryCards');
  if(!box)return;
  const current=round||currentRound();
  const boards=current?.games?.filter(g=>!g.bye).length||0;
  const byes=current?.games?.filter(g=>g.bye).length||0;
  const done=current?.games?.filter(g=>g.bye||g.result).length||0;
  const total=current?.games?.length||0;
  const pending=Math.max(total-done,0);
  box.innerHTML=[
    ['Round', current?.number||0, current ? 'Current active round' : 'No round yet'],
    ['Boards', boards, boards ? 'Games to be played' : 'Waiting for pairings'],
    ['Pending', pending, pending ? 'Results still to encode' : 'All boards encoded'],
    ['Byes', byes, byes ? 'Automatic pairing bye(s)' : 'No bye in this round']
  ].map(([label,value,sub])=>`<div class="summary-card-mini"><div class="label">${esc(label)}</div><div class="value">${value}</div><div class="sub">${esc(sub)}</div></div>`).join('');
}

function resultChipButtons(g){
  const options=[
    ['1-0','White Win'],
    ['½-½','Draw'],
    ['0-1','Black Win'],
    ['1F-0F','White Forfeit'],
    ['0F-1F','Black Forfeit']
  ];
  return `<div class="result-chip-row">${options.map(([value,label])=>`<button type="button" class="result-chip ${g.result===value?'active':''}" onclick="updateGameResult('${g.id}','${value}')">${esc(label)}</button>`).join('')}<select class="result-chip-select" data-result-id="${g.id}" onchange="updateGameResult('${g.id}',this.value)">${resultOptions(g.result)}</select></div>`;
}

function renderPairings(){
  const r=currentRound();
  roundLabel.textContent=r?.number||0;
  renderPairingsSummaryCards(r);
  updateRoundStickyBar(r);
  updateMainRoundAction(r);
  pairingNote.style.display=(state.settings.mode==='swiss'||state.settings.mode==='team')?'block':'none';
  if(state.settings.mode==='swiss'){
    const v=state.settings.swissVariant||'flexible';
    const randomRoundOne=!!r?.games?.some(g=>g.randomSchoolRoundOne);
    if(randomRoundOne){
      pairingNote.textContent=state.settings?.manualRosterShuffle
        ? 'Round 1 uses the Shuffle Players order you selected in the Players screen. From Round 2 onward, normal Swiss score-based pairing is used.'
        : 'School / DepEd unrated Round 1: players were randomly shuffled before pairing. If the roster is odd, the first-round bye is also chosen randomly. From Round 2 onward, normal Swiss score-based pairing is used.';
    }else pairingNote.textContent=v==='dutch'
      ? 'FIDE Dutch Swiss: exact @echecs/swiss v5.0.0 Dutch C.04.3 pairing engine. The engine must pass its built-in self-test; Flexible / Practical Swiss is never used as a fallback.'
      : v==='accelerated'
      ? 'Accelerated Swiss: temporary virtual pairing points are used in the opening rounds; real standings points are unchanged.'
      : v==='double'
      ? 'Double Swiss: each pairing contains two games with reversed colors.'
      : 'Flexible / Practical Swiss: similar scores, repeat-opponent avoidance, and color balancing for school/local events.';
  } else if(state.settings.mode==='team'){
    pairingNote.textContent='Team Tournament: teams are formed from the current meet-level delegation and ranked by Match Points, then Board Points.';
  }

  if(!r){
    pairingsList.innerHTML='<div class="pair-empty-guide"><b>No round generated yet.</b><ol><li>Make sure your roster is complete.</li><li>Click <b>Generate / Next Round</b>.</li><li>Encode the results using the quick buttons, then save.</li></ol></div>';
    return;
  }

  if(state.settings.mode==='team' && r.teamMatches){
    pairingsList.innerHTML=r.teamMatches.map(m=>{
      if(m.bye)return `<div class="pair-card-easy" data-board-id="${m.id}"><div class="pair-bye-easy"><div><div class="board-badge">M${m.number}</div></div><div><b>${esc(m.teamA)}</b></div><div><span class="badge gold">TEAM BYE</span></div></div></div>`;
      const gs=r.games.filter(g=>g.matchId===m.id).sort((a,b)=>a.board-b.board);
      return `<div class="pair-card-easy">
        <div class="pair-card-head"><div><div class="board-badge">M${m.number}</div></div><div><b>${esc(m.teamA)} vs ${esc(m.teamB)}</b></div></div>
        <table class="roster-table-compact"><thead><tr><th>Board</th><th>White</th><th>Result</th><th>Black</th></tr></thead><tbody>
        ${gs.map(g=>{
          const w=getPlayer(g.white),b=getPlayer(g.black);
          if(g.bye)return `<tr><td>${g.board}</td><td>${esc(playerDisplay(w))}</td><td>${g.teamBoardForfeit?'1-0 (missing board)':'BYE'}</td><td>—</td></tr>`;
          return `<tr><td>${g.board}</td><td>${esc(w?.name||'')}<span class="subline">${esc(g.whiteTeam||'')}</span></td><td>${resultChipButtons(g)}</td><td>${esc(b?.name||'')}<span class="subline">${esc(g.blackTeam||'')}</span></td></tr>`;
        }).join('')}</tbody></table>
      </div>`;
    }).join('');
    return;
  }

  pairingsList.innerHTML=r.games.sort((a,b)=>a.board-b.board).map(g=>{
    const w=getPlayer(g.white),b=getPlayer(g.black);
    if(g.bye){
      return `<div class="pair-card-easy" data-board-id="${g.id}"><div class="pair-bye-easy"><div class="board-badge">B${g.board}</div><div><b>${esc(playerDisplay(w))}</b><div class="subline">${esc(compactDelegationLabel(w)||w?.school||'')}</div></div><div><span class="badge gold">PAIRING BYE • +${byePointsForGame(g)===1.5?'1½':byePointsForGame(g)} POINT${byePointsForGame(g)===1?'':'S'}</span></div></div></div>`;
    }
    return `<div class="pair-card-easy" data-board-id="${g.id}">
      <div class="pair-card-head"><div class="board-badge">B${g.board}</div><div class="help">Tap the result below to encode this board.</div></div>
      <div class="pair-players-grid">
        <div class="pair-player-panel">
          <div class="top"><span class="color-dot w">W</span> <b>${esc(w?.name||'')}</b></div>
          <span class="subline">${esc(compactDelegationLabel(w)||w?.school||'')}</span>
          <span class="subline">Rating: ${ratingText(w)}</span>
        </div>
        <div class="pair-vs">VS</div>
        <div class="pair-player-panel">
          <div class="top"><span class="color-dot b">B</span> <b>${esc(b?.name||'')}</b></div>
          <span class="subline">${esc(compactDelegationLabel(b)||b?.school||'')}</span>
          <span class="subline">Rating: ${ratingText(b)}</span>
        </div>
      </div>
      ${resultChipButtons(g)}
    </div>`;
  }).join('');
}
