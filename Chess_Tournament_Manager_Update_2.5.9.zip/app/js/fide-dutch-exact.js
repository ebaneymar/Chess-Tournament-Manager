// CatQue v2.5.9 — exact FIDE Dutch C.04.3 engine loader.
// The pairing implementation is pinned to @echecs/swiss v5.0.0.
// Once fetched successfully it is stored in localStorage and imported from
// the cached source on subsequent launches, including offline launches.

const CATQUE_DUTCH_VERSION='5.0.0';
const CATQUE_DUTCH_ENTRY='https://esm.sh/@echecs/swiss@5.0.0/dutch?bundle&target=es2022';
const CATQUE_DUTCH_CACHE_KEY='catque:fide-dutch-exact:5.0.0:bundle';
const CATQUE_DUTCH_META_KEY='catque:fide-dutch-exact:5.0.0:meta';

let exactDutchPromise=null;

function absoluteEsmUrl(spec){
  return new URL(spec,'https://esm.sh').href;
}

async function fetchPinnedBundleSource(){
  const entryResponse=await fetch(CATQUE_DUTCH_ENTRY,{cache:'no-cache'});
  if(!entryResponse.ok)throw new Error(`Engine download failed (${entryResponse.status}).`);
  let source=await entryResponse.text();

  // esm.sh usually returns a tiny entry module that re-exports the real
  // version-pinned *.bundle.mjs file. Fetch that actual file so the cached
  // source is the executable bundle, not just the redirect wrapper.
  const m=source.match(/(?:from|import)\s*["'](\/[^"']+\.mjs[^"']*)["']/) ||
          source.match(/["'](\/[^"']+\.bundle\.mjs[^"']*)["']/);

  if(m){
    const bundleUrl=absoluteEsmUrl(m[1]);
    const bundleResponse=await fetch(bundleUrl,{cache:'no-cache'});
    if(!bundleResponse.ok)throw new Error(`Pinned bundle download failed (${bundleResponse.status}).`);
    source=await bundleResponse.text();
  }

  // @echecs/swiss has no runtime dependency on @echecs/tournament for Dutch
  // pairing. If a future CDN transform introduces external imports, refuse to
  // cache a partially-online engine rather than pretending it is offline.
  const externalImport=source.match(/(?:from\s*|import\s*)["'](https?:|\/)/);
  if(externalImport){
    throw new Error('Pinned Dutch bundle unexpectedly contains an external runtime import.');
  }

  localStorage.setItem(CATQUE_DUTCH_CACHE_KEY,source);
  localStorage.setItem(CATQUE_DUTCH_META_KEY,JSON.stringify({
    version:CATQUE_DUTCH_VERSION,
    cachedAt:new Date().toISOString(),
    source:'@echecs/swiss',
    rule:'FIDE C.04.3'
  }));
  return source;
}

async function importBundleSource(source){
  const blob=new Blob([source],{type:'text/javascript'});
  const url=URL.createObjectURL(blob);
  try{
    const mod=await import(url);
    if(typeof mod.pair!=='function')throw new Error('pair() export was not found.');
    return mod.pair;
  }finally{
    URL.revokeObjectURL(url);
  }
}

async function loadExactDutch(){
  if(typeof window.__fideDutchExactPair==='function')return window.__fideDutchExactPair;
  if(exactDutchPromise)return exactDutchPromise;

  exactDutchPromise=(async()=>{
    let cached=localStorage.getItem(CATQUE_DUTCH_CACHE_KEY);

    if(cached){
      try{
        const pair=await importBundleSource(cached);
        window.__fideDutchExactPair=pair;
        window.__fideDutchExactReady=true;
        return pair;
      }catch(err){
        console.warn('Cached exact Dutch engine was invalid; refreshing it.',err);
        localStorage.removeItem(CATQUE_DUTCH_CACHE_KEY);
        cached=null;
      }
    }

    const source=await fetchPinnedBundleSource();
    const pair=await importBundleSource(source);
    window.__fideDutchExactPair=pair;
    window.__fideDutchExactReady=true;
    return pair;
  })();

  try{
    return await exactDutchPromise;
  }catch(err){
    window.__fideDutchExactReady=false;
    throw err;
  }finally{
    exactDutchPromise=null;
  }
}

window.ensureFideDutchExact=loadExactDutch;
window.__fideDutchExactVersion=CATQUE_DUTCH_VERSION;

// Preload/cache while the user is still in setup, so tournament pairing later
// does not depend on network access.
loadExactDutch().catch(err=>{
  console.warn('Exact FIDE Dutch engine has not been cached yet:',err);
});
