// Chess Tournament Manager 2.0
// Pairing engines, Swiss safeguards, rounds/results, and pairing print.

function playerHistory(){
  const h={};
  state.players.forEach(p=>h[p.id]={score:0,opp:[],colors:[],wins:0,gamesWon:0,blackWins:0,roundScores:[],bye:0});
  for(const rnd of state.rounds){
    for(const g of rnd.games){
      if(g.bye){
        if(h[g.white]){
          // Swiss pairing-allocated bye = 1 point.
          // Round-Robin scheduled sit-out = 0 points because no game is played.
          const byePoints=state.settings.mode==='roundrobin' ? 0 : state.settings.scoring.bye;
          h[g.white].score += byePoints;
          h[g.white].bye++;
          // FIDE WIN counts a round where full win-points are awarded,
          // even without playing (pairing-allocated/full-point bye).
          if(byePoints===state.settings.scoring.win)h[g.white].wins++;
        }
        continue;
      }
      if(!h[g.white]||!h[g.black])continue;
      h[g.white].opp.push(g.black);
      h[g.black].opp.push(g.white);
      h[g.white].colors.push('W');
      h[g.black].colors.push('B');
      let ws=0,bs=0;
      if(g.result==='1-0'){
        ws=state.settings.scoring.win;bs=state.settings.scoring.loss;
        h[g.white].wins++;
        h[g.white].gamesWon++;
      } else if(g.result==='1F-0F'){
        ws=state.settings.scoring.win;bs=state.settings.scoring.loss;
        h[g.white].wins++;
      } else if(g.result==='0-1'){
        ws=state.settings.scoring.loss;bs=state.settings.scoring.win;
        h[g.black].wins++;
        h[g.black].gamesWon++;
        h[g.black].blackWins++;
      } else if(g.result==='0F-1F'){
        ws=state.settings.scoring.loss;bs=state.settings.scoring.win;
        h[g.black].wins++;
      } else if(g.result==='½-½'){
        ws=state.settings.scoring.draw;bs=state.settings.scoring.draw;
      }
      h[g.white].score+=ws;
      h[g.black].score+=bs;
    }
    // Record the running score once per tournament round, even if a format
    // contains multiple games per pairing (e.g. Double Swiss).
    for(const p of state.players){
      h[p.id].roundScores.push(h[p.id].score);
    }
  }
  return h;
}
function scoreOf(id){return playerHistory()[id]?.score||0;}
function played(a,b){return state.rounds.some(r=>r.games.some(g=>!g.bye&&((g.white===a&&g.black===b)||(g.white===b&&g.black===a))));}
function colorBalance(id){
  const c=playerHistory()[id]?.colors||[]; return c.filter(x=>x==='W').length-c.filter(x=>x==='B').length;
}
function lastColors(id,n=2){return (playerHistory()[id]?.colors||[]).slice(-n);}
function chooseColors(a,b){
  const ba=colorBalance(a.id),bb=colorBalance(b.id),la=lastColors(a.id),lb=lastColors(b.id);
  const penalty=(pid,color)=>{
    const bal=colorBalance(pid)+(color==='W'?1:-1); let p=Math.abs(bal)*2;
    const l=lastColors(pid,2); if(l.length===2&&l[0]===color&&l[1]===color)p+=20;
    return p;
  };
  const p1=penalty(a.id,'W')+penalty(b.id,'B'), p2=penalty(a.id,'B')+penalty(b.id,'W');
  if(p1<p2)return [a.id,b.id]; if(p2<p1)return [b.id,a.id];
  return Math.random()<.5?[a.id,b.id]:[b.id,a.id];
}
function selectBye(players){
  const h=playerHistory();
  const eligible=players.filter(p=>(h[p.id]?.bye||0)===0);
  if(!eligible.length)return null;
  return [...eligible].sort((a,b)=>
    (h[a.id].score-h[b.id].score)||
    ((a.unrated?0:a.rating)-(b.unrated?0:b.rating))||
    a.name.localeCompare(b.name)
  )[0];
}

function buildConflictFreeSwissPairs(pool,pairingScore){
  const h=playerHistory();
  const historyPairs=new Set();
  for(const rnd of state.rounds){
    for(const g of rnd.games){
      if(g.bye||!g.white||!g.black)continue;
      historyPairs.add([g.white,g.black].sort().join('|'));
    }
  }
  const canPair=(a,b)=>!historyPairs.has([a.id,b.id].sort().join('|'));
  const balance=p=>{
    const colors=h[p.id]?.colors||[];
    return colors.filter(x=>x==='W').length-colors.filter(x=>x==='B').length;
  };
  const pairCost=(a,b)=>
    Math.abs(pairingScore(a)-pairingScore(b))*10000+
    Math.abs(balance(a)+balance(b))*50+
    Math.abs((a.unrated?0:a.rating||0)-(b.unrated?0:b.rating||0))/10;

  let nodes=0;
  const NODE_LIMIT=250000;

  const search=(remaining,pairs)=>{
    if(!remaining.length)return pairs;
    if(++nodes>NODE_LIMIT)return null;

    let pickIndex=0,minOptions=Infinity;
    for(let i=0;i<remaining.length;i++){
      let options=0;
      for(let j=0;j<remaining.length;j++){
        if(i!==j && canPair(remaining[i],remaining[j]))options++;
      }
      if(options<minOptions){minOptions=options;pickIndex=i;}
      if(minOptions===0)break;
    }
    if(minOptions===0)return null;

    const a=remaining[pickIndex];
    const rest=remaining.filter((_,i)=>i!==pickIndex);
    const candidates=rest.filter(b=>canPair(a,b)).sort((x,y)=>pairCost(a,x)-pairCost(a,y));

    for(const b of candidates){
      const next=rest.filter(x=>x.id!==b.id);
      const found=search(next,[...pairs,[a,b]]);
      if(found)return found;
    }
    return null;
  };

  return search([...pool],[]);
}

function validateSwissAbsoluteCriteria(games,{doubleSwiss=false}={}){
  if(!Array.isArray(games)||!games.length)return {ok:false,message:'No valid games were generated.'};
  const h=playerHistory();
  const seenPlayers=new Map();
  const seenCurrentPairs=new Set();

  for(const g of games){
    if(g.bye){
      if(!g.white)return {ok:false,message:'A pairing-allocated bye has no player.'};
      if((h[g.white]?.bye||0)>0){
        const p=getPlayer(g.white);
        return {ok:false,message:`${p?.name||'A player'} already received a pairing-allocated bye.`};
      }
      seenPlayers.set(g.white,(seenPlayers.get(g.white)||0)+1);
      continue;
    }

    if(!g.white||!g.black)return {ok:false,message:'A generated board is missing a player.'};

    const key=[g.white,g.black].sort().join('|');
    if(played(g.white,g.black)){
      const a=getPlayer(g.white),b=getPlayer(g.black);
      return {ok:false,message:`Repeat opponent blocked: ${a?.name||'Player'} vs ${b?.name||'Player'} already occurred.`};
    }

    if(seenCurrentPairs.has(key) && !doubleSwiss){
      return {ok:false,message:'The same opponents were paired twice in the new round.'};
    }
    seenCurrentPairs.add(key);

    seenPlayers.set(g.white,(seenPlayers.get(g.white)||0)+1);
    seenPlayers.set(g.black,(seenPlayers.get(g.black)||0)+1);
  }

  if(!doubleSwiss){
    for(const [id,count] of seenPlayers){
      if(count>1){
        const p=getPlayer(id);
        return {ok:false,message:`${p?.name||'A player'} appears more than once in the generated round.`};
      }
    }
  }
  return {ok:true,message:''};
}

function swissPairByScore(players, pairingScore){
  const h=playerHistory();
  let pool=[...players].sort((a,b)=>
    pairingScore(b)-pairingScore(a)||
    (b.unrated?0:b.rating||0)-(a.unrated?0:a.rating||0)||
    a.name.localeCompare(b.name)
  );
  const games=[];

  if(pool.length%2){
    const bye=selectBye(pool);
    if(!bye){
      showToast('No player is eligible for another pairing-allocated bye. Pairing stopped.','error','Swiss pairing blocked');
      return null;
    }
    games.push({id:uid(),board:0,white:bye.id,black:null,result:'BYE',bye:true});
    pool=pool.filter(p=>p.id!==bye.id);
  }

  const pairs=buildConflictFreeSwissPairs(pool,pairingScore);
  if(!pairs){
    showToast('A conflict-free Swiss round could not be produced without a repeat opponent. Pairing stopped instead of forcing an invalid board.','error','Swiss pairing blocked');
    return null;
  }

  pairs.sort((x,y)=>Math.max(pairingScore(y[0]),pairingScore(y[1]))-Math.max(pairingScore(x[0]),pairingScore(x[1])));
  let board=1;
  for(const [a,b] of pairs){
    const [w,bl]=chooseColors(a,b);
    games.push({id:uid(),board:board++,white:w,black:bl,result:'',bye:false});
  }
  const byeGame=games.find(g=>g.bye);
  if(byeGame)byeGame.board=board;
  return games;
}

function swissPair(players){
  const h=playerHistory();
  return swissPairByScore(players,p=>h[p.id]?.score||0);
}


function shouldRandomizeSchoolRoundOne(){
  if(state.settings.mode!=='swiss')return false;
  if(state.rounds.length!==0)return false;

  // A selected FIDE Dutch tournament must ALWAYS use the Dutch engine.
  if((state.settings.swissVariant||'flexible')==='dutch')return false;

  // Manual Shuffle Players explicitly requests a random Swiss Round 1.
  if(state.settings?.manualRosterShuffle)return state.players.length>1;

  // School/DepEd all-NR tournaments are random by default in Round 1.
  if(state.settings?.eventScope==='open')return false;
  return state.players.length>1 && state.players.every(p=>p.unrated || !Number(p.rating||0));
}

function shuffledPlayers(players){
  const arr=[...players];
  for(let i=arr.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]]=[arr[j],arr[i]];
  }
  return arr;
}

function randomSchoolRoundOnePair(players){
  // If the user already clicked Shuffle Players, preserve that visible shuffled order.
  // Otherwise (automatic School/NR Round 1), create a fresh random shuffle here.
  let pool=state.settings?.manualRosterShuffle ? [...players] : shuffledPlayers(players);
  const games=[];
  let board=1;

  // For an odd roster, the first-round bye is random too.
  if(pool.length%2){
    const bye=pool.pop();
    games.push({
      id:uid(),
      board:0,
      white:bye.id,
      black:null,
      result:'BYE',
      bye:true,
      randomSchoolRoundOne:true
    });
  }

  for(let i=0;i<pool.length;i+=2){
    const a=pool[i], b=pool[i+1];
    const [w,bl]=chooseColors(a,b);
    games.push({
      id:uid(),
      board:board++,
      white:w,
      black:bl,
      result:'',
      bye:false,
      randomSchoolRoundOne:true
    });
  }

  const byeGame=games.find(g=>g.bye);
  if(byeGame)byeGame.board=board;
  return games;
}

function acceleratedSwissPair(players){
  const h=playerHistory();
  const seeded=[...players].sort((a,b)=>(b.rating||0)-(a.rating||0)||a.name.localeCompare(b.name));
  const top=new Set(seeded.slice(0,Math.ceil(seeded.length/2)).map(p=>p.id));
  const opening=state.rounds.length<2;
  return swissPairByScore(players,p=>(h[p.id]?.score||0)+(opening&&top.has(p.id)?1:0));
}


// ---------------------------------------------------------------------------
// FIDE DUTCH SWISS — dedicated deterministic engine
// ---------------------------------------------------------------------------
// Separate from Flexible / Practical Swiss.
// Pairing order: score DESC -> Tournament Pairing Number (TPN) ASC.
// Uses score-group upper/lower preference, repeat/bye safeguards,
// float history and FIDE colour-allocation priorities.
// It never falls back to Flexible Swiss.

function dutchEnsureTPN(players){
  const used=new Set();
  let valid=true;
  for(const p of players){
    const n=Number(p.dutchTpn||0);
    if(!Number.isInteger(n)||n<1||used.has(n)){valid=false;break;}
    used.add(n);
  }
  if(!valid||used.size!==players.length){
    players.forEach((p,i)=>{p.dutchTpn=i+1;});
    state.settings.dutchTpnLocked=true;
    state.settings.dutchInitialColor=state.settings.dutchInitialColor||'W';
  }
}

function dutchResultPointsFor(game,playerId){
  if(game.bye)return state.settings.scoring.bye;
  if(game.result==='½-½')return state.settings.scoring.draw;
  if((game.white===playerId&&(game.result==='1-0'||game.result==='1F-0F'))||
     (game.black===playerId&&(game.result==='0-1'||game.result==='0F-1F')))return state.settings.scoring.win;
  return state.settings.scoring.loss;
}

function dutchHistory(players){
  const d={};
  players.forEach(p=>d[p.id]={
    score:0,opponents:new Set(),byeCount:0,fullUnplayedWins:0,unplayed:0,
    colorsByRound:[],floats:[],tpn:Number(p.dutchTpn||0)
  });

  for(const rnd of state.rounds){
    const pre={};
    players.forEach(p=>{pre[p.id]=d[p.id].score;});
    const seen=new Set();

    for(const g of rnd.games||[]){
      if(g.bye){
        const x=d[g.white];
        if(!x)continue;
        const pts=state.settings.mode==='roundrobin'?0:state.settings.scoring.bye;
        x.score+=pts;x.byeCount++;x.unplayed++;
        if(pts>=state.settings.scoring.win)x.fullUnplayedWins++;
        x.colorsByRound.push(undefined);
        x.floats.push(pts>state.settings.scoring.loss?'down':undefined);
        seen.add(g.white);
        continue;
      }

      const a=d[g.white],b=d[g.black];
      if(!a||!b)continue;
      const isForfeit=g.result==='1F-0F'||g.result==='0F-1F';

      if(isForfeit){
        a.colorsByRound.push(undefined);b.colorsByRound.push(undefined);
        a.unplayed++;b.unplayed++;
        const ap=dutchResultPointsFor(g,g.white),bp=dutchResultPointsFor(g,g.black);
        if(ap>=state.settings.scoring.win)a.fullUnplayedWins++;
        if(bp>=state.settings.scoring.win)b.fullUnplayedWins++;
      }else{
        a.colorsByRound.push('W');b.colorsByRound.push('B');
        a.opponents.add(g.black);b.opponents.add(g.white);
      }

      const aw=pre[g.white]||0,bw=pre[g.black]||0;
      if(isForfeit){
        a.floats.push(dutchResultPointsFor(g,g.white)>state.settings.scoring.loss?'down':undefined);
        b.floats.push(dutchResultPointsFor(g,g.black)>state.settings.scoring.loss?'down':undefined);
      }else if(aw>bw){
        a.floats.push('down');b.floats.push('up');
      }else if(aw<bw){
        a.floats.push('up');b.floats.push('down');
      }else{
        a.floats.push(undefined);b.floats.push(undefined);
      }

      a.score+=dutchResultPointsFor(g,g.white);
      b.score+=dutchResultPointsFor(g,g.black);
      seen.add(g.white);seen.add(g.black);
    }

    for(const p of players){
      if(seen.has(p.id))continue;
      d[p.id].colorsByRound.push(undefined);
      d[p.id].floats.push(undefined);
      d[p.id].unplayed++;
    }
  }
  return d;
}

function dutchColorProfile(playerId,h){
  const rounds=(h[playerId]?.colorsByRound||[]).filter(Boolean);
  const whites=rounds.filter(c=>c==='W').length;
  const blacks=rounds.filter(c=>c==='B').length;
  const diff=whites-blacks;
  const last2=rounds.slice(-2);
  let strength='none',preferred;

  if(!rounds.length){
    strength='none';preferred=undefined;
  }else if(Math.abs(diff)>1||(last2.length===2&&last2[0]===last2[1])){
    strength='absolute';
    preferred=(diff< -1||(last2.length===2&&last2[0]==='B'&&last2[1]==='B'))?'W':'B';
  }else if(Math.abs(diff)===1){
    strength='strong';preferred=diff>0?'B':'W';
  }else{
    strength='mild';preferred=rounds.at(-1)==='W'?'B':'W';
  }
  return {diff,strength,preferred,rounds};
}

function dutchIsTopscorer(player,h){
  const nextRound=state.rounds.length+1;
  const isFinal=nextRound>=Number(state.settings.rounds||nextRound);
  if(!isFinal)return false;
  const maxBefore=Math.max(0,(nextRound-1)*Number(state.settings.scoring.win||1));
  return Number(h[player.id]?.score||0)>maxBefore/2;
}

function dutchRankCompare(a,b,h){
  return (Number(h[b.id]?.score||0)-Number(h[a.id]?.score||0))||
         (Number(a.dutchTpn||999999)-Number(b.dutchTpn||999999));
}

function dutchCanPair(a,b,h){
  if(!a||!b||a.id===b.id)return false;
  if(h[a.id]?.opponents?.has(b.id)||h[b.id]?.opponents?.has(a.id))return false;

  const pa=dutchColorProfile(a.id,h),pb=dutchColorProfile(b.id,h);
  if(pa.strength==='absolute'&&pb.strength==='absolute'&&
     pa.preferred&&pa.preferred===pb.preferred&&
     !dutchIsTopscorer(a,h)&&!dutchIsTopscorer(b,h))return false;

  return true;
}

function dutchPreferenceRank(s){
  return s==='absolute'?3:s==='strong'?2:s==='mild'?1:0;
}

function dutchAllocateColors(a,b,h){
  const pa=dutchColorProfile(a.id,h),pb=dutchColorProfile(b.id,h);
  const rank=dutchRankCompare(a,b,h);
  const hrp=rank<=0?a:b,lrp=rank<=0?b:a;
  const hp=hrp.id===a.id?pa:pb,lp=hrp.id===a.id?pb:pa;

  const finish=(hrpColor)=>{
    const white=hrpColor==='W'?hrp.id:lrp.id;
    const black=hrpColor==='B'?hrp.id:lrp.id;
    return [white,black];
  };

  if(hp.preferred&&lp.preferred&&hp.preferred!==lp.preferred)return finish(hp.preferred);

  const hs=dutchPreferenceRank(hp.strength),ls=dutchPreferenceRank(lp.strength);
  if(hp.preferred&&hs>ls)return finish(hp.preferred);
  if(lp.preferred&&ls>hs)return finish(lp.preferred==='W'?'B':'W');

  if(hp.strength==='absolute'&&lp.strength==='absolute'&&hp.preferred&&lp.preferred){
    if(Math.abs(hp.diff)>Math.abs(lp.diff))return finish(hp.preferred);
    if(Math.abs(lp.diff)>Math.abs(hp.diff))return finish(lp.preferred==='W'?'B':'W');
  }

  const ac=h[a.id]?.colorsByRound||[],bc=h[b.id]?.colorsByRound||[];
  for(let i=Math.min(ac.length,bc.length)-1;i>=0;i--){
    if(ac[i]&&bc[i]&&ac[i]!==bc[i]){
      const aNext=ac[i]==='W'?'B':'W';
      return aNext==='W'?[a.id,b.id]:[b.id,a.id];
    }
  }

  if(hp.preferred)return finish(hp.preferred);

  const initial=state.settings.dutchInitialColor||'W';
  const hrpColor=(Number(hrp.dutchTpn||1)%2===1)?initial:(initial==='W'?'B':'W');
  return finish(hrpColor);
}

function dutchPairColorPenalty(a,b,h){
  const [w]=dutchAllocateColors(a,b,h);
  const colorOf=id=>id===w?'W':'B';
  let topBad=0,prefMiss=0,strongMiss=0;

  for(const p of [a,b]){
    const prof=dutchColorProfile(p.id,h),color=colorOf(p.id);
    if(prof.preferred&&prof.preferred!==color){
      prefMiss++;
      if(prof.strength==='strong'||prof.strength==='absolute')strongMiss++;
    }
    const projected=prof.diff+(color==='W'?1:-1);
    const same3=prof.rounds.length>=2&&prof.rounds.at(-1)===color&&prof.rounds.at(-2)===color;
    if(dutchIsTopscorer(p,h)&&(Math.abs(projected)>2||same3))topBad++;
  }
  return {topBad,prefMiss,strongMiss};
}

function dutchFloatPenalty(a,b,h){
  const as=Number(h[a.id]?.score||0),bs=Number(h[b.id]?.score||0);
  if(as===bs)return {r1:0,r2:0,diffs1:0,diffs2:0};
  const high=as>bs?a:b,low=as>bs?b:a;
  const hf=h[high.id]?.floats||[],lf=h[low.id]?.floats||[];
  const gap=Math.abs(as-bs);
  return {
    r1:(hf.at(-1)==='down'?1:0)+(lf.at(-1)==='up'?1:0),
    r2:(hf.at(-2)==='down'?1:0)+(lf.at(-2)==='up'?1:0),
    diffs1:gap*((hf.at(-1)==='down'?1:0)+(lf.at(-1)==='up'?1:0)),
    diffs2:gap*((hf.at(-2)==='down'?1:0)+(lf.at(-2)==='up'?1:0))
  };
}

function dutchIdealPartnerPenalty(a,b,pool,h){
  const sa=Number(h[a.id]?.score||0),sb=Number(h[b.id]?.score||0);
  if(sa!==sb)return 0;
  const group=pool.filter(p=>Number(h[p.id]?.score||0)===sa)
    .sort((x,y)=>Number(x.dutchTpn)-Number(y.dutchTpn));
  if(group.length<2)return 0;
  const maxPairs=Math.floor(group.length/2);
  const ia=group.findIndex(p=>p.id===a.id),ib=group.findIndex(p=>p.id===b.id);
  if(ia<0||ib<0)return 0;
  const topA=ia<maxPairs,topB=ib<maxPairs;
  if(topA===topB)return 50;
  const ti=topA?ia:ib,bi=topA?ib:ia;
  return Math.abs(bi-(maxPairs+ti));
}

function dutchLexCompare(a,b){
  const n=Math.max(a.length,b.length);
  for(let i=0;i<n;i++){
    const av=Number(a[i]||0),bv=Number(b[i]||0);
    if(av<bv)return -1;
    if(av>bv)return 1;
  }
  return 0;
}

function dutchEvaluatePairs(pairs,bye,pool,h){
  let cross=0,topBad=0,prefMiss=0,strongMiss=0,r1=0,r2=0,d1=0,d2=0,split=0;
  const downScores=[],scoreDiffs=[];

  for(const [a,b] of pairs){
    const as=Number(h[a.id]?.score||0),bs=Number(h[b.id]?.score||0);
    const gap=Math.abs(as-bs);
    if(gap>0){
      cross++;downScores.push(Math.max(as,bs));scoreDiffs.push(gap);
    }
    const cp=dutchPairColorPenalty(a,b,h);
    topBad+=cp.topBad;prefMiss+=cp.prefMiss;strongMiss+=cp.strongMiss;
    const fp=dutchFloatPenalty(a,b,h);
    r1+=fp.r1;r2+=fp.r2;d1+=fp.diffs1;d2+=fp.diffs2;
    split+=dutchIdealPartnerPenalty(a,b,pool,h);
  }

  downScores.sort((x,y)=>y-x);scoreDiffs.sort((x,y)=>y-x);
  const slots=Math.ceil(pool.length/2);
  const pad=(arr,len)=>[...arr,...Array(Math.max(0,len-arr.length)).fill(0)];

  const seq=[...pairs].sort((x,y)=>{
    const ax=[...x].sort((p,q)=>dutchRankCompare(p,q,h))[0];
    const ay=[...y].sort((p,q)=>dutchRankCompare(p,q,h))[0];
    return dutchRankCompare(ax,ay,h);
  }).flatMap(([a,b])=>{
    const ordered=[a,b].sort((p,q)=>dutchRankCompare(p,q,h));
    return [Number(ordered[0].dutchTpn||0),Number(ordered[1].dutchTpn||0)];
  });

  return [
    bye?Number(h[bye.id]?.score||0):-1,
    cross,
    ...pad(downScores,slots),
    ...pad(scoreDiffs,slots),
    bye?Number(h[bye.id]?.unplayed||0):0,
    topBad,prefMiss,strongMiss,
    r1,r2,d1,d2,
    split,
    ...seq
  ];
}

function dutchSearchBestPairing(pool,h,nodeLimit=300000){
  const ranked=[...pool].sort((a,b)=>dutchRankCompare(a,b,h));
  let best=null,bestScore=null,nodes=0;

  const rec=(remaining,pairs)=>{
    if(++nodes>nodeLimit)return;
    if(!remaining.length){
      const score=dutchEvaluatePairs(pairs,null,ranked,h);
      if(!best||dutchLexCompare(score,bestScore)<0){
        best=pairs.map(x=>[...x]);bestScore=score;
      }
      return;
    }

    const a=remaining[0];
    const candidates=remaining.slice(1).filter(b=>dutchCanPair(a,b,h)).sort((x,y)=>{
      const as=Number(h[a.id]?.score||0),xs=Number(h[x.id]?.score||0),ys=Number(h[y.id]?.score||0);
      const sameX=as===xs?0:1,sameY=as===ys?0:1;
      if(sameX!==sameY)return sameX-sameY;
      const px=dutchIdealPartnerPenalty(a,x,ranked,h),py=dutchIdealPartnerPenalty(a,y,ranked,h);
      if(px!==py)return px-py;
      const gx=Math.abs(as-xs),gy=Math.abs(as-ys);
      if(gx!==gy)return gx-gy;
      return Number(x.dutchTpn)-Number(y.dutchTpn);
    });

    for(const b of candidates){
      rec(remaining.filter(p=>p.id!==a.id&&p.id!==b.id),[...pairs,[a,b]]);
      if(nodes>nodeLimit)break;
    }
  };

  rec(ranked,[]);
  return {pairs:best,score:bestScore,nodes};
}

function dutchStyleSwissPairApproxV258(players,{preview=false}={}){
  dutchEnsureTPN(players);
  const h=dutchHistory(players);
  const ranked=[...players].sort((a,b)=>dutchRankCompare(a,b,h));
  let byeCandidates=[null];

  if(ranked.length%2){
    const eligible=ranked.filter(p=>
      Number(h[p.id]?.byeCount||0)===0&&
      Number(h[p.id]?.fullUnplayedWins||0)===0
    );
    if(!eligible.length){
      if(!preview)showToast('No player is eligible for another FIDE pairing-allocated bye.','error','FIDE Dutch pairing blocked');
      return null;
    }

    const minScore=Math.min(...eligible.map(p=>Number(h[p.id]?.score||0)));
    byeCandidates=eligible.filter(p=>Number(h[p.id]?.score||0)===minScore);

    // First round: lowest-ranked eligible player receives the PAB.
    if(state.rounds.length===0)byeCandidates.sort((a,b)=>Number(b.dutchTpn)-Number(a.dutchTpn));
    else byeCandidates.sort((a,b)=>Number(a.dutchTpn)-Number(b.dutchTpn));
  }

  let best=null,bestVector=null;
  for(const bye of byeCandidates){
    const pool=bye?ranked.filter(p=>p.id!==bye.id):ranked;
    const found=dutchSearchBestPairing(pool,h,ranked.length<=14?450000:120000);
    if(!found.pairs)continue;

    const vector=dutchEvaluatePairs(found.pairs,bye,ranked,h);
    if(!best||dutchLexCompare(vector,bestVector)<0){
      best={pairs:found.pairs,bye};bestVector=vector;
    }
    if(state.rounds.length===0&&best)break;
  }

  if(!best){
    if(!preview)showToast(
      'FIDE Dutch could not produce a legal pairing. No Flexible fallback was used.',
      'error','FIDE Dutch pairing blocked'
    );
    return null;
  }

  best.pairs.sort((x,y)=>{
    const ax=[...x].sort((p,q)=>dutchRankCompare(p,q,h))[0];
    const ay=[...y].sort((p,q)=>dutchRankCompare(p,q,h))[0];
    return dutchRankCompare(ax,ay,h);
  });

  const games=[];
  let board=1;
  for(const [a,b] of best.pairs){
    const [w,bl]=dutchAllocateColors(a,b,h);
    games.push({
      id:preview?`preview-${board}`:uid(),board:board++,
      white:w,black:bl,result:'',bye:false,
      dutchStyle:true,fideDutch:true
    });
  }
  if(best.bye){
    games.push({
      id:preview?'preview-bye':uid(),board,
      white:best.bye.id,black:null,result:'BYE',bye:true,
      dutchStyle:true,fideDutch:true
    });
  }

  if(!preview){
    state.settings.dutchEngine='strict-2026';
    state.settings.dutchTpnLocked=true;
  }
  return games;
}


// ---------------------------------------------------------------------------
// EXACT FIDE DUTCH C.04.3 ADAPTER — @echecs/swiss v5.0.0
// ---------------------------------------------------------------------------
// Pure Dutch tournaments use the official/pinned library engine loaded by
// js/fide-dutch-exact.js. There is deliberately NO Flexible fallback.

function catqueToExactDutchPlayers(players){
  return players.map((p,index)=>{
    const out={
      id:String(p.id),
      name:String(p.name||''),
      points:0,
      rank:index+1,
      startingRank:index+1
    };
    if(!p.unrated && Number.isFinite(Number(p.rating)) && Number(p.rating)>0){
      out.rating=Number(p.rating);
    }
    return out;
  });
}

function catqueResultToExactDutchGame(g){
  const base={white:String(g.white),black:String(g.black)};

  if(g.result==='1-0')return {...base,result:'white'};
  if(g.result==='0-1')return {...base,result:'black'};
  if(g.result==='½-½')return {...base,result:'draw'};
  if(g.result==='1F-0F')return {...base,result:'white',forfeit:'black'};
  if(g.result==='0F-1F')return {...base,result:'black',forfeit:'white'};

  throw new Error(`Round ${g.board||'?'} has no completed result for exact FIDE Dutch pairing.`);
}

function catqueToExactDutchRounds(){
  return state.rounds.map(r=>{
    const games=[];
    const byes=[];

    for(const g of (r.games||[])){
      if(g.bye){
        byes.push({kind:'pairing',player:String(g.white)});
        continue;
      }
      games.push(catqueResultToExactDutchGame(g));
    }

    return {games,byes};
  });
}

function exactDutchGamesToCatQue(result,{preview=false}={}){
  const games=[];
  let board=1;

  for(const g of (result?.games||[])){
    games.push({
      id:preview?`exact-dutch-preview-${board}`:uid(),
      board:board++,
      white:String(g.white),
      black:String(g.black),
      result:'',
      bye:false,
      dutchStyle:true,
      fideDutch:true,
      exactFideDutch:true,
      exactEngine:'@echecs/swiss@5.0.0'
    });
  }

  for(const b of (result?.byes||[])){
    games.push({
      id:preview?`exact-dutch-preview-bye-${board}`:uid(),
      board:board++,
      white:String(b.player),
      black:null,
      result:'BYE',
      bye:true,
      dutchStyle:true,
      fideDutch:true,
      exactFideDutch:true,
      exactEngine:'@echecs/swiss@5.0.0'
    });
  }

  return games;
}

async function dutchStyleSwissPair(players,{preview=false}={}){
  let exactPair;
  try{
    if(typeof window.ensureFideDutchExact!=='function'){
      throw new Error('Exact FIDE Dutch engine loader is not available.');
    }
    exactPair=await window.ensureFideDutchExact();
  }catch(err){
    if(!preview){
      showToast(
        'The exact FIDE Dutch C.04.3 engine could not load. CatQue will NOT substitute Flexible Swiss. Connect once after updating so the pinned engine can be cached locally.',
        'error',
        'Exact Dutch engine unavailable'
      );
    }
    console.error('Exact FIDE Dutch engine load failed:',err);
    return null;
  }

  if(typeof exactPair!=='function'){
    if(!preview)showToast('Exact FIDE Dutch engine did not expose pair(). No fallback pairing was generated.','error','Pairing blocked');
    return null;
  }

  try{
    const exactPlayers=catqueToExactDutchPlayers(players);
    const exactRounds=catqueToExactDutchRounds();
    const expectedRounds=Math.max(
      exactRounds.length+1,
      Number(state.settings.rounds)||exactRounds.length+1
    );

    // This is the actual C.04.3 pair() implementation from
    // @echecs/swiss v5.0.0, not CatQue's Flexible pairing search.
    const result=exactPair(exactPlayers,exactRounds,{expectedRounds});
    if(!preview)window.__catqueExactDutchPreviewGames=null;
    const games=exactDutchGamesToCatQue(result,{preview});

    if(!preview){
      state.settings.dutchEngine='@echecs/swiss@5.0.0';
      state.settings.dutchRule='FIDE C.04.3';
      state.settings.dutchExact=true;
      state.settings.dutchTpnLocked=true;
    }
    return games;
  }catch(err){
    if(!preview){
      showToast(
        `Exact FIDE Dutch pairing stopped: ${err?.message||err}. No Flexible fallback was used.`,
        'error',
        'FIDE Dutch pairing blocked'
      );
    }
    console.error('Exact FIDE Dutch pair() failed:',err);
    return null;
  }
}

function doubleSwissPair(players){
  const base=(state.settings.doubleSwissBase||'dutch')==='flexible'
    ? swissPair(players)
    : dutchStyleSwissPairApproxV258(players);
  const out=[];
  let board=1;
  for(const g of base){
    if(g.bye){
      out.push({...g,board:board++});
      continue;
    }
    const matchId=uid();
    out.push({...g,id:uid(),board:board++,matchId,doubleSwissGame:1});
    out.push({id:uid(),board:board++,white:g.black,black:g.white,result:'',bye:false,matchId,doubleSwissGame:2});
  }
  return out;
}
function roundRobinSchedule(){
  let arr=[...state.players];
  if(arr.length%2)arr.push({id:'BYE',name:'BYE'});
  const n=arr.length, schedules=[];
  let work=[...arr];
  for(let r=0;r<n-1;r++){
    const games=[];
    for(let i=0;i<n/2;i++){
      const a=work[i],b=work[n-1-i];
      if(a.id==='BYE'||b.id==='BYE'){
        const real=a.id==='BYE'?b:a; games.push({id:uid(),board:games.length+1,white:real.id,black:null,result:'BYE',bye:true});
      }else{
        const reverse=(r+i)%2===1;games.push({id:uid(),board:games.length+1,white:reverse?b.id:a.id,black:reverse?a.id:b.id,result:'',bye:false});
      }
    }
    schedules.push(games);
    work=[work[0],work[n-1],...work.slice(1,n-1)];
  }
  if(state.settings.roundRobinType==='double'){
    const second=schedules.map(round=>round.map(g=>{
      if(g.bye)return {...g,id:uid()};
      return {...g,id:uid(),white:g.black,black:g.white,result:''};
    }));
    return [...schedules,...second];
  }
  return schedules;
}
function knockoutPair(){
  if(state.rounds.length===0){
    const seeded=[...state.players].sort((a,b)=>b.rating-a.rating);
    const games=[];let board=1;
    while(seeded.length){
      const a=seeded.shift(),b=seeded.pop();
      if(!b)games.push({id:uid(),board:board++,white:a.id,black:null,result:'BYE',bye:true});
      else games.push({id:uid(),board:board++,white:a.id,black:b.id,result:'',bye:false});
    } return games;
  }
  const prev=currentRound(); const winners=[];
  for(const g of prev.games){
    if(g.bye)winners.push(getPlayer(g.white));
    else if(g.result==='1-0'||g.result==='1F-0F')winners.push(getPlayer(g.white));
    else if(g.result==='0-1'||g.result==='0F-1F')winners.push(getPlayer(g.black));
    else {alert('Knockout games must have a winner. Resolve draws before generating the next round.');return null;}
  }
  if(winners.length<=1){alert('Knockout tournament already has a champion.');return null;}
  const games=[];let board=1;
  for(let i=0;i<winners.length;i+=2){
    const a=winners[i],b=winners[i+1];
    if(!b)games.push({id:uid(),board:board++,white:a.id,black:null,result:'BYE',bye:true});
    else {const [w,bl]=chooseColors(a,b);games.push({id:uid(),board:board++,white:w,black:bl,result:'',bye:false});}
  } return games;
}

function teamKeyForPlayer(p){
  return delegationLabel(p)||p.school||p.town||p.region||'Unassigned';
}
function getTeams(){
  const map=new Map();
  for(const p of state.players){
    const key=teamKeyForPlayer(p);
    if(!map.has(key))map.set(key,[]);
    map.get(key).push(p);
  }
  return [...map.entries()].map(([name,players])=>({
    name,
    players:players.sort((a,b)=>(b.unrated?0:b.rating)-(a.unrated?0:a.rating)||a.name.localeCompare(b.name)),
    avgRating:players.length?players.reduce((s,p)=>s+(p.unrated?0:p.rating),0)/players.length:0
  }));
}
function teamHistory(){
  const teams=getTeams();
  const h={};
  teams.forEach(t=>h[t.name]={matchPoints:0,boardPoints:0,wins:0,opponents:[]});
  for(const rnd of state.rounds){
    if(!rnd.teamMatches)continue;
    for(const m of rnd.teamMatches){
      if(m.bye){
        if(h[m.teamA]){
          h[m.teamA].matchPoints+=(state.settings.teamMatchWin??2);
          h[m.teamA].boardPoints+=(state.settings.teamBoards||4);
          h[m.teamA].wins++;
        }
        continue;
      }
      if(!h[m.teamA]||!h[m.teamB])continue;
      h[m.teamA].opponents.push(m.teamB);
      h[m.teamB].opponents.push(m.teamA);
      const games=rnd.games.filter(g=>g.matchId===m.id);
      let aBP=0,bBP=0,complete=true;
      for(const g of games){
        if(!g.result){complete=false;continue;}
        const whiteTeam=g.whiteTeam, blackTeam=g.blackTeam;
        let w=0,b=0;
        if(g.result==='1-0'||g.result==='1F-0F'){w=1;}
        else if(g.result==='0-1'||g.result==='0F-1F'){b=1;}
        else if(g.result==='½-½'){w=.5;b=.5;}
        if(whiteTeam===m.teamA){aBP+=w;bBP+=b;}else{aBP+=b;bBP+=w;}
      }
      h[m.teamA].boardPoints+=aBP;
      h[m.teamB].boardPoints+=bBP;
      if(complete){
        if(aBP>bBP){h[m.teamA].matchPoints+=(state.settings.teamMatchWin??2);h[m.teamA].wins++;}
        else if(bBP>aBP){h[m.teamB].matchPoints+=(state.settings.teamMatchWin??2);h[m.teamB].wins++;}
        else{
          h[m.teamA].matchPoints+=(state.settings.teamMatchDraw??1);
          h[m.teamB].matchPoints+=(state.settings.teamMatchDraw??1);
        }
      }
    }
  }
  return h;
}
function teamPlayed(a,b){
  return state.rounds.some(r=>(r.teamMatches||[]).some(m=>!m.bye&&((m.teamA===a&&m.teamB===b)||(m.teamA===b&&m.teamB===a))));
}
function buildTeamMatch(teamA,teamB,matchNo,roundNo){
  const boards=Math.max(1,state.settings.teamBoards||4);
  const matchId=uid();
  const games=[];
  for(let i=0;i<boards;i++){
    const a=teamA.players[i], b=teamB.players[i];
    if(!a&&!b)continue;
    if(a&&!b){
      games.push({id:uid(),board:i+1,white:a.id,black:null,result:'BYE',bye:true,matchId,whiteTeam:teamA.name,blackTeam:teamB.name,teamBoard:true});
      continue;
    }
    if(!a&&b){
      games.push({id:uid(),board:i+1,white:b.id,black:null,result:'BYE',bye:true,matchId,whiteTeam:teamB.name,blackTeam:teamA.name,teamBoard:true});
      continue;
    }
    const aWhite=((roundNo+i)%2===0);
    games.push({
      id:uid(),board:i+1,
      white:aWhite?a.id:b.id,black:aWhite?b.id:a.id,
      result:'',bye:false,matchId,
      whiteTeam:aWhite?teamA.name:teamB.name,
      blackTeam:aWhite?teamB.name:teamA.name,
      teamBoard:true
    });
  }
  return {match:{id:matchId,number:matchNo,teamA:teamA.name,teamB:teamB.name,bye:false},games};
}
function generateTeamSwissRound(){
  const teams=getTeams();
  const h=teamHistory();
  let pool=[...teams].sort((a,b)=>(h[b.name]?.matchPoints||0)-(h[a.name]?.matchPoints||0)||(h[b.name]?.boardPoints||0)-(h[a.name]?.boardPoints||0)||b.avgRating-a.avgRating);
  const teamMatches=[],games=[];
  if(pool.length%2){
    const bye=pool.pop();
    const id=uid();
    teamMatches.push({id,number:teamMatches.length+1,teamA:bye.name,teamB:null,bye:true});
  }
  let n=1;
  while(pool.length){
    const a=pool.shift();
    let idx=pool.findIndex(b=>!teamPlayed(a.name,b.name));
    if(idx<0)idx=0;
    const b=pool.splice(idx,1)[0];
    const built=buildTeamMatch(a,b,n++,state.rounds.length+1);
    teamMatches.push(built.match);
    games.push(...built.games);
  }
  return {teamMatches,games};
}
function teamRoundRobinSchedule(){
  let teams=getTeams().map(t=>t.name);
  if(teams.length%2)teams.push('BYE');
  const all=[],n=teams.length;
  let work=[...teams];
  for(let r=0;r<n-1;r++){
    const matches=[];
    for(let i=0;i<n/2;i++){
      const a=work[i],b=work[n-1-i];
      matches.push([a,b]);
    }
    all.push(matches);
    work=[work[0],work[n-1],...work.slice(1,n-1)];
  }
  return all;
}
function generateTeamRound(){
  const teams=getTeams();
  if(teams.length<2){alert('A team tournament needs at least 2 different delegations/teams.');return null;}
  if((state.settings.teamFormat||'swiss')==='roundrobin'){
    const sched=teamRoundRobinSchedule();
    const idx=state.rounds.length;
    if(idx>=sched.length){alert('Team Round Robin is complete.');return null;}
    const teamMap=new Map(teams.map(t=>[t.name,t]));
    const teamMatches=[],games=[];
    let no=1;
    for(const [aName,bName] of sched[idx]){
      if(aName==='BYE'||bName==='BYE'){
        const real=aName==='BYE'?bName:aName;
        teamMatches.push({id:uid(),number:no++,teamA:real,teamB:null,bye:true});
      }else{
        const built=buildTeamMatch(teamMap.get(aName),teamMap.get(bName),no++,idx+1);
        teamMatches.push(built.match);games.push(...built.games);
      }
    }
    return {teamMatches,games};
  }
  return generateTeamSwissRound();
}
function teamStandings(){
  const h=teamHistory();
  return getTeams().map(t=>({...t,...(h[t.name]||{})}))
    .sort((a,b)=>(b.matchPoints||0)-(a.matchPoints||0)||(b.boardPoints||0)-(a.boardPoints||0)||(b.wins||0)-(a.wins||0)||b.avgRating-a.avgRating||a.name.localeCompare(b.name));
}

async function generateNextRound(skipHistory=false){
  // Capture any currently selected result before validating the round.
  syncVisibleResults();
  persist();

  // Do not call syncSettings() here because tournament format/settings
  // are already fixed for the active tournament and the dashboard mode field is locked.
  if(state.players.length<2){alert('Register at least 2 players first.');return;}
  const cur=currentRound();
  if(cur && cur.games.some(g=>!g.bye&&!g.result)){
    alert('Please select a result for every played game before ending this round.');
    return;
  }

  // A completed round must be explicitly ended before another round is generated.
  if(cur && !cur.finalized){
    endCurrentRound();
    return;
  }

  if(state.settings.mode!=='knockout' && state.rounds.length>=state.settings.rounds){
    const finalPending=currentRound()?.games?.filter(g=>!g.bye&&!g.result).length||0;
    if(finalPending>0){
      showToast(`This is the final round. Complete the remaining ${finalPending} result(s) to show the official final result.`,'info','Final round');
      goTab('pairings');
      setTimeout(()=>scrollToPendingBoard(),80);
      return;
    }
    showFinalTournamentResult();
    return;
  }
  let games;
  if(state.settings.mode==='swiss'){
    const v=state.settings.swissVariant||'flexible';
    if(shouldRandomizeSchoolRoundOne()){
      games=randomSchoolRoundOnePair(state.players);
    }else if(v==='dutch')games=await dutchStyleSwissPair(state.players);
    else if(v==='accelerated')games=acceleratedSwissPair(state.players);
    else if(v==='double')games=doubleSwissPair(state.players);
    else games=swissPair(state.players);
  }
  if(state.settings.mode==='team'){
    const teamRound=generateTeamRound();
    if(!teamRound)return;
    if(!skipHistory)pushHistory(`Generate Round ${state.rounds.length+1}`);
    state.rounds.push({number:state.rounds.length+1,games:teamRound.games,teamMatches:teamRound.teamMatches,finalized:false});
    persist();renderAll();goTab('pairings');
    showToast(`Round ${state.rounds.length} generated successfully.`,'success','Pairings ready');
    return;
  }
  if(state.settings.mode==='roundrobin'){
    const sched=roundRobinSchedule();
    if(state.rounds.length>=sched.length){alert('Round Robin schedule is complete.');return;}
    games=sched[state.rounds.length];
  }
  if(state.settings.mode==='knockout')games=knockoutPair();
  if(!games)return;

  if(state.settings.mode==='swiss'){
    const check=validateSwissAbsoluteCriteria(games,{doubleSwiss:state.settings.swissVariant==='double'});
    if(!check.ok){showToast(check.message,'error','Pairing blocked');return;}
  }

  if(!skipHistory)pushHistory(`Generate Round ${state.rounds.length+1}`);
  state.rounds.push({number:state.rounds.length+1,games,finalized:false});
  persist();renderAll();goTab('pairings');
  showToast(`Round ${state.rounds.length} generated successfully.`,'success','Pairings ready');
}

function openEditRoundModal(){
  syncVisibleResults();
  persist();

  if(!state.rounds.length){
    alert('There are no generated rounds to edit yet.');
    return;
  }

  const select=document.getElementById('editRoundSelect');
  select.innerHTML=state.rounds
    .map(r=>`<option value="${r.number}" ${r.number===currentRound()?.number?'selected':''}>Round ${r.number}</option>`)
    .join('');

  renderEditRoundGames();
  document.getElementById('editRoundModal').classList.add('show');
}

function closeEditRoundModal(){
  document.getElementById('editRoundModal').classList.remove('show');
}

function selectedEditRound(){
  const n=+document.getElementById('editRoundSelect')?.value;
  return state.rounds.find(r=>r.number===n)||null;
}

function renderEditRoundGames(){
  const r=selectedEditRound();
  const box=document.getElementById('editRoundGames');
  const warning=document.getElementById('editRoundWarning');
  if(!r||!box)return;

  const hasLater=state.rounds.some(x=>x.number>r.number);
  if(warning){
    warning.style.display=hasLater?'block':'none';
    warning.innerHTML=hasLater
      ? `<b>Important:</b> You are editing Round ${r.number}, but later rounds already exist. Correcting this result will recalculate scores, rankings, and tie-breaks. Existing later-round pairings will remain as originally generated.`
      : '';
  }

  if(state.settings.mode==='team' && r.teamMatches){
    box.innerHTML=r.teamMatches.map(m=>{
      if(m.bye){
        return `<div class="pair-card"><b>Team Match ${m.number}: ${esc(m.teamA)}</b> — TEAM BYE</div>`;
      }
      const games=r.games.filter(g=>g.matchId===m.id).sort((a,b)=>a.board-b.board);
      return `<div class="pair-card">
        <h3>Match ${m.number}: ${esc(m.teamA)} vs ${esc(m.teamB)}</h3>
        <table>
          <thead><tr><th>Board</th><th>White</th><th>Correct Result</th><th>Black</th></tr></thead>
          <tbody>${games.map(g=>{
            const w=getPlayer(g.white),b=getPlayer(g.black);
            if(g.bye){
              return `<tr><td>${g.board}</td><td>${esc(playerDisplay(w))}</td><td>BYE</td><td>—</td></tr>`;
            }
            return `<tr>
              <td>${g.board}</td>
              <td>${esc(w?.name||'')}<br><small>${esc(g.whiteTeam||'')}</small></td>
              <td><select data-edit-round-result="${g.id}">${resultOptions(g.result)}</select></td>
              <td>${esc(b?.name||'')}<br><small>${esc(g.blackTeam||'')}</small></td>
            </tr>`;
          }).join('')}</tbody>
        </table>
      </div>`;
    }).join('');
    return;
  }

  box.innerHTML=`<table>
    <thead><tr><th>Board</th><th>White</th><th>Correct Result</th><th>Black</th></tr></thead>
    <tbody>${[...r.games].sort((a,b)=>a.board-b.board).map(g=>{
      const w=getPlayer(g.white),b=getPlayer(g.black);
      if(g.bye){
        return `<tr>
          <td><b>${g.board}</b></td>
          <td>${esc(playerDisplay(w))}</td>
          <td><span class="badge gold">BYE</span></td>
          <td>—</td>
        </tr>`;
      }
      return `<tr>
        <td><b>${g.board}</b></td>
        <td>${esc(playerDisplay(w))}</td>
        <td><select data-edit-round-result="${g.id}">${resultOptions(g.result)}</select></td>
        <td>${esc(playerDisplay(b))}</td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

async function saveEditedRound(){
  const r=selectedEditRound();
  if(!r)return;

  const hasLater=state.rounds.some(x=>x.number>r.number);
  if(hasLater){
    const ok=await appConfirm(
      `Save corrections to Round ${r.number}? Rankings and tie-breaks will be recalculated, but already-generated later pairings will NOT be changed.`,
      {title:'Correct Earlier Round',confirmText:'Save Corrections',danger:false}
    );
    if(!ok)return;
  }

  pushHistory(`Edit results — Round ${r.number}`);

  document.querySelectorAll('[data-edit-round-result]').forEach(sel=>{
    const g=r.games.find(x=>x.id===sel.dataset.editRoundResult);
    if(g)g.result=sel.value;
  });

  persist();
  renderAll();
  renderPairingsRanking();
  closeEditRoundModal();

  const status=document.getElementById('saveStatus');
  if(status){
    status.textContent=`Round ${r.number} corrected`;
    setTimeout(()=>status.textContent='Ready',1200);
  }

  showToast(`Round ${r.number} corrections saved. Rankings and tie-breaks were recalculated.`,'success','Round corrected');
}

async function rebuildCurrentRound(){
  if(!state.rounds.length){generateNextRound();return;}
  if(!await appConfirm('Regenerate the current round? Any entered results in this round will be lost.',{title:'Regenerate Round',confirmText:'Regenerate'}))return;
  pushHistory(`Regenerate Round ${state.rounds.length}`);
  state.rounds.pop();persist();generateNextRound(true);
}

function syncVisibleResults(){
  const r=currentRound();
  if(!r)return;
  document.querySelectorAll('[data-result-id]').forEach(sel=>{
    const g=r.games.find(x=>x.id===sel.dataset.resultId);
    if(g)g.result=sel.value;
  });
}

function updateGameResult(gameId,value){
  const r=currentRound();
  if(!r)return;
  const g=r.games.find(x=>x.id===gameId);
  if(!g)return;
  if(g.result===value)return;
  pushHistory(`Change result — Round ${r.number}, Board ${g.board}`);
  g.result=value;
  persist();
  const status=document.getElementById('saveStatus');
  if(status){
    status.textContent='Result saved';
    setTimeout(()=>status.textContent='Ready',900);
  }

  // Update the current round view and dependent reports immediately.
  renderPairings();
  renderStandings();
  renderPairingsRanking();
  renderDashboard();
  renderReports();
}

function saveResults(){
  const r=currentRound();if(!r)return;
  syncVisibleResults();
  persist();
  renderAll();
  showToast('Round results saved.','success','Saved');
}
function printPairings(){
  buildCleanPairingPrint();
  openPrintPreview({
    title:`Round ${currentRound()?.number||0} Pairings Preview`,
    selector:'#printPairingSheet',
    orientation:'portrait',
    bodyClass:'printing-pairings'
  });
}

function buildRoundResultsPrintSheet(){
  const box=document.getElementById('printRoundResultsSheet');
  const r=currentRound();
  if(!box)return false;
  if(!r){
    showToast('Generate a round first before previewing Round Results.','info','Round Results');
    return false;
  }
  const s=state.settings||{};
  const games=[...(r.games||[])].sort((a,b)=>(a.board||0)-(b.board||0));
  const played=games.filter(g=>!g.bye);
  const completed=played.filter(g=>!!g.result).length;
  const pending=played.length-completed;
  const whiteWins=played.filter(g=>g.result==='1-0'||g.result==='1F-0F').length;
  const blackWins=played.filter(g=>g.result==='0-1'||g.result==='0F-1F').length;
  const draws=played.filter(g=>g.result==='½-½').length;
  const byes=games.filter(g=>g.bye).length;
  const meet=(s.eventScope==='open')?'Open Tournament':String(s.meetLevel||'').toUpperCase();

  const rows=games.map(g=>{
    const w=pairingPrintPlayer(getPlayer(g.white));
    const b=g.bye?null:pairingPrintPlayer(getPlayer(g.black));
    const result=g.bye?'BYE':(g.result||'PENDING');
    return `<tr class="${!g.bye&&!g.result?'pending-result-row':''}">
      <td class="board">${esc(g.board)}</td>
      <td><span class="player-name">${esc(w.name)}</span><span class="delegation">${esc(w.delegation)}</span></td>
      <td class="rating">${esc(w.rating)}</td>
      <td class="result"><b>${esc(result)}</b></td>
      <td>${g.bye?'—':`<span class="player-name">${esc(b.name)}</span><span class="delegation">${esc(b.delegation)}</span>`}</td>
      <td class="rating">${g.bye?'—':esc(b.rating)}</td>
    </tr>`;
  }).join('');

  box.innerHTML=`
    <div class="print-round-results-document">
      <div class="print-pairing-header">
        <div class="print-brand-line print-brand-center"><img src="assets/catque-logo.png" alt="CatQue"><span>CATQUE TOURNAMENT MANAGER</span></div>
        <h1>${esc(s.name||'Chess Tournament')}</h1>
        <div class="category">${esc(s.tournamentCategory||'Open')}</div>
        <div class="round-title">ROUND ${esc(r.number)} — RESULTS</div>
      </div>
      <div class="print-meta">
        <div><b>Format:</b> ${esc(cleanFormatName())}</div>
        <div><b>Event:</b> ${esc(meet||'—')}</div>
        <div><b>Date:</b> ${esc(s.date||'—')}</div>
        <div><b>Time Control:</b> ${esc(s.timeControl||'—')}</div>
        <div><b>Venue:</b> ${esc(s.venue||'—')}</div>
        <div><b>Status:</b> ${pending===0?'Complete':`${pending} result(s) pending`}</div>
      </div>
      <div class="round-results-summary">
        <div><b>${completed}</b><span>Completed</span></div>
        <div><b>${whiteWins}</b><span>White Wins</span></div>
        <div><b>${draws}</b><span>Draws</span></div>
        <div><b>${blackWins}</b><span>Black Wins</span></div>
        <div><b>${byes}</b><span>Byes</span></div>
      </div>
      <table class="print-pairing-table print-results-table">
        <colgroup><col style="width:7%"><col style="width:32%"><col style="width:8%"><col style="width:13%"><col style="width:32%"><col style="width:8%"></colgroup>
        <thead><tr><th>Board</th><th>White</th><th>Rtg</th><th>Result</th><th>Black</th><th>Rtg</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="print-signatures">
        <div class="print-signature"><div class="name">${esc(s.chiefArbiter||'')}</div><div class="line">Chief Arbiter</div></div>
        <div class="print-signature"><div class="name">${esc(s.tournamentDirector||'')}</div><div class="line">Tournament Director (TD)</div></div>
      </div>
      <div class="catque-print-footer">Generated by CatQue Tournament Manager • Round ${esc(r.number)} Results</div>
    </div>`;
  return true;
}

function printRoundResults(){
  if(!buildRoundResultsPrintSheet())return;
  openPrintPreview({
    title:`Round ${currentRound()?.number||0} Results Preview`,
    selector:'#printRoundResultsSheet',
    orientation:'portrait',
    bodyClass:'printing-round-results'
  });
}

function pairingPrintPlayer(p){
  if(!p)return {name:'—',delegation:'',rating:'—'};
  ensurePlayerStructuredName(p);
  return {
    name:p.name||'—',
    delegation:compactDelegationLabel(p)||p.school||'',
    rating:ratingText(p)
  };
}

function cleanFormatName(){
  if(state.settings.mode==='swiss'){
    const v={
      flexible:'Flexible / Practical Swiss',
      dutch:'FIDE Dutch Swiss',
      accelerated:'Accelerated Swiss',
      double:'Double Swiss'
    }[state.settings.swissVariant||'flexible'];
    return `Swiss System — ${v}`;
  }
  if(state.settings.mode==='roundrobin'){
    return state.settings.roundRobinType==='double'?'Double Round Robin':'Round Robin';
  }
  if(state.settings.mode==='team'){
    return (state.settings.teamFormat||'swiss')==='swiss'?'Team Swiss':'Team Round Robin';
  }
  if(state.settings.mode==='knockout')return 'Knockout';
  return modeName(state.settings.mode);
}

function buildCleanPairingPrint(){
  const sheet=document.getElementById('printPairingSheet');
  const r=currentRound();
  if(!sheet)return;

  if(!r){
    sheet.innerHTML='<div style="font-family:Arial;color:#000">No round generated yet.</div>';
    return;
  }

  const s=state.settings;
  const category=s.tournamentCategory||s.category||'';
  const meet=(s.meetLevel||'').replace(/^\w/,c=>c.toUpperCase());

  let rows='';

  if(state.settings.mode==='team' && r.teamMatches){
    let displayBoard=1;
    for(const m of r.teamMatches){
      if(m.bye){
        rows+=`<tr>
          <td class="board">${displayBoard++}</td>
          <td colspan="2"><span class="player-name">${esc(m.teamA)}</span></td>
          <td class="result">TEAM BYE</td>
          <td colspan="2">—</td>
        </tr>`;
        continue;
      }
      const games=r.games.filter(g=>g.matchId===m.id).sort((a,b)=>a.board-b.board);
      for(const g of games){
        const w=pairingPrintPlayer(getPlayer(g.white));
        const b=pairingPrintPlayer(getPlayer(g.black));
        rows+=`<tr>
          <td class="board">${esc(g.board)}</td>
          <td><span class="player-name">${esc(w.name)}</span><span class="delegation">${esc(g.whiteTeam||w.delegation)}</span></td>
          <td class="rating">${esc(w.rating)}</td>
          <td class="result">${esc(g.bye?'BYE':(g.result||'________'))}</td>
          <td><span class="player-name">${esc(b.name)}</span><span class="delegation">${esc(g.blackTeam||b.delegation)}</span></td>
          <td class="rating">${esc(b.rating)}</td>
        </tr>`;
      }
    }
  }else{
    for(const g of [...r.games].sort((a,b)=>a.board-b.board)){
      const w=pairingPrintPlayer(getPlayer(g.white));
      const b=pairingPrintPlayer(getPlayer(g.black));
      rows+=`<tr>
        <td class="board">${esc(g.board)}</td>
        <td><span class="player-name">${esc(w.name)}</span><span class="delegation">${esc(w.delegation)}</span></td>
        <td class="rating">${esc(w.rating)}</td>
        <td class="result">${esc(g.bye?'BYE':(g.result||'________'))}</td>
        <td>${g.bye?'—':`<span class="player-name">${esc(b.name)}</span><span class="delegation">${esc(b.delegation)}</span>`}</td>
        <td class="rating">${g.bye?'—':esc(b.rating)}</td>
      </tr>`;
    }
  }

  sheet.innerHTML=`
    <div class="print-pairing-header">
      <div class="print-brand-line print-brand-center"><img src="assets/catque-logo.png" alt="CatQue"><span>CATQUE TOURNAMENT MANAGER</span></div>
      <h1>${esc(s.name||'Chess Tournament')}</h1>
      ${category?`<div class="category">${esc(category)}</div>`:''}
      <div class="round-title">PAIRINGS — ROUND ${esc(r.number)}</div>
    </div>

    <div class="print-meta">
      <div><b>Format:</b> ${esc(cleanFormatName())}</div>
      <div><b>Meet Level:</b> ${esc(meet||'—')}</div>
      <div><b>Date:</b> ${esc(s.date||'—')}</div>
      <div><b>Time Control:</b> ${esc(s.timeControl||'—')}</div>
      <div><b>Venue:</b> ${esc(s.venue||'—')}</div>
      <div><b>Players:</b> ${state.players.length}</div>
    </div>

    <table class="print-pairing-table">
      <colgroup>
        <col style="width:7%">
        <col style="width:32%">
        <col style="width:8%">
        <col style="width:11%">
        <col style="width:34%">
        <col style="width:8%">
      </colgroup>
      <thead>
        <tr>
          <th>Board</th>
          <th>White</th>
          <th>Rtg</th>
          <th>Result</th>
          <th>Black</th>
          <th>Rtg</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>

    <div class="print-signatures">
      <div class="print-signature">
        <div class="name">${esc(s.chiefArbiter||'')}</div>
        <div class="line">Chief Arbiter</div>
      </div>
      <div class="print-signature">
        <div class="name">${esc(s.tournamentDirector||'')}</div>
        <div class="line">Tournament Director (TD)</div>
      </div>
    </div>
  `;
}
let roundFocusMode=false;
function toggleRoundFocusMode(){
  roundFocusMode=!roundFocusMode;
  document.body.classList.toggle('round-focus-mode',roundFocusMode);
  const btn=document.getElementById('focusRoundBtn');
  if(btn)btn.textContent=roundFocusMode?'Exit Focus Mode':'⛶ Focus Mode';
  if(roundFocusMode)window.scrollTo({top:0,behavior:'smooth'});
}
function firstPendingGame(){
  const r=currentRound();
  return r?.games?.find(g=>!g.bye&&!g.result)||null;
}
function scrollToPendingBoard(){
  const g=firstPendingGame();
  if(!g)return;
  const el=document.querySelector(`[data-board-id="${g.id}"]`);
  if(el)el.scrollIntoView({behavior:'smooth',block:'center'});
}

function isScheduledFinalRound(round=currentRound()){
  if(!round || state.settings.mode==='knockout')return false;
  const total=+state.settings.rounds||0;
  return total>0 && state.rounds.length>=total;
}


function endCurrentRound(){
  syncVisibleResults();
  const round=currentRound();
  if(!round)return;

  const pending=round.games.filter(g=>!g.bye&&!g.result).length;
  if(pending>0){
    showToast(`Round ${round.number} still has ${pending} unfinished result(s).`,'info','Round not finished');
    setTimeout(()=>scrollToPendingBoard(),60);
    return;
  }

  if(round.finalized){
    updateMainRoundAction(round);
    return;
  }

  pushHistory(`End Round ${round.number}`);
  round.finalized=true;
  round.finalizedAt=new Date().toISOString();
  persist();
  renderStandings?.();
  renderPairingsRanking?.();
  renderDashboard?.();
  renderReports?.();
  renderPairings();

  if(isScheduledFinalRound(round)){
    showToast(`Round ${round.number} ended. Tournament is complete.`,'success','Tournament complete');
    setTimeout(()=>showFinalTournamentResult(),120);
  }else{
    showToast(`Round ${round.number} ended. Review the ranking, then generate the next round when ready.`,'success','Round ended');
  }
}

function showFinalTournamentResult(){
  renderStandings?.();
  goTab('standings');
  setTimeout(()=>{
    const heading=document.querySelector('#standings h3');
    if(heading && typeof isTournamentFinalResult==='function' && isTournamentFinalResult()){
      heading.textContent='Final Result';
    }
    showToast('Tournament completed. Official final ranking is now shown.','success','Final Result');
    window.scrollTo?.({top:0,behavior:'smooth'});
  },30);
}


function canShuffleRoundOne(){
  return state.settings?.mode==='swiss' &&
    state.rounds.length===0 &&
    state.players.length>=2;
}

function roundOnePreviewModel(){
  if(!canShuffleRoundOne())return null;

  if((state.settings.swissVariant||'flexible')==='dutch'){
    const games=window.__catqueExactDutchPreviewGames;
    if(!Array.isArray(games)){
      return {pairs:[],bye:null,dutch:true,pending:true};
    }
    const preview={pairs:[],bye:null,dutch:true,pending:false};
    for(const g of games){
      if(g.bye)preview.bye=getPlayer(g.white);
      else preview.pairs.push([getPlayer(g.white),getPlayer(g.black)]);
    }
    return preview;
  }

  const pool=[...state.players];
  const preview={pairs:[],bye:null};
  if(pool.length%2)preview.bye=pool.pop();
  for(let i=0;i<pool.length;i+=2)preview.pairs.push([pool[i],pool[i+1]]);
  return preview;
}

function renderRoundOneShufflePreview(){
  const preview=roundOnePreviewModel();
  if(!preview)return '';

  if(preview.dutch && preview.pending && state.settings?.manualRosterShuffle){
    return `<div class="round1-shuffle-intro">
      <div class="round1-shuffle-icon">♟</div>
      <div>
        <b>Exact FIDE Dutch preview is loading</b>
        <div class="help">The shuffled roster is now the TPN order. CatQue is asking the pinned C.04.3 engine for the exact board pairings.</div>
      </div>
    </div>`;
  }

  if(!state.settings?.manualRosterShuffle){
    return `<div class="round1-shuffle-intro">
      <div class="round1-shuffle-icon">🔀</div>
      <div>
        <b>Shuffle Round 1 before starting</b>
        <div class="help">Click <b>Shuffle Round 1</b> to randomize the starting pairings. Nothing is recorded as Round 1 until you click <b>Start Round 1</b>.</div>
      </div>
    </div>`;
  }

  const rows=preview.pairs.map(([a,b],i)=>`
    <div class="round1-preview-row">
      <div class="board-badge">B${i+1}</div>
      <div class="round1-preview-player">${esc(a?.name||'')}</div>
      <div class="round1-preview-vs">vs</div>
      <div class="round1-preview-player">${esc(b?.name||'')}</div>
    </div>`).join('');

  const bye=preview.bye
    ? `<div class="round1-preview-row round1-preview-bye">
        <div class="board-badge">BYE</div>
        <div class="round1-preview-player">${esc(preview.bye.name||'')}</div>
        <div class="round1-preview-vs">—</div>
        <div><span class="badge gold">PAIRING BYE</span></div>
      </div>`
    : '';

  return `<div class="round1-shuffle-preview">
    <div class="round1-preview-head">
      <div>
        <div class="wizard-participant-kicker">ROUND 1 PREVIEW</div>
        <h3>Shuffled Pairings</h3>
        <div class="help">This is only a preview. Click <b>Reshuffle Round 1</b> for another draw, or <b>Start Round 1</b> to lock these pairings.</div>
      </div>
      <span class="badge green">NOT STARTED YET</span>
    </div>
    <div class="round1-preview-list">${rows}${bye}</div>
  </div>`;
}

function updateRoundOneShuffleUI(){
  const btn=document.getElementById('shuffleRoundOneBtn');
  const saveBtn=document.getElementById('saveRoundResultsBtn');
  if(btn){
    const visible=canShuffleRoundOne();
    btn.style.display=visible?'inline-flex':'none';
    btn.disabled=!visible;
    btn.textContent=state.settings?.manualRosterShuffle
      ? '🔀 Reshuffle Round 1'
      : '🔀 Shuffle Round 1';
  }
  if(saveBtn){
    saveBtn.style.display=state.rounds.length?'inline-flex':'none';
  }
}

async function shuffleRoundOnePairings(){
  if(!canShuffleRoundOne()){
    showToast('Round 1 can only be shuffled before it is started.','info','Shuffle Round 1');
    return;
  }

  // Reuse the roster shuffle logic so the exact shuffled order is persisted
  // and then used by randomSchoolRoundOnePair() when Round 1 starts.
  shufflePlayers();
  state.settings.manualRosterShuffle=true;
  if((state.settings.swissVariant||'flexible')==='dutch'){
    state.players.forEach(p=>{delete p.dutchTpn;});
    delete state.settings.dutchTpnLocked;
    delete state.settings.dutchEngine;
  }
  persist();

  if((state.settings.swissVariant||'flexible')==='dutch'){
    window.__catqueExactDutchPreviewGames=null;
    renderPairings();
    const exactPreview=await dutchStyleSwissPair(state.players,{preview:true});
    if(exactPreview){
      window.__catqueExactDutchPreviewGames=exactPreview;
      renderPairings();
      showToast('TPN order shuffled. The preview now comes from the exact FIDE Dutch C.04.3 engine.','success','Exact Dutch preview');
    }else{
      renderPairings();
    }
    return;
  }

  renderPairings();
  showToast('Round 1 pairings shuffled. Review the preview, then click Start Round 1.','success','Round 1 shuffled');
}

function updateMainRoundAction(round=currentRound()){
  const btn=document.getElementById('mainRoundActionBtn');
  const label=document.getElementById('mainRoundActionText');
  if(!btn||!label)return;

  btn.disabled=false;

  if(!round){
    label.textContent=state.settings?.manualRosterShuffle?'Start Round 1':'Start Round 1';
    btn.onclick=()=>generateNextRound();
    btn.disabled=state.players.length<2;
    btn.title=state.players.length<2
      ? 'Add at least 2 players first.'
      : (state.settings?.manualRosterShuffle
          ? 'Start Round 1 using the shuffled pairing preview.'
          : 'Start Round 1. You can also shuffle the pairings first.');
    return;
  }

  const pending=round.games.filter(g=>!g.bye&&!g.result).length;
  const finalRound=isScheduledFinalRound(round);

  if(pending>0){
    label.textContent=`Complete Round ${round.number} (${pending} left)`;
    btn.onclick=()=>scrollToPendingBoard();
    btn.title='Go to the next board without a result.';
    return;
  }

  if(!round.finalized){
    label.textContent=finalRound?'End Final Round':'End Round';
    btn.onclick=()=>endCurrentRound();
    btn.title='Confirm that this round is complete.';
    return;
  }

  if(finalRound){
    label.textContent='View Final Result';
    btn.onclick=()=>showFinalTournamentResult();
    btn.title='Open the official final ranking.';
    return;
  }

  label.textContent='Generate Next Round';
  btn.onclick=()=>generateNextRound();
  btn.title='Generate the next scheduled round.';
}

function updateRoundStickyBar(round=currentRound()){
  const title=document.getElementById('roundStickyTitle');
  const help=document.getElementById('roundStickyHelp');
  const primary=document.getElementById('roundStickyPrimary');
  if(!title||!help||!primary)return;

  if(!round){
    title.textContent='Ready to start';
    help.textContent=`${state.players.length} player(s) registered. Generate Round 1 when ready.`;
    primary.textContent='Generate Round 1';
    primary.disabled=state.players.length<2;
    primary.onclick=()=>generateNextRound();
    return;
  }
  const pending=round.games.filter(g=>!g.bye&&!g.result).length;
  const played=round.games.filter(g=>!g.bye).length;
  if(pending>0){
    title.textContent=`Round ${round.number} • ${pending} result(s) left`;
    help.textContent=`${played-pending}/${played} played boards completed.`;
    primary.textContent='Go to Next Unfinished Board';
    primary.disabled=false;
    primary.onclick=()=>scrollToPendingBoard();
  }else{
    title.textContent=`Round ${round.number} complete`;
    help.textContent='All results are encoded and auto-saved.';
    const allDone=isScheduledFinalRound(round);
    primary.textContent=allDone?'View Final Result':'Generate Next Round';
    primary.disabled=false;
    primary.onclick=allDone?(()=>showFinalTournamentResult()):(()=>generateNextRound());
  }
}

function resultOptions(value){
  const opts=['','1-0','0-1','½-½','1F-0F','0F-1F'];
  return opts.map(o=>`<option ${o===value?'selected':''} value="${o}">${o||'Select result'}</option>`).join('');
}
function renderPairingsSummaryCards(round){
  const box=document.getElementById('pairingsSummaryCards');
  if(!box)return;
  const current=round||currentRound();
  const boards=current?.games?.filter(g=>!g.bye).length||0;
  const byes=current?.games?.filter(g=>g.bye).length||0;
  const done=current?.games?.filter(g=>g.bye||g.result).length||0;
  const total=current?.games?.length||0;
  const pending=Math.max(total-done,0);
  box.innerHTML=[
    ['Round', current?.number||0, current ? 'Current active round' : 'No round yet'],
    ['Boards', boards, boards ? 'Games to be played' : 'Waiting for pairings'],
    ['Pending', pending, pending ? 'Results still to encode' : 'All boards encoded'],
    ['Byes', byes, byes ? 'Automatic pairing bye(s)' : 'No bye in this round']
  ].map(([label,value,sub])=>`<div class="summary-card-mini"><div class="label">${esc(label)}</div><div class="value">${value}</div><div class="sub">${esc(sub)}</div></div>`).join('');
}

function resultChipButtons(g){
  const options=[
    ['1-0','White Win'],
    ['½-½','Draw'],
    ['0-1','Black Win'],
    ['1F-0F','White Forfeit'],
    ['0F-1F','Black Forfeit']
  ];
  return `<div class="result-chip-row">${options.map(([value,label])=>`<button type="button" class="result-chip ${g.result===value?'active':''}" onclick="updateGameResult('${g.id}','${value}')">${esc(label)}</button>`).join('')}<select class="result-chip-select" data-result-id="${g.id}" onchange="updateGameResult('${g.id}',this.value)">${resultOptions(g.result)}</select></div>`;
}

function renderPairings(){
  const r=currentRound();
  roundLabel.textContent=r?.number||0;
  const roundOfTotal=document.getElementById('roundOfTotal');
  if(roundOfTotal){
    const total=Number(state.settings?.rounds||0);
    roundOfTotal.textContent=total?`of ${total}`:'';
  }
  renderPairingsSummaryCards(r);
  updateRoundStickyBar(r);
  updateMainRoundAction(r);
  updateRoundOneShuffleUI();
  pairingNote.style.display=(state.settings.mode==='swiss'||state.settings.mode==='team')?'block':'none';
  if(state.settings.mode==='swiss'){
    const v=state.settings.swissVariant||'flexible';
    const randomRoundOne=!!r?.games?.some(g=>g.randomSchoolRoundOne);
    if(randomRoundOne){
      pairingNote.textContent=state.settings?.manualRosterShuffle
        ? 'Round 1 uses the Shuffle Players order you selected in the Players screen. From Round 2 onward, normal Swiss score-based pairing is used.'
        : 'School / DepEd unrated Round 1: players were randomly shuffled before pairing. If the roster is odd, the first-round bye is also chosen randomly. From Round 2 onward, normal Swiss score-based pairing is used.';
    }else pairingNote.textContent=v==='dutch'
      ? 'FIDE Dutch Swiss: dedicated deterministic Dutch engine. Players are ordered by score then TPN; Flexible / Practical Swiss is not used.'
      : v==='accelerated'
      ? 'Accelerated Swiss: temporary virtual pairing points are used in the opening rounds; real standings points are unchanged.'
      : v==='double'
      ? 'Double Swiss: each pairing contains two games with reversed colors.'
      : 'Flexible / Practical Swiss: similar scores, repeat-opponent avoidance, and color balancing for school/local events.';
  } else if(state.settings.mode==='team'){
    pairingNote.textContent='Team Tournament: teams are formed from the current meet-level delegation and ranked by Match Points, then Board Points.';
  }

  if(!r){
    pairingsList.innerHTML=renderRoundOneShufflePreview();
    return;
  }

  if(state.settings.mode==='team' && r.teamMatches){
    pairingsList.innerHTML=r.teamMatches.map(m=>{
      if(m.bye)return `<div class="pair-card-easy" data-board-id="${g.id}"><div class="pair-bye-easy"><div><div class="board-badge">M${m.number}</div></div><div><b>${esc(m.teamA)}</b></div><div><span class="badge gold">TEAM BYE</span></div></div></div>`;
      const gs=r.games.filter(g=>g.matchId===m.id).sort((a,b)=>a.board-b.board);
      return `<div class="pair-card-easy">
        <div class="pair-card-head"><div><div class="board-badge">M${m.number}</div></div><div><b>${esc(m.teamA)} vs ${esc(m.teamB)}</b></div></div>
        <table class="roster-table-compact"><thead><tr><th>Board</th><th>White</th><th>Result</th><th>Black</th></tr></thead><tbody>
        ${gs.map(g=>{
          const w=getPlayer(g.white),b=getPlayer(g.black);
          if(g.bye)return `<tr><td>${g.board}</td><td>${esc(playerDisplay(w))}</td><td>BYE</td><td>—</td></tr>`;
          return `<tr><td>${g.board}</td><td>${esc(w?.name||'')}<span class="subline">${esc(g.whiteTeam||'')}</span></td><td>${resultChipButtons(g)}</td><td>${esc(b?.name||'')}<span class="subline">${esc(g.blackTeam||'')}</span></td></tr>`;
        }).join('')}</tbody></table>
      </div>`;
    }).join('');
    return;
  }

  pairingsList.innerHTML=r.games.sort((a,b)=>a.board-b.board).map(g=>{
    const w=getPlayer(g.white),b=getPlayer(g.black);
    if(g.bye){
      return `<div class="pair-card-easy" data-board-id="${g.id}"><div class="pair-bye-easy"><div class="board-badge">B${g.board}</div><div><b>${esc(playerDisplay(w))}</b><div class="subline">${esc(compactDelegationLabel(w)||w?.school||'')}</div></div><div><span class="badge gold">PAIRING BYE</span></div></div></div>`;
    }
    return `<div class="pair-card-easy" data-board-id="${g.id}">
      <div class="pair-card-head"><div class="board-badge">B${g.board}</div><div class="help">Tap the result below to encode this board.</div></div>
      <div class="pair-players-grid">
        <div class="pair-player-panel">
          <div class="top"><span class="color-dot w">W</span> <b>${esc(w?.name||'')}</b></div>
          <span class="subline">${esc(compactDelegationLabel(w)||w?.school||'')}</span>
          <span class="subline">Rating: ${ratingText(w)}</span>
        </div>
        <div class="pair-vs">VS</div>
        <div class="pair-player-panel">
          <div class="top"><span class="color-dot b">B</span> <b>${esc(b?.name||'')}</b></div>
          <span class="subline">${esc(compactDelegationLabel(b)||b?.school||'')}</span>
          <span class="subline">Rating: ${ratingText(b)}</span>
        </div>
      </div>
      ${resultChipButtons(g)}
    </div>`;
  }).join('');
}
